import java.awt.Frame;
import java.awt.Event;
import java.awt.Panel;
import java.awt.List;
import java.awt.Color;
import java.awt.Insets;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.CheckboxMenuItem;
import java.awt.FileDialog;
import java.awt.Toolkit;
import java.awt.Image;
import java.awt.MediaTracker;

import java.applet.Applet;
import java.io.File;
import java.util.Properties;
import java.net.URL;

//////////////////////////////////////////////////////////////////////
// 
//  This is the entry-point for the MicMac simulator.  MicMacApplet
//  merely instantiates this class.
//
//  MicMac provides the primary user interface and framework to the
//  simulator and IDE.  
//
//  Much of the business of this class is to menus and dispatch
//  menu & keyboard related events to routines which do the work
//  of the IDE.  Here are a few notable things:
//
//  * editSource()        lets you edit your programs
//  * buildSource()       compiles MicMac programs in the context of
//                        the IDE.  (The compiler MicMacMake can be
//                        run at the command line.)
//
//  * runJavaBenchmark()  is the MicMacMark benchmark
//  * generateReport()    provides a lot of the 'take with you' output
//  * displayHelp()       shows all help files
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 Entry point for the MicMac microprogramming simulator & IDE for
 both applet and application modes.
 @see MicMacApplet
 */

public class MicMac extends Frame
{
   ///////////////////////////////////////////////////////////////////
   //  Constructor.  An instance shows itself!  Here is where the
   //  program determines if it is "trusted" or not.  Instantiating
   //  MicMac spawns two threads:  the simulator and the talker.
   //  The talker writes inviting things on the display for new
   //  users, while the simulator is a thread so that it can execute
   //  programs while allowing the UI to be responsive.
   ///////////////////////////////////////////////////////////////////

   /**
    Create and start a new MicMac session
    @param applet Reference to calling applet, or null if application mode.
    */

   public MicMac( Applet applet)
   {
      try {  // Just temporary till we find that null pointer exception in Linux!

         trusted = makeMicMacDirectory("MicMac");

         this.applet = applet;

         setTitle("Hi, I'm Initializing...");

         cpu = new MicMacCanvas( applet);

         Panel p = new Panel();
         p.setLayout( new BorderLayout());
         p.add("Center", cpu);

        

         setBackground( new Color( 255,255,204));

         sim = new Simulator( null, this, cpu);
         sim.setPriority( Thread.MIN_PRIORITY);

         cpu.setSimulator( sim);

         setResizable( true); 

         pack(); setMenuBar( setupMenus()); pack();

         setLayout( new GridBagLayout()); 
         setupGBC( (GridBagLayout) getLayout(), cpu, 1, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH);

         Util.nextWindowCorner(this);
         Util.setWindowCorner(this);

         show();  


         // HACK! addNotify should tell us when it is safe to consult/use
         // the visbile components of this interface -- it does not always
         // do that!

         while ( !cpu.getUiReady())
            Util.sleep(100);
     

         //cpu.paintNow();


         // HACK! Correct for window mis-sizing because of the manubar and
         // possible Applet Warning

         Insets i = insets();

         resize( i.left + i.right  + cpu.minimumSize().width,
                 i.top  + i.bottom + cpu.minimumSize().height);



         requestFocus();  // HACK! (it should have the focus by default.)

         loadDefaultMic();

         sim.macTraceOnPC( mItemMacTraceOnPC.getState());

         setStatus("Downloading Default Mic Program...");

         String s = Util.readFile( applet, "Mic.exa");

         if ( s != null)
            sim.setSource( (defaultMic = s));


         setStatus( "Aucht! Das Blinkenlites!   Get Serious?  OK, select 'Help/Get Started' on the menubar." +
            "                            " + 
            Util.getJavaVersion() + "    " + 
            Util.getOSVersion());

         talker = new MicMacTalker(cpu);


         prefetch = new Prefetch( applet);    // this is the order I thing the user is 
         prefetch.add( STARTED_HELP);         // most likely to want these files.
         prefetch.add( "Addtwo.exa");
         prefetch.add( MMINTRO_HELP);
         prefetch.add( MACPROG_HELP);
         prefetch.add( PROGRAM_HELP);
         prefetch.add( CONTROL_HELP);
         prefetch.add( DEBUG_HELP);
         prefetch.add( GENTLE_HELP);
         prefetch.add( MICPROG_HELP);
         prefetch.add( INTRO_HELP);
      }
      catch( Exception e) {
         System.out.println("Reported from MicMac.class: ");
         System.out.println("   Exeception: " + e.getMessage());
         e.printStackTrace();
      }
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Public Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   ////////////////////////////////////////////////////////////
   //  Handle events.  Sorry for this monolith, event handling
   //  under 1.1 becomes much cleaner.  You have to tie the
   //  UI to the application too much in 1.02 for my tastes.
   ////////////////////////////////////////////////////////////

   /**
    Handles MicMac's menu system and hot-keys, as well as keyboard
    input for the simulator's TTY input device.
    */

   public boolean handleEvent( Event e)
   {

      // Handle Console keyboard input

      if ( e.id == Event.KEY_PRESS) {
         if ( sim.fetchCore(Simulator.CONSOLE_ISTAT_REG) == 0) {
            sim.storeCore(Simulator.CONSOLE_ISTAT_REG, 0xFFFF);
            sim.storeCore(Simulator.CONSOLE_INPUT_REG,  (e.key & 0xFF));
            cpu.drawConsoleRegisters();
         }
      }
      else

      // Handle Application Exit...

      if ( e.id == Event.WINDOW_DESTROY || e.target == mItemExit) {
         if ( editor != null && editor.getDirty() == true) {
            haltSimulation();
            //saveSimulation();
         }

         // Stop background threads...

         try { sim.stop(); }   catch(Exception x) {}
         try { talker.stop(); } catch(Exception x) {}

         hide();
         dispose();

         if ( applet != null)
            stop();
         else
            System.exit(0);
      }
      else

      // Handle Menus & Function Keys

      if ( e.id == Event.ACTION_EVENT || 
           e.id == Event.KEY_ACTION) {

         setStatus("");  
         requestFocus();  // HACK! I should not have to shift focus here!
         repaint();

         // Simulator

         for ( int i = 0; i < mItemExample.length; i++)
            if ( e.target == mItemExample[i])
               loadExample( (String) e.arg);

         if ( e.target == mItemEdit)
            editSource();
         else
         if ( e.target == mItemBuild) {
            cpu.paintNow();
            haltSimulation();
            resetSimulation();
            buildSource();
         }
         else
         if ( e.target == mItemSave)
            saveSimulation();
         else
         if ( e.target == mItemSaveAs)
            saveSimulationAs(null);
         else
         if ( e.target == mItemLoad)
            loadSimulation();
         else
         if ( e.target == mItemGenReport) {
            cpu.paintNow();
            generateReport(false);
         }
         else
         if ( e.target == mItemGenReportAll) {
            cpu.paintNow();
            generateReport(true);
         }
         else


         // Control

         if ( e.target == mItemReset    || e.key == Event.F2)
            resetSimulation();
         else
         if ( e.target == mItemRun      || e.key == Event.F3)
            runSimulation();
         else
         if ( e.target == mItemHalt     || e.key == Event.F4)
            haltSimulation();
         else
         if ( e.target == mItemMicPhase || e.key == Event.F5)
            sim.nextMicPhase();
         else
         if ( e.target == mItemMicStep  || e.key == Event.F6) 
            sim.nextMicCycle();
         else
         if ( e.target == mItemMacStep  || e.key == Event.F7) 
            sim.nextMacCycle();
         else
         if ( e.target == mItemMacTraceOnPC)
            sim.macTraceOnPC( mItemMacTraceOnPC.getState());
         else

         if ( e.target == mItemMicDrawLevel)
            resetDrawLevelChecks((CheckboxMenuItem) e.target, MicMacCanvas.REDRAW_FULL);
         else
         if ( e.target == mItemMacDrawLevel)
            resetDrawLevelChecks((CheckboxMenuItem) e.target, MicMacCanvas.REDRAW_MAC);
         else
         if ( e.target == mItemMinDrawLevel)
            resetDrawLevelChecks((CheckboxMenuItem) e.target, MicMacCanvas.REDRAW_NONE);
         else
            
            
            
            
         // Debug


         if ( e.target == mItemMicTrace)
            sim.micTraceEnable( mItemMicTrace.getState());
         else
         if ( e.target == mItemMacTrace)
            sim.macTraceEnable( mItemMacTrace.getState());
         else
         if ( e.target == mItemClearTrace)
            clearTrace();
         else
         if ( e.target == mItemViewTrace)
            viewTrace();
         else
         if ( e.target == mItemMicBreak) {
            if ( sim.getMicBreakpoints() != null)
               new EditBreakpoints( this, "Mic Breakpoints", sim.getMicBreakpoints());
         }
         else
         if ( e.target == mItemMacBreak) {
            if ( sim.getMacBreakpoints() != null)
               new EditBreakpoints( this, "Mac Breakpoints", sim.getMacBreakpoints());
         }
         else
         if ( e.target == mItemClearBreak)
            clearBreakpoints();
         else
         if ( e.target == mItemMicClear) {
            sim.clearStore();
            sim.setMicBreakpoints(null);
            mItemLockBreak.setState(false);
            setStatus("Microstore Cleared.");
         }
         else
         if ( e.target == mItemMacClear) {
            sim.clearCore();
            sim.setMacBreakpoints(null);
            mItemLockBreak.setState(false);
            setStatus("Main Memory Cleared.");
         }
         else
         if ( e.target == mItemMicDump)
            new EditDump( this, sim, EditDump.STORE);
         else
         if ( e.target == mItemMacDump)
            new EditDump( this, sim, EditDump.CORE);
         else
         if ( e.target == mItemRegDump)
            new EditDump( this, sim, cpu);
         else


         // Help

         if ( e.target == mItemHelpBenchmark || e.key == Event.F12)
            runJavaBenchmark();
         else
         if ( e.target == mItemHelpGentle)
            displayHelp( GENTLE_HELP,"Gentle Introdution to Computers");
         else
         if ( e.target == mItemHelpStarted)
            displayHelp( STARTED_HELP,"Getting Started");
         else
         if ( e.target == mItemHelpMicMacIntro)
            displayHelp( MMINTRO_HELP,"Introduction");
         else
         if ( e.target == mItemHelpProgramming)
            displayHelp( PROGRAM_HELP,"Programming Menu");
         else
         if ( e.target == mItemHelpControl)
            displayHelp( CONTROL_HELP,"Control Menu");
         else
         if ( e.target == mItemHelpDebug)
            displayHelp( DEBUG_HELP,"Debug Menu");
         else
         if ( e.target == mItemHelpMicProgram)
            displayHelp( MICPROG_HELP,"Mic Programming");
         else
         if ( e.target == mItemHelpMacProgram)
            displayHelp( MACPROG_HELP,"Mac Programming");
         else
         if ( e.target == mItemHelpResource)
            displayHelp( RESOURCE_HELP,"Useful Resources");
         else
         if ( e.target == mItemHelpLegal)
            displayHelp( LEGAL_HELP,"Kudos & Legalities");
         else
         if ( e.target == mItemHelpSignature)
            displayHelp( SIG_HELP,"Digital Signatures");
         else
         if ( e.target == mItemHelpUInterface)
            displayHelp( UI_HELP, "User Interface & AWT");
         else
         if ( e.target == mItemHelpFileAccess)
            displayHelp( FILE_HELP, "File Access");
         else
         if ( e.target == mItemHelpCompiler)
            displayHelp( COMPILER_HELP, "MicMac Compiler");
         else
         if ( e.target == mItemHelpSpeed)
            displayHelp( SPEED_HELP, "Speed Issues");
         else
         if ( e.target == mItemHelpGottcha)
            displayHelp( GOTTCHA_HELP, "Java Gottchas");
         else
         if ( e.target == mItemHelpIntroduction)
            displayHelp( INTRO_HELP,"Source Code Introduction");
         else
         if ( e.target == mItemHelpFastList)
            displayHelp( FASTLIST_JAVA,"FastList Class Definition");
         else
         if ( e.target == mItemHelpEditBreakpoints)
            displayHelp( EDITBREAKPOINTS_JAVA,"EditBreakpoints Class Definition");
         else
         if ( e.target == mItemHelpEditDump)
            displayHelp( EDITDUMP_JAVA,"EditDump Class Definition");
         else
         if ( e.target == mItemHelpEditor)
            displayHelp( EDITOR_JAVA,"Editor Class Definition");
         else
         if ( e.target == mItemHelpFindDialog)
            displayHelp( FINDDIALOG_JAVA,"FindDialog Class Definition");
         else
         if ( e.target == mItemHelpMessageDialog)
            displayHelp( MESSAGEDIALOG_JAVA, "MessageDialog Class Definition");
         else
         if ( e.target == mItemHelpMicMac)
            displayHelp( MICMAC_JAVA,"MicMac Class Definition (entrypoint)");
         else
         if ( e.target == mItemHelpMicMacApplet)
            displayHelp( MICMACAPPLET_JAVA,"MicMacApplet Class Definition (entrypoint)");
         else
         if ( e.target == mItemHelpMicMacCanvas)
            displayHelp( MICMACCANVAS_JAVA, "MicMacCanvas Class Definition");
         else
         if ( e.target == mItemHelpMicMacMake)
            displayHelp( MICMACMAKE_JAVA,"MicMacMake Class Definition");
         else
         if ( e.target == mItemHelpMicMacSymbol)
            displayHelp( MICMACSYMBOL_JAVA,"MicMacSymbol Class Definition");
         else
         if ( e.target == mItemHelpMicMacTalker)
            displayHelp( MICMACTALKER_JAVA,"MicMacTalker Class Definition");
         else
         if ( e.target == mItemHelpPrefetch)
            displayHelp( PREFETCH_JAVA,"Prefetch Class Definition");
         else
         if ( e.target == mItemHelpSimulator)
            displayHelp( SIMULATOR_JAVA,"Simulator Class Definition");
         else
         if ( e.target == mItemHelpSort)
            displayHelp( SORT_JAVA,"Sort Class Definition");
         else
         if ( e.target == mItemHelpTokenizer)
            displayHelp( TOKENIZER_JAVA,"Tokenizer Class Definition");
         else
         if ( e.target == mItemHelpUtil)
            displayHelp( UTIL_JAVA,"Util Class Definition");
         else
         if ( e.target == mItemHelpAbout)
            aboutMessage();


         repaint();
         System.gc();

         return true;
      }
      else
      if ( e.id == Event.WINDOW_EXPOSE)
         repaint();

      return super.handleEvent(e);
   }





   //////////////////////////////////////////////////////////////////////
   //  Try to make the MicMac home directory on the user's machine
   //  Return true if we can do it (we are "trusted"), false, otherwise
   //////////////////////////////////////////////////////////////////////

   /**
    Try to make the MicMac home directory on the user's machine
    @param  baseDir Try to create our home directory by this name.
    @return True if we created the directory (and are trusted), false otherwise.
    */

   public boolean makeMicMacDirectory(String baseDir)
   {
      try {
         String jdir = System.getProperties().getProperty("java.home");
         String fsep = System.getProperties().getProperty("file.separator");

         if ( baseDir != null && !baseDir.equals("")) {
            homeDir          = jdir + fsep + baseDir;
            homeDirSeparator = fsep;
            makeDirectoryTest();
         }

         return true;
      }
      catch (Exception e) { return false; }
   }




   ///////////////////////////////////////////////////////////////////
   //  These correspond to MicMacApplet's start() and stop() methods
   //  and are invoked by these methods by the controlling web
   //  browser if operating as an applet.
   ///////////////////////////////////////////////////////////////////

   /**
    Corresponds with MicMacApplet's start() method.
    */

   public void start()
   {
      if ( applet != null)
         show();
   }

   /**
    Corresponds with MicMacApplet's stop() method.
    */

   public void stop()
   {
      if ( applet == null)
         System.exit(0);
      else
         hide();
   }



   ///////////////////////////////////////////////////////////////////
   //  Return the current version number
   ///////////////////////////////////////////////////////////////////

   /**
    Return MicMac's version string.
    @return Version string.
    */

   public static String getVersion()
   {
      return version;
   }



   ///////////////////////////////////////////////////////////////////
   //  Start MicMac as an application
   ///////////////////////////////////////////////////////////////////

   /**
    Start a new MicMac session from the host operating system command line:
    <tt>java MicMac</tt>
    */

   public static void main( String args[])
   {
      new MicMac( null);
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Private Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   private static final int MAX_TEXTAREA_SIZE = 50000;
   private static String    version = "3.4";

   private boolean      trusted = false;

   private String       homeDir;
   private String       homeDirSeparator;

   private String       defaultMic = "";
   
   private long         sTime, eTime;

   private Simulator    sim;
   private Applet       applet;
   private Panel        pan;
   private MicMacCanvas cpu;
   private MicMacTalker talker;
   private Prefetch     prefetch;


   private Editor       editor = null;
   private boolean      dirty  = false;

   private Menu     mItemExamples;
   private MenuItem mItemExample[];
   private MenuItem mItemEdit;
   private MenuItem mItemBuild;
   private MenuItem mItemLoad;
   private MenuItem mItemSave;
   private MenuItem mItemSaveAs;
   private MenuItem mItemExit;

   private Menu             mItemReport;
   private CheckboxMenuItem mItemRptListing;
   private CheckboxMenuItem mItemRptParseTrace;
   private CheckboxMenuItem mItemRptExecTrace;
   private CheckboxMenuItem mItemRptMicDump;
   private CheckboxMenuItem mItemRptMacDump;
   private CheckboxMenuItem mItemRptSource;
   private MenuItem         mItemGenReport;
   private MenuItem         mItemGenReportAll;

   private MenuItem mItemReset;
   private MenuItem mItemRun;
   private MenuItem mItemHalt;
   private MenuItem mItemMicPhase;
   private MenuItem mItemMicStep;
   private MenuItem mItemMacStep;
   private CheckboxMenuItem mItemMacTraceOnPC;
   private CheckboxMenuItem mItemMicDrawLevel;
   private CheckboxMenuItem mItemMacDrawLevel;
   private CheckboxMenuItem mItemMinDrawLevel;

   private MenuItem mItemMicBreak;
   private MenuItem mItemMacBreak;
   private MenuItem mItemClearBreak;
   private CheckboxMenuItem mItemLockBreak;

   private CheckboxMenuItem mItemMicTrace;
   private CheckboxMenuItem mItemMacTrace;
   private MenuItem mItemClearTrace;
   private MenuItem mItemViewTrace;
   private MenuItem mItemMicClear;
   private MenuItem mItemMacClear;
   private MenuItem mItemMicDump;
   private MenuItem mItemMacDump;
   private MenuItem mItemRegDump;

   private MenuItem mItemHelpBenchmark;
   private MenuItem mItemHelpGentle;
   private MenuItem mItemHelpStarted;
   private MenuItem mItemHelpMicMacIntro;
   private MenuItem mItemHelpProgramming;
   private MenuItem mItemHelpControl;
   private MenuItem mItemHelpDebug;
   private MenuItem mItemHelpMicProgram;
   private MenuItem mItemHelpMacProgram;
   private MenuItem mItemHelpResource;
   private MenuItem mItemHelpLegal;
   private MenuItem mItemHelpIntroduction;
   private MenuItem mItemHelpSignature;
   private MenuItem mItemHelpUInterface;
   private MenuItem mItemHelpFileAccess;
   private MenuItem mItemHelpCompiler;
   private MenuItem mItemHelpSpeed;
   private MenuItem mItemHelpFastList;
   private MenuItem mItemHelpMicMacTalker;
   private MenuItem mItemHelpEditBreakpoints;
   private MenuItem mItemHelpEditDump;
   private MenuItem mItemHelpEditor;
   private MenuItem mItemHelpFindDialog;
   private MenuItem mItemHelpMessageDialog;
   private MenuItem mItemHelpMicMac;
   private MenuItem mItemHelpMicMacApplet;
   private MenuItem mItemHelpMicMacCanvas;
   private MenuItem mItemHelpMicMacMake;
   private MenuItem mItemHelpMicMacSymbol;
   private MenuItem mItemHelpPrefetch;
   private MenuItem mItemHelpSimulator;
   private MenuItem mItemHelpSort;
   private MenuItem mItemHelpTokenizer;
   private MenuItem mItemHelpUtil;
   private MenuItem mItemHelpAbout;
   private MenuItem mItemHelpGottcha;




   private final String GENTLE_HELP          = "Gentle.hlp";
   private final String STARTED_HELP         = "Started.hlp";
   private final String MMINTRO_HELP         = "Mmintro.hlp";
   private final String PROGRAM_HELP         = "Program.hlp";
   private final String CONTROL_HELP         = "Control.hlp";
   private final String DEBUG_HELP           = "Debug.hlp";
   private final String MICPROG_HELP         = "Micprog.hlp";
   private final String MACPROG_HELP         = "Macprog.hlp";
   private final String RESOURCE_HELP        = "Resource.hlp";
   private final String LEGAL_HELP           = "Legal.hlp";
   private final String SIG_HELP             = "Sig.hlp";
   private final String UI_HELP              = "Ui.hlp";
   private final String FILE_HELP            = "File.hlp";
   private final String COMPILER_HELP        = "Compiler.hlp";
   private final String SPEED_HELP           = "Speed.hlp";
   private final String GOTTCHA_HELP         = "Gottcha.hlp";
   private final String INTRO_HELP           = "Intro.hlp";

   private final String FASTLIST_JAVA        = "FastList.java";
   private final String EDITBREAKPOINTS_JAVA = "EditBreakpoints.java";
   private final String EDITDUMP_JAVA        = "EditDump.java";
   private final String EDITOR_JAVA          = "Editor.java";
   private final String FINDDIALOG_JAVA      = "FindDialog.java";
   private final String MESSAGEDIALOG_JAVA   = "MessageDialog.java";
   private final String MICMAC_JAVA          = "MicMac.java";
   private final String MICMACAPPLET_JAVA    = "MicMacApplet.java";
   private final String MICMACCANVAS_JAVA    = "MicMacCanvas.java";
   private final String MICMACMAKE_JAVA      = "MicMacMake.java";
   private final String MICMACSYMBOL_JAVA    = "MicMacSymbol.java";
   private final String MICMACTALKER_JAVA    = "MicMacTalker.java";
   private final String PREFETCH_JAVA        = "Prefetch.java";
   private final String SIMULATOR_JAVA       = "Simulator.java";
   private final String SORT_JAVA            = "Sort.java";
   private final String TOKENIZER_JAVA       = "Tokenizer.java";
   private final String UTIL_JAVA            = "Util.java";





   ///////////////////////////////////////////////////////////////////
   //  Used to make the 'Control/Draw...' Checked menu options work
   //  like "radio-buttons." so that only one is on at a time.
   ///////////////////////////////////////////////////////////////////

   private void resetDrawLevelChecks( CheckboxMenuItem m, int level)
   {
      boolean wasRunning = sim.isRunning();

      if ( wasRunning)
         haltSimulation();

      Util.sleep(200);

/*
      if ( sim.isRunning()) {   // Can't change while simulation is running
         if ( m.getState())
            m.setState(false);
         else
            m.setState(true);

         return;
      }
*/

      if ( m.getState()) {
         mItemMicDrawLevel.setState(false);
         mItemMacDrawLevel.setState(false);
         mItemMinDrawLevel.setState(false);

         cpu.setRedrawLevel( level);
      }

      if ( m == mItemMinDrawLevel) {
         sim.setHighSpeed(true);
         mItemMicTrace.setState(false);
         mItemMacTrace.setState(false);
      }
      else
         sim.setHighSpeed(false);

      cpu.refreshRegisters();
      //cpu.repaint();

      m.setState(true);

      if ( wasRunning)
         runSimulation();
   }



   ////////////////////////////////////////////////////////////
   //  Setup the menubar.  Note that No-no options are grayed-
   //  out if we are "untrusted."
   ////////////////////////////////////////////////////////////

   private MenuBar setupMenus()
   {
      Menu    u, v;
      MenuBar m = new MenuBar();

      // Simulator Menu

      m.add( (u = new Menu("Programming", true)));

      u.add( (mItemExamples = v = new Menu("Examples")));
      mItemExample = new MenuItem[10];
      v.add( (mItemExample[0] = new MenuItem("Addtwo")));
      v.add( (mItemExample[1] = new MenuItem("Callsub")));
      v.add( (mItemExample[2] = new MenuItem("Direct")));
      v.add( (mItemExample[3] = new MenuItem("Stack")));
      v.add( (mItemExample[4] = new MenuItem("Inout")));
      v.add( (mItemExample[5] = new MenuItem("Local")));
      v.add( (mItemExample[6] = new MenuItem("Pascal")));
      v.add( (mItemExample[7] = new MenuItem("Loopy")));

      u.addSeparator();
      u.add( (mItemLoad    = new MenuItem("Load")));
      u.add( (mItemEdit    = new MenuItem("Edit")));
      u.add( (mItemBuild   = new MenuItem("Build")));
      
      u.add( (mItemReport  = new Menu("Report", true)));

      mItemReport.add( mItemRptSource     = new CheckboxMenuItem("Source Code"));
      mItemReport.add( mItemRptListing    = new CheckboxMenuItem("Build Listing"));
      mItemRptListing.setState(true);
      mItemReport.add( mItemRptParseTrace = new CheckboxMenuItem("Parse Trace"));
      mItemReport.add( mItemRptExecTrace  = new CheckboxMenuItem("Execution Trace"));
      mItemReport.add( mItemRptMicDump    = new CheckboxMenuItem("Mic Memory Dump"));
      mItemReport.add( mItemRptMacDump    = new CheckboxMenuItem("Mac Memory Dump"));
      mItemReport.addSeparator();
      mItemReport.add( mItemGenReport     = new MenuItem("Generate"));
      mItemReport.add( mItemGenReportAll  = new MenuItem("Generate Most"));

      u.add( (mItemSave    = new MenuItem("Save")));
      u.add( (mItemSaveAs  = new MenuItem("Save As")));


      u.addSeparator();
      u.add( (mItemExit    = new MenuItem("Exit")));


      // Control Menu

      m.add( (u = new Menu("Control", true)));
      u.add( (mItemReset    = new MenuItem("F2  Reset")));
      u.add( (mItemRun      = new MenuItem("F3  Run")));
      u.add( (mItemHalt     = new MenuItem("F4  Halt")));
      u.addSeparator();
      u.add( (mItemMicPhase = new MenuItem("F5  Mic Phase Step")));
      u.add( (mItemMicStep  = new MenuItem("F6  Mic Step")));
      u.add( (mItemMacStep  = new MenuItem("F7  Mac Step")));
      u.addSeparator();
      u.add( (mItemMacTraceOnPC = new CheckboxMenuItem( "Mac Trace on PC Change")));
      mItemMacTraceOnPC.setState(false);
      u.addSeparator();
      u.add( (mItemMicDrawLevel = new CheckboxMenuItem( "Draw All Changes - Slow")));
      mItemMicDrawLevel.setState(true);
      u.add( (mItemMacDrawLevel = new CheckboxMenuItem( "Draw Mac Only - Faster")));
      u.add( (mItemMinDrawLevel = new CheckboxMenuItem( "Draw TTY Only - Fastest")));

      // Debug Menu

      m.add( (u = new Menu("Debug", true)));
      u.add( (mItemMicBreak   = new MenuItem("Mic Breakpoints")));
      u.add( (mItemMacBreak   = new MenuItem("Mac Breakpoints")));
      u.add( (mItemClearBreak = new MenuItem("Clear Breakpoints")));
      u.add( (mItemLockBreak  = new CheckboxMenuItem("Lock Breakpoints")));
      mItemLockBreak.setState(false);
      u.addSeparator();
      u.add( (mItemMicTrace   = new CheckboxMenuItem("Mic Trace")));
      u.add( (mItemMacTrace   = new CheckboxMenuItem("Mac Trace")));
      u.add( (mItemClearTrace = new MenuItem("Clear Trace")));
      u.add( (mItemViewTrace  = new MenuItem("View Trace")));
      u.addSeparator();
      u.add( (mItemMicClear   = new MenuItem("Clear Mic Memory")));
      u.add( (mItemMacClear   = new MenuItem("Clear Mac Memory")));
      u.addSeparator();
      u.add( (mItemMicDump    = new MenuItem("Edit Mic Memory")));
      u.add( (mItemMacDump    = new MenuItem("Edit Mac Memory")));
      u.add( (mItemRegDump    = new MenuItem("Edit Registers")));


      // Help Menu

      m.add( (u = new Menu("Help")));
      u.add( (mItemHelpBenchmark    = new MenuItem("F12  Run Java Benchmark (MicMacMark)")));
      u.addSeparator();
      u.add( (mItemHelpStarted      = new MenuItem("Get Started")));
      u.add( (mItemHelpMicMacIntro  = new MenuItem("General Introduction")));
      u.add( (v = new Menu("Topics", true)));
      v.add( (mItemHelpProgramming  = new MenuItem("Programming Menu")));
      v.add( (mItemHelpControl      = new MenuItem("Control Menu")));
      v.add( (mItemHelpDebug        = new MenuItem("Debug Menu")));
      v.addSeparator();
      v.add( (mItemHelpGentle       = new MenuItem("Gentle Introduction to Computers")));
      v.add( (mItemHelpMacProgram   = new MenuItem("Mac Programming")));
      v.add( (mItemHelpMicProgram   = new MenuItem("Mic Programming")));
      v.addSeparator();
      v.add( (mItemHelpResource     = new MenuItem("Useful Resources")));
      u.add( (v = new Menu("MicMac's Source", true)));
      v.add( (mItemHelpIntroduction = new MenuItem("Code Introduction")));
      v.add( (mItemHelpSignature    = new MenuItem("Digital Signatures")));
      v.add( (mItemHelpUInterface   = new MenuItem("User Interface")));
      v.add( (mItemHelpFileAccess   = new MenuItem("File Access")));
      v.add( (mItemHelpCompiler     = new MenuItem("MicMac Compiler")));
      v.add( (mItemHelpSpeed        = new MenuItem("Speed Issues")));
      v.add( (mItemHelpGottcha      = new MenuItem("Java Gottchas")));
      v.addSeparator();
      v.add( (mItemHelpEditBreakpoints = new MenuItem( EDITBREAKPOINTS_JAVA)));
      v.add( (mItemHelpEditDump        = new MenuItem( EDITDUMP_JAVA)));
      v.add( (mItemHelpEditor          = new MenuItem( EDITOR_JAVA)));
      v.add( (mItemHelpFastList        = new MenuItem( FASTLIST_JAVA)));
      v.add( (mItemHelpFindDialog      = new MenuItem( FINDDIALOG_JAVA)));
      v.add( (mItemHelpMessageDialog   = new MenuItem( MESSAGEDIALOG_JAVA)));
      v.add( (mItemHelpMicMac          = new MenuItem( MICMAC_JAVA + " (entry point)")));
      v.add( (mItemHelpMicMacApplet    = new MenuItem( MICMACAPPLET_JAVA + " (entry point)")));
      v.add( (mItemHelpMicMacCanvas    = new MenuItem( MICMACCANVAS_JAVA)));
      v.add( (mItemHelpMicMacMake      = new MenuItem( MICMACMAKE_JAVA)));
      v.add( (mItemHelpMicMacSymbol    = new MenuItem( MICMACSYMBOL_JAVA)));
      v.add( (mItemHelpMicMacTalker    = new MenuItem( MICMACTALKER_JAVA)));
      v.add( (mItemHelpPrefetch        = new MenuItem( PREFETCH_JAVA)));
      v.add( (mItemHelpSimulator       = new MenuItem( SIMULATOR_JAVA)));
      v.add( (mItemHelpSort            = new MenuItem( SORT_JAVA)));
      v.add( (mItemHelpTokenizer       = new MenuItem( TOKENIZER_JAVA)));
      v.add( (mItemHelpUtil            = new MenuItem( UTIL_JAVA)));
      u.addSeparator();
      u.add( (mItemHelpLegal        = new MenuItem("Kudos/Legalities")));
      u.add( (mItemHelpAbout        = new MenuItem("About")));

      if ( trusted == false) {
         mItemSave.disable();
         mItemSaveAs.disable();
         mItemLoad.disable();
      }

      return m;
   }




   ////////////////////////////////////////////////////////////
   //  Load the Default Mic program, compile and start 
   //  executing it.
   ////////////////////////////////////////////////////////////

   private void loadDefaultMic()
   {
      sim.setSource( (defaultMic = blinkinLightSource("first")));
      buildSource();
      MicMacMake.clearErrorList();
      runSimulation();
   }



   ////////////////////////////////////////////////////////////
   //  Return 'Blinkin Light Demonstration Source Code
   ////////////////////////////////////////////////////////////

   private String blinkinLightSource( String label)
   {
      return   "         ac := mbr + ac;\n"+
               "         wr;\n" +
               label +
               "    sp  := pc;       { reset SP\n"+
               "         pc  := pc + 1;   { increment PC\n"+
               "         ac  := ac +(-1); { decrement AC\n"+
               "         mar := pc;\n"+
               "         mbr := ac; wr;   { write PC into memory\n"+
               "         wr;\n"+
               "         c   := mbr; rd;\n"+
               "         goto "+
               label +
               ";      { YEA! Do It Again!\n";
   }








   ////////////////////////////////////////////////////////////
   //  Build / Compile the source code.  This is a big wrapper
   //  around the MicMacMake class.  We suspend the simulator
   //  thread so that compilation can have as much CPU attention
   //  as possible.
   ////////////////////////////////////////////////////////////

   /**
    Rebuild the current source code.  This is public so that
    outside objects can trigger a rebuild.
    */

   public void buildSource()
   {
      boolean wasRunning = sim.isRunning();

      if ( wasRunning)
         haltSimulation();


      if ( sim.isAlive())
         sim.suspend();

      String s = new String("");
      String l = new String("");
      String t = new String( sim.getSource());
      int    e;

      if ( !t.endsWith("\n"))
         t += "\n";

      setStatus("Building...");

      cpu.paintNow();

      s     = MicMacMake.compile( t);
      eTime = MicMacMake.getElapstedTime();


      if ( (e = MicMacMake.getNumErrors()) == 0) {
         resetSimulation();

         
         // Handle new Mic Breakpoints

         FastList   micBP  = MicMacMake.getMicBreakpoints();
         FastList   micSBP = sim.getMicBreakpoints();

         micBP.setMultipleSelections( true);

         if ( mItemLockBreak.getState()) {
            int[] sels = micSBP.getSelectedIndexes();

            for ( int i = 0; i < sels.length; i++)
               micBP.select(sels[i]);

            sels = null;
         }

         sim.setMicBreakpoints( micBP); micSBP = null;



         // Handle new Mic Object Code

         long[] micOc  = MicMacMake.getMicObjectCode();

         sim.clearStore();

         for ( int i = 0; i < micOc.length; i++)
            sim.storeStore( i, micOc[i]);
         

         // Handle new Mac Breakpoints

         FastList  macBP = MicMacMake.getMacBreakpoints();
         FastList  macSBP = sim.getMacBreakpoints();

         macBP.setMultipleSelections( true);

         if ( mItemLockBreak.getState()) {
            int[] sels = macSBP.getSelectedIndexes();

            for ( int i = 0; i < sels.length; i++)
               macBP.select(sels[i]);

            sels = null;
         }

         sim.setMacBreakpoints( macBP); macSBP = null;



         // Handle new Mac Object Code

         int[] macOc = MicMacMake.getMacObjectCode();

         sim.clearCore();

         for ( int i = 0; i < macOc.length; i++)
            sim.storeCore( i, macOc[i]);



         setStatus("Source Built & Ready to Execute: "+((float) MicMacMake.getElapstedTime()/1000.0)+"s");
      }
      else {
         setStatus("Correct Your Errors & Rebuild.");
         editSource();
         //new Editor( this, "   View Listing:  Press F4 to find error.", 
         //            MicMacMake.reportCompilationString( s));
      }


      if ( sim.isAlive())
         sim.resume();

      if ( wasRunning) {
         resetSimulation();
         runSimulation();
      }
   }





   ////////////////////////////////////////////////////////////
   //  Clear Breakpoints.  Spin through the breakpoint
   //  FastLists, deselecting all the entries.
   ////////////////////////////////////////////////////////////

   private void clearBreakpoints()
   {
      List list;  int[] sels;

      list = sim.getMicBreakpoints();
      sels = list.getSelectedIndexes();

      for ( int i = 0; i < sels.length; i++)
         list.deselect(sels[i]);


      list = sim.getMacBreakpoints();
      sels = list.getSelectedIndexes();

      for ( int i = 0; i < sels.length; i++)
         list.deselect(sels[i]);

      sels = null;

      mItemLockBreak.setState(false);

      setStatus("Breakpoints Cleared.");
   }




   ////////////////////////////////////////////////////////////
   //  Edit the source code
   ////////////////////////////////////////////////////////////

   private void editSource()
   {
      editor = new Editor( this, this, sim);
      editor.show();
      editor.requestFocus();
   }


   
   ////////////////////////////////////////////////////////////
   //  Reset simulation
   ////////////////////////////////////////////////////////////
   
   private void resetSimulation()
   {
      sim.reset();
      setStatus("Processor Reset.");
   }




   ////////////////////////////////////////////////////////////
   //  Run simulation.  The simulator thread is nearly always
   //  going.  This just lets it do real work. (It does this
   //  by continously invoking its own "step" method -- so
   //  it single-steps continuously!)
   ////////////////////////////////////////////////////////////

   private void runSimulation()
   {
      if ( talker != null)
         talker.quiet(3000000);

      sTime = eTime = System.currentTimeMillis();
      sim.go();
      setStatus("Running...");
   }



   ////////////////////////////////////////////////////////////
   //  Halt simulation
   ////////////////////////////////////////////////////////////

   private void haltSimulation()
   {
      if ( talker != null)
         talker.quiet(30);

      if (sim.isRunning())
         sim.halt("Processor Halt.");
      else
         sim.halt("");

      eTime = System.currentTimeMillis();
      cpu.refreshRegisters();
   }


   
   ////////////////////////////////////////////////////////////
   //  Save simulation
   ////////////////////////////////////////////////////////////

   private void saveSimulation()
   {
      String d = new String( Simulator.DEFAULT_SIM_NAME + "." +
                             Simulator.DEFAULT_EXTENSION);

      if ( sim.getSourceName().equals("") || sim.getSourceName().equals(d))
         saveSimulationAs( d);
      else {
         setStatus("Saving...");
         sim.save( sim.getSourceName());
         setStatus("Simulation Saved.");
      }
   }



   ///////////////////////////////////////////////////////////////////
   //  Save simulation state (especially source code) under a given
   //  name.
   ///////////////////////////////////////////////////////////////////

   private void saveSimulationAs( String fname)
   {
      try {
         String name = sim.getSourceName();

         FileDialog d = new FileDialog( this, "Save Simulation", FileDialog.SAVE);

         d.setDirectory( homeDir);

         d.setFile( "*." + Simulator.DEFAULT_EXTENSION);

         if ( fname != null && !fname.equals(""))
            d.setFile( fname);

         d.show();

         if ( d.getFile() != null) {
            setStatus("Saving...");

            String qname = qualifyName( d.getDirectory() + d.getFile());

            if ( !(qname.endsWith(".sim") || qname.endsWith(".SIM")))
               qname += ".sim";

            sim.save( qualifyName( qname));

            setStatus("Simulation Saved.");
         }

         d.dispose();
      }
      catch (Exception e) { Util.msgBox( e.toString()); }   
   }



   ////////////////////////////////////////////////////////////
   //  Load simulation
   ////////////////////////////////////////////////////////////

   private void loadSimulation()
   {
      try {

         FileDialog d = new FileDialog( this, "Open Simulation", FileDialog.LOAD);

         d.setDirectory( homeDir);
         d.setFile( "*."+Simulator.DEFAULT_EXTENSION);

         d.show();

         if ( d.getFile() != null) {
            String name = qualifyName( d.getDirectory() + d.getFile());

            File f = new File( name);

            if ( f.exists()) {
               setStatus("Loading...");
               sim.load( name);
               setStatus("Simulation Loaded.");
            }
            else
               msgBox("Sorry, \"" + name + "\" does not exist.");
         }

         d.dispose();

         dirty = false;
      }
      catch (Exception e) { Util.msgBox( e.toString()); }
   }



   ////////////////////////////////////////////////////////////
   //  About box
   ////////////////////////////////////////////////////////////

   private void aboutMessage()
   {
      String operation = "'Untrusted,' Load/Save Disabled\nSee 'Help/Topics/Programming' for alternatives";

      if ( trusted)
         operation = "'Trusted' in " + homeDir;

      new MessageDialog( this, 
         "MicMac Microprogramming Simulator " + version + "\n" +
         "Brett Blatchley, 1997\n \n" + 
         operation + "\n \n" +
         Util.getOSVersion() + "\n" +
         Util.getJavaVersion());
   }



   ////////////////////////////////////////////////////////////
   //  Try to make our home directory
   ////////////////////////////////////////////////////////////

   private boolean makeDirectoryTest()
   {
      try {
         File f = new File(homeDir);

         if ( !f.exists())
            f.mkdir();

         homeDirSeparator = f.separator;

         return true;
      }
      catch (Exception e) { homeDir = ""; return false; }
   }



   ///////////////////////////////////////////////////////////////////
   //  Adjust a file pathname coming from the FileDialog and get
   //  around its bad habit of putting *.* on that back of anything
   //  you did'nt actually type.  HACK!
   ///////////////////////////////////////////////////////////////////

   private String qualifyName( String name)
   {
      if ( name.indexOf('.') < 0)
         name += "." + Simulator.DEFAULT_EXTENSION;

      if ( name.endsWith(".*.*"))
         return qualifyName( name.substring(0,name.length()-4));

      return name;
   }




   ///////////////////////////////////////////////////////////////////
   //  A handy way to write status information. Currently this goes
   //  to the window's title bar.
   ///////////////////////////////////////////////////////////////////

   private String setStatus( String s)
   {
      String was = getTitle();

      setTitle( "   " + s);

      return was;
   }



   
   //////////////////////////////////////////////////////////////////////
   //  Pop up a message box with the given string.  Handy for debugging
   //////////////////////////////////////////////////////////////////////

   private void msgBox( String s)
   {
      Frame f = new Frame();

      MessageDialog d = new MessageDialog( f, s);

      d.dispose();
      f.dispose();

      setStatus("");
   }




   //////////////////////////////////////////////////////////////////////
   //  Load an example file -- *.exa files.  An attempt is made to load
   //  these from the local hard disk.  If that fails, it will try to
   //  server which served the applet.
   //////////////////////////////////////////////////////////////////////

   private String loadExample( String name)
   {      
      String source = null;

      setStatus("Downloading Example: " + name + "...");

      source = Util.readFile( applet, name + ".exa");

      if ( source != null && !source.equals("")) {
         sim.setSource( defaultMic + source);

         setStatus("'" + name + 
            "' Source Loaded.  Now Edit And/Or Build, Then Run.");

         editSource();
      }
      else
         setStatus("Sorry, Example '" + name + "' Unavailable.");

      return source;
   }




   //////////////////////////////////////////////////////////////////////
   //  Clear Trace
   //////////////////////////////////////////////////////////////////////

   private void clearTrace()
   {
      sim.clearTrace();
      setStatus("Trace Cleared.");
   }


   //////////////////////////////////////////////////////////////////////
   //  View Trace
   //////////////////////////////////////////////////////////////////////

   private void viewTrace()
   {
      new Editor( this, "View Trace", sim.getTrace());
   }




   
   //////////////////////////////////////////////////////////////////////
   //  Generate Report
   //////////////////////////////////////////////////////////////////////

   private void generateReport( boolean generateAll)
   {
      String outputName = "";

      cpu.paintNow(); // this may take a while so erase the menu void

      setStatus("Generating Report...");

      if ( generateAll) {
         mItemRptListing.setState(true);
         mItemRptSource.setState(true);
         mItemRptExecTrace.setState(true);
         mItemRptMicDump.setState(true);
         mItemRptMacDump.setState(true);
      }

      String rpt = "MicMac Microprogramming Simulator " + version + "\n";

      if ( mItemRptParseTrace.getState()) {
         setStatus("Generating Report: Generating Parse Trace...");
         MicMacMake.parseTrace(true);

         MicMacMake.compile( sim.getSource());

         outputName = sim.getSourceName();
         outputName = outputName.substring(0,outputName.lastIndexOf("."));
         outputName += ".log";

         // If you want to write this to a file...

         //setStatus("Generating Report: Writing Parse Trace...");

         //Util.writeTextFile( homeDir + homeDirSeparator + outputName, 
         //   MicMacMake.getParseTrace());

         displayBigString( "Parse Trace", MicMacMake.getParseTrace());


         MicMacMake.parseTrace(false);

         System.gc();

         setStatus("Generating Report...");
      }

      if ( mItemRptSource.getState())
         rpt += "\n\n*** Combined Source ***\n\n" + sim.getSource();

      if ( mItemRptListing.getState())
         rpt += "\n\n*** Build Listing ***\n\n" + 
            MicMacMake.reportCompilationString( MicMacMake.getListing());


      // Uncomment if you want to note that the parse trace was
      // saved to disk.

      //if ( mItemRptParseTrace.getState())
      //   rpt += "\n\n*** Parse Trace ***\n\n" +
      //          "Java/AWT can't display strings this large, " +
      //          "so I wrote it to a file\ncalled '"+outputName+"' " +
      //          "in MicMac's directory on your disk.\n\n";


      if ( mItemRptExecTrace.getState())
         rpt += "\n\n*** Execution Trace ***\n\n" + sim.getTrace();

      if ( mItemRptMicDump.getState())
         rpt += "\n\n*** Microstore Dump ***\n\n" + sim.dumpStore();

      if ( mItemRptMacDump.getState())
         rpt += "\n\n*** Main Memory Dump ***\n\n" + sim.dumpCore();

      MicMacMake.parseTrace(false);

      setStatus("");

      new Editor(this, "View Report", rpt);

      rpt = null;
   }



   //////////////////////////////////////////////////////////////////////
   //  Display Help.  All the online help in MicMac is displayed with
   //  this method.
   //////////////////////////////////////////////////////////////////////

   private void displayHelp( String key, String title)
   {
      cpu.paintNow();
      haltSimulation();


      setStatus("Downloading "+title+"...");

      String s = Util.readFile( applet, key);

      if ( title == null || title.equals(""))
         title = key;

      cpu.paintNow();

      setStatus("");

      if ( s != null)
         displayBigString( "Help "+title, s);
      else
         setStatus("Sorry, '"+title+"' Help is Unavailable.");

   }



   //////////////////////////////////////////////////////////////////////
   //  Display VERY big text files (using multiple windows, if necessary)
   //  HACK!  Windows TextArea peer cannot handle more than 64k of data
   //  (not even that by my own experiments!)
   //////////////////////////////////////////////////////////////////////

   private void displayBigString( String title, String str)
   {
      if ( str != null) {

         int    len = str.length();
         int    start = 0;
         int    part;
         String partStr;

         part = len > MAX_TEXTAREA_SIZE ? 1 : 0;

         do {
            int eachLen = len > MAX_TEXTAREA_SIZE ? MAX_TEXTAREA_SIZE : len;

            if ( len > MAX_TEXTAREA_SIZE) {
               while ( str.charAt(start+eachLen) != '\n')
                  eachLen++;

               eachLen++;
            }

            partStr = part > 0 ? ", Part " + part : "";

            new Editor( this, title + partStr, str.substring( start, start+eachLen));

            len   -= eachLen;
            start += eachLen;
            part++;

         } while (len > 0);
      }
   }




   //////////////////////////////////////////////////////////////////////
   //  Run Java Benchmark.  The (soon to be legendary?) MicMacMark
   //////////////////////////////////////////////////////////////////////

   private void runJavaBenchmark()
   {
      cpu.paintNow();
      haltSimulation();
      resetSimulation();


      if ( sim.isAlive())
         sim.suspend();
      

      setStatus("Running Java Benchmark");

      long compTime = 0; int times;

      // Make a silly program to compile over and over...

      String program = "";

      for ( int i = 0; i < 15; i++) {
         program += blinkinLightSource("LABEL"+i);

         program += " mbr := a; if n then goto LABEL"+i+";\n";
         program += "HOOHA"+i+" define INST"+i+":0FF000h one:255 two:32;\n";
      }


      System.gc();

      // DrawLine Benchmark

      times = 10;

      for ( int i = 0; i < times; i++) {
         setStatus("Compute Benchmark "+(times-i));

                     MicMacMake.compile( program);
         compTime += MicMacMake.getElapstedTime();

         long sTime = System.currentTimeMillis();

         System.gc();

         compTime += System.currentTimeMillis() - sTime;
      }

      program = null;


      compTime /= times;  


      long ioTime = System.currentTimeMillis();


      // Draw Character Benchmark

      times = 10;

      for ( int i = 0; i < times; i++) {
         setStatus("Draw2 Benchmark "+(times-i));

         for ( int j = 0; j < 15; j++)
            cpu.testDraw();
      }

      
      times = 10;

      for ( int i = 0; i < times; i++) {
         setStatus("Draw1 Benchmark "+(times-i));

         for ( int j = 0; j < 15; j++)
            for ( int k = ' '; k <= '}'; k++)
               cpu.ttyChar((char) k);
      }

      ioTime = System.currentTimeMillis() - ioTime; 



      // 2404x18951 is my average for Win95/IE3.02/P120/L2 cache/24mb


      compTime = (int) Math.round((1/(compTime /  2404.0))*10);
      ioTime   = (int) Math.round((1/(ioTime   / 18951.0))*10);

      String micMacMark = compTime + "x" + ioTime;

      String standard   = "10x10 on a Win95/IExplore 3.02/P120/24mb/Cache";

      Util.msgBox( "MicMacMark = " + micMacMark +
         "  (Compute Index by Draw Index)\n\n" +
         "Plus or minus one is +/- 10% in rate.\n" +
         "Standard PC: " + standard + "\n\n" +
         Util.getJavaVersion() + "\n" + 
         Util.getOSVersion());

      resetSimulation();

      setStatus("MicMacMark: " + micMacMark+"   ("+standard+")");

      if ( sim.isAlive())
         sim.resume();
   }




   //////////////////////////////////////////////////////////////////////
   //  Set up the Gridbag constraints easier
   //////////////////////////////////////////////////////////////////////

	private void setupGBC( GridBagLayout l, Component c, int x, int y, int w, int h, int anchor, int fill) {

		GridBagConstraints con = new GridBagConstraints();

		con.gridx      = x;
		con.gridy      = y;
		con.gridwidth  = w;
		con.gridheight = h;
		con.anchor     = anchor;
		con.fill       = fill;

		add( c);

		l.setConstraints(c, con);
	}
}


