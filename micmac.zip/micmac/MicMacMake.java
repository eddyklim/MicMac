import java.io.File;
import java.io.IOException;
import java.io.StringBufferInputStream;
import java.io.FileInputStream;

import java.util.StringTokenizer;
import java.util.Stack;

import java.awt.List;


//////////////////////////////////////////////////////////////////////
//
//  Compile a Mic program in modified 'Tanenbaum' form.  Tanenbaum's 
//  mal programs will compile as written; I add symbolic addresses 
//  (labels) and mac instruction definitions (for the mac assembler).
//
//  The parsing method relies on the Tokenizer class and is of the
//  recursive-descent in nature.
//
//  This class is not meant to be instantiated.
//
//  You can run this compiler from the command line (outside of
//  the IDE) if you wish -- see main() for details.
//
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 Compiles MicMac programs.  Class methods only, do not instantiate.
 @see MicMac
 */

public class MicMacMake extends Object
{
   ///////////////////////////////////////////////////////////////////
   //  THERE ARE NO CONSTRUCTORS -- DO NOT INSTANTIATE
   ///////////////////////////////////////////////////////////////////
   

   ///////////////////////////////////////////////////////////////////
   //  Give Mic source code, compile it and return a listing.
   //  The object code may be extraced/loaded from this listing.
   ///////////////////////////////////////////////////////////////////

   /**
    Compile the given MicMac source code.
    @param source String containing MicMac source code.
    */

   public static String compile( String source)
   {
      long start = System.currentTimeMillis();

      listing    = "";
      errorList  = "";
      parseTrace = new StringBuffer("");
      parseMode  = MIC_MODE;

      installKeywords();

      listing = Util.arrayToString( micParse(source));

      elapstedTime = System.currentTimeMillis() - start;

      return listing;
   }



   ///////////////////////////////////////////////////////////////////
   //  Take a plain listing string (from the compile routine) and
   //  doll it up.
   ///////////////////////////////////////////////////////////////////

   /**
    Write an improved compilation listing to standard output.
    @param listing Listing string produced by compile().
    */

   public static void reportCompilation( String listing)
   {
      System.out.print( reportCompilationString( listing));
   }



   ///////////////////////////////////////////////////////////////////
   //  Given a listing string, Return it in a fancier and easer form
   //  to read.
   ///////////////////////////////////////////////////////////////////

   /**
    Return a fancier version of the compilation listing returned
    from compile().
    @param listing Listing string from compile().
    @return Fancier listing string.
    */

   public static String reportCompilationString( String listing)
   {
      String l = new String("");

      int error = MicMacSymbol.lookupSpecialValue( ERROR_COUNT);  

      l += "\nMic Compilation:  "+lineno+" Source";

      if (lineno == 1)
         l += " line, ";
      else
         l += " lines, ";

      if ( error == 1)
         l += "with "+error+" error, ";
      else
         l += "with "+error+" errors, ";

      l += elapstedTime + "ms elapsted time.\n";

      if ( parseTraceEnable)
         l += "\nParse trace follows listing...\n";

      l += "\n";

      l += "  Adr X CD AL SH BARWE   C    B    A  Jmp-Addr  ";

      if ( parseTraceEnable)
         l += "Line";

      l += "\n\n" + listing + "\n";

      l += "\n   Mic Symbols:\n";
      l += MicMacSymbol.listTable( MicMacSymbol.MIC_SYMBOL, 6, 4, 16) + "\n";

      l += "\n   Mac Symbols:\n";
      l += MicMacSymbol.listTable( MicMacSymbol.MAC_SYMBOL, 6, 4, 16) + "\n";

      if ( parseTraceEnable) {
         l += "\nParse tracing...\n\n";
         l += "Line >into rule, <out of rule, <TOKEN>, remark\n\n";
         l += parseTrace.toString() + "\n";
         l += "trace concluded.\n";
      }

      return l;
   }




   ///////////////////////////////////////////////////////////////////
   //  Turn parse tracing on/off.  This is quite time consuming but
   //  very enlightening.
   ///////////////////////////////////////////////////////////////////

   /**
    Set parse tracing on if true, otherwise, off.
    @param flag New state of parse tracing.
    */

   public static void parseTrace( boolean flag)
   {
      parseTraceEnable = flag;
   }



   ///////////////////////////////////////////////////////////////////
   // Give outsiders access to the object code & new breakpoints
   ///////////////////////////////////////////////////////////////////

   /**
    Return the Mic object code produced by compile().
    @return Microstore image of the Mic object code.
    */

   public static long[]   getMicObjectCode()   { return micObjectCode; }


   /**
    Return the Mac object code produced by compile().
    @return Memory image of the Mic object code.
    */

   public static int[]    getMacObjectCode()   { return macObjectCode; }

   /**
    Return the number of errors in the last compile.
    @return Number of errors in the last compile.
    */

   public static int      getNumErrors()       { return numErrors; }


   /**
    Return the amount of time in milliseconds required by the last compile.
    @return Elapsted time for compile() in milliseconds.
    */

   public static long     getElapstedTime()    { return elapstedTime; }


   /**
    Return the current Mic breakpoint list.
    @return Current Mic breakpoint list.
    */

   public static FastList getMicBreakpoints()  { return micBreakpoints; }


   /**
    Return the current Mac breakpoint list.
    @return Current Mac breakpoint list.
    */

   public static FastList getMacBreakpoints()  { return macBreakpoints; }


   /**
    Return the listing of the last compile().
    @return Lastest compilation listing.
    */

   public static String   getListing()         { return listing; }




   /**
    Return the error listing of the last compile().
    @return Lastest compilation error listing.
    */

   public static String   getErrorList()       { return errorList; }





   /**
    Return the latest parse trace results from compile().
    @return Latest parse tracing.
    */

   public static String   getParseTrace()      { return parseTrace.toString(); }



   /**
    Clear the error list from the latest compile().
    */

   public static String   clearErrorList()     { return errorList = null; }



   ///////////////////////////////////////////////////////////////////
   //  Command line compiler
   //
   //  usage:  java MicMacMake [-t] programSourcePath ...
   ///////////////////////////////////////////////////////////////////

   /**
    Invoke the MicMac compiler from the host operating system command line:<br>
    usage: <tt><b>java MicMacMake [-t] programSourcePath</b></tt><br>
    where: <b><tt>-t</tt></b> Produces a parse tracing.
    */

   public static void main( String args[])
   {
      // Process global args...

      for ( int i = 0; i < args.length; i++)
         if ( args[i].equals("-t"))
            parseTraceEnable = true;


      if ( args.length < 1) {
         System.out.println("\nusage:  java MicMake [-t] micSourcePath ...\n");
      }
      else {
         for ( int i = 0; i < args.length; i++) {

            if ( args[i].equals("-t"))
               continue;

            // Read & translate each file, sending the listing to stdout
            try {
               File f = new File( args[i]);

               FileInputStream is = new FileInputStream( f);

               byte[] buff = new byte[ (int) f.length()]; // max file size
   
               is.read( buff);   is.close();
   

               reportCompilation( compile( new String( buff, 0)));
            }
            catch (Exception e) { System.out.println(e); }
         }
      }
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Private Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   private static final int NUMBER = Tokenizer.TT_NUMBER;
   private static final int WORD   = Tokenizer.TT_WORD;
   private static final int EOL    = Tokenizer.TT_EOL;
   private static final int EOF    = Tokenizer.TT_EOF;

   private static final int PLUS    = '+';
   private static final int MINUS   = '-';
   private static final int MULT    = '*';
   private static final int DIV     = '/';
   private static final int EQUALS  = '=';
   private static final int LPAREN  = '(';
   private static final int RPAREN  = ')';
   private static final int SEMI    = ';';
   private static final int COLIN   = ':';
   private static final int COMMA   = ',';
   private static final int COMMENT = '{';

   private static final int PC        =  1;
   private static final int AC        =  2;
   private static final int SP        =  3;
   private static final int IR        =  4;
   private static final int TIR       =  5;
   private static final int AMASK     =  6;
   private static final int SMASK     =  7;
   private static final int A         =  8;
   private static final int B         =  9;
   private static final int C         = 10;
   private static final int D         = 11;
   private static final int E         = 12;
   private static final int F         = 13;
   private static final int ALU       = 14;
   private static final int MAR       = 15;
   private static final int MBR       = 16;
   private static final int LSHIFT    = 17;
   private static final int RSHIFT    = 18;
   private static final int BAND      = 19;
   private static final int INV       = 20;

   private static final int IF        = 21;
   private static final int GOTO      = 22;
   private static final int THEN      = 23;
   private static final int RD        = 24;
   private static final int WR        = 25;
   private static final int DEFINE    = 26;
   private static final int MICHALT   = 27;

   private static final int UNDEFINED = 0x10000;
   private static final int MIC_MODE  = 0x20000;
   private static final int MAC_MODE  = 0x40000;

   private static final int SYM_UNDEFINED = MicMacSymbol.UNDEFINED;


   private static final long A_BUS_USED = 0x0100000000l;  // Masked with long instruction
   private static final long B_BUS_USED = 0x0200000000l;  // to track bus usage
   private static final long ALU_USED   = 0x0400000000l;
   private static final long SHIFT_USED = 0x4000000000l;
   private static final long GEN_CODE   = 0x8000000000l;


   private static final String ERROR_COUNT = "_ERRORS_";  // Reserved keywords in the symbol
   private static final String ERROR_TEXT  = "_ERROR_";   // table for transitory values.

   private static int numErrors;  // number of compile errors

   private static int     margin = 0;                // for parse trace spacing
   private static String  marginStr = new String("                                                  ");

   private static boolean parseTraceEnable = false;

   private static int parseMode = MIC_MODE;

   private static Stack     stack;
   private static int       lineno;

   private static String       listing;
   private static String       errorList;
   private static StringBuffer parseTrace;
   private static long         elapstedTime;

   private static long[] micObjectCode = null;
   private static int[]  macObjectCode = null;

   private static FastList   micBreakpoints = null;
   private static FastList   macBreakpoints = null;

   private static int micLocation;
   private static int macLocation;
   private static int srcLocation;

   private static String fixups;




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //
   //                       Parser & Rules
   //
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////


   ///////////////////////////////////////////////////////////////////
   //  Parse a Mic program using the Recursive-Descent technique.
   //
   //  The opbject code is returned embedded in the listing.  The 
   //  listing is a string array.
   //
   //  For the purposes of parsing, the statement is the main unit of
   //  consideration.  However, for code generation, each line 
   //  represents a single instruction and all the statements combined
   //  form it. So from a linguistic perspective this is a compiler, 
   //  but from a code generation perspective it is more like an 
   //  assembler.
   //
   //  In general, the source looks like:
   //
   //     [<label> COLIN ] (<statement> SEMI)* EOL
   //
   //  Associating the object code and any errors with the original
   //  source line presents some complication to which most of this
   //  routine is dedicated.
   //
   //  The parser passed over the source only once, placing any forward
   //  jump references into the fix list.  Once the parse is compile,
   //  a fixup pass finishes generating any incomplete Mic instructions.
   //
   //  Source to object (and error) association is maintained by a
   //  matchup table in the case of source and ERROR_TEXT symbols in 
   //  the case of errors.  A spin through both sets of elements lets
   //  us connect each source line with its appropriate object line and
   //  possible errors.
   //
   //  Data bus allocation is somewhat of a problem on this machine (as
   //  it often is in real machines).  Several operations demand their
   //  operand on one bus or another.  Since potentially several 
   //  operations may occur in the same instruction (statements on the
   //  same source line) some conflicts will come up from time to time.
   //  The basic strategy is to defer any register to bus allocations
   //  where the bus is not important.  For those where the bus is 
   //  important they are taken care of on a first-come-first-served
   //  basis -- any conflicts are naturally fatal, so it does not matter
   //  what order they arrive!  When the finicky operations are done, 
   //  all the flexible operands are assigned with the remaining 
   //  resources.
   ///////////////////////////////////////////////////////////////////

   private static StringBuffer[] micParse( String source)
   {
      if ( source == null || source.equals(""))
         return null;

      String[]        sourceList  = Util.stringToArray( source);

      String[]        _listing     = new String[ sourceList.length];
      StringBuffer[]  listing     = new StringBuffer[ sourceList.length];
      int[]           matchup     = new int[    sourceList.length];

      long[]          micInstr    = new long[   sourceList.length];
      int[]           macInstr    = new int[    sourceList.length];

      Tokenizer t           = initMicLexer( source);
      

      numErrors = lineno = 0;   fixups = "";

      micLocation = 0;
      macLocation = 0;
      srcLocation = 0;

      try {
         while ( !token( t, EOF) && lineno < sourceList.length) {

            matchup[ lineno] = UNDEFINED | parseMode;

            parseTracer( t, "BEGIN LINE: "+sourceList[ lineno], true, 0);

            srcLocation = lineno;

            if ( !parsePseudoOp( t, micLocation, micInstr)) {

               switch ( parseMode) {
                  case MIC_MODE: if ( parseStatements( t, micLocation, micInstr))
                                    matchup[ lineno] = MIC_MODE | micLocation++;
                                 break;

                  case MAC_MODE: if ( parseMacLine( t, macLocation, macInstr))
                                    matchup[ lineno] = MAC_MODE | macLocation++;
                                 break;
               }
            }

            lineno++;
         }
      }
      catch( Exception e) 
      { 
         System.out.println("micParse, Internal Error: "+t.lineno()+" "+e); 
         e.printStackTrace( System.out);
         return null;
      }



      fixupPass( fixups, micInstr, macInstr, sourceList);



      // Save the Object code

      micObjectCode = new long[micLocation];

      for ( int i = 0; i < micLocation; i++)
         micObjectCode[i] = micInstr[i] & 0xFFFFFFFFl;

      macObjectCode = new int[macLocation];

      for ( int i = 0; i < macLocation; i++)
         macObjectCode[i] = macInstr[i] & 0xFFFF;




      // Build the listings...

      micBreakpoints = new FastList();
      macBreakpoints = new FastList();
   

      int addr, lastMacAddr = 0;  long in;  int errors = 0;   
      
      String error, key, modeStr = "";

      StringBuffer listLine   = null;
      StringBuffer linenoStr  = null;
   


      // Format the Mac listing

      for ( int i = 0; i < matchup.length; i++) {

         addr = matchup[i];

         listLine = null;    listLine = new StringBuffer(512);
         
         listing[i] = new StringBuffer(128);


         modeStr = "@ ";

         if ( (addr & MIC_MODE) > 0)
            modeStr = "! ";


         linenoStr = null;   linenoStr = new StringBuffer(16);

         if ( parseTraceEnable) {
            linenoStr.append( "  ");
            linenoStr.append( Util.format("-03d", i));
            linenoStr.append( "  ");
         }



         if ( sourceList[i].endsWith("\r"))
            listLine.append( Util.expandTabs( sourceList[i].substring(0,sourceList[i].length()-1), 8));
         else        
            listLine.append( Util.expandTabs( sourceList[i], 8));



         if ( (addr & UNDEFINED) > 0) {
            listing[i].append( modeStr);
            listing[i].append( Util.format( "45s", " "));
            listing[i].append( linenoStr);
            listing[i].append( listLine);
         }
         else


         if ( (addr & MIC_MODE) > 0) {

            addr &= 0xFFFF;

            micInstr[ addr] &= 0xFFFFFFFFl; // strip the BUS_USED bits off the instruction word

            in = micInstr[ addr];

            listing[i].append( modeStr);
            listing[i].append( Util.format( "-04d ", addr));
            listing[i].append( Util.format( "-02b ", ((in & 0x80000000l) >> 31)));
            listing[i].append( Util.format( "-03b ", ((in & 0x60000000l) >> 29)));
            listing[i].append( Util.format( "-03b ", ((in & 0x18000000l) >> 27)));
            listing[i].append( Util.format( "-03b ", ((in & 0x06000000l) >> 25)));
            listing[i].append( Util.format( "-06b ", ((in & 0x01F00000l) >> 20)));
            listing[i].append( Util.format( "-05b ", ((in & 0x000F0000l) >> 16)));
            listing[i].append( Util.format( "-05b ", ((in & 0x0000F000l) >> 12)));
            listing[i].append( Util.format( "-05b ", ((in & 0x00000F00l) >>  8)));
            listing[i].append( Util.format( "-09b ",  (in & 0x000000FFl)));
            listing[i].append( linenoStr.toString());
            listing[i].append( listLine);

            micBreakpoints.addItem( Util.format("-05d: ", addr)+listLine.toString(), addr);
         }


         else
         if ( (addr & MAC_MODE) > 0) {

            addr &= 0xFFFF;    in = macInstr[ addr];
      
            listing[i].append( modeStr);
            listing[i].append( Util.format( "-05d ", addr));
            listing[i].append( Util.format( "-05b ", ((in & 0xF000) >> 12)));
            listing[i].append( Util.format( "-05b ", ((in & 0x0F00) >>  8)));
            listing[i].append( Util.format( "-05b ", ((in & 0x00F0) >>  4)));
            listing[i].append( Util.format( "-05b ",  (in & 0x000F)));
            listing[i].append( Util.format( "20s", " "));
            listing[i].append( linenoStr.toString());
            listing[i].append( listLine);

            macBreakpoints.addItem( Util.format( "-06d: ", addr)+listLine.toString(), addr);
         }


         // List error(s), if any on this line

         if ( (error = MicMacSymbol.lookupSpecialText(ERROR_TEXT+i)) != null) {
            errors++;

            StringTokenizer et = new StringTokenizer( error, "\r\n");

            while ( et.hasMoreTokens()) {
               String etok = et.nextToken();


               if ( etok.startsWith("ERROR: "))
                  addErrorList( etok.substring(7), sourceList[i], false);
               else
                  addErrorList( etok, sourceList[i], false);
            }

            listing[i].append( '\n');
            listing[i].append( error);
         }

      }


      MicMacSymbol.insertSpecial(ERROR_COUNT, errors);


      return listing;
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE:  <pseudo-op> ::= ( <define> | "micparse" | "macparse" )
   //                           SEMI EOL 
   //
   //  The place for statements that do not generate code.
   //  Pseudo-op statements exist one to a line.
   ///////////////////////////////////////////////////////////////////

   private static boolean parsePseudoOp( Tokenizer t, int location, long[] instr) throws IOException
   {
      parseBegin( t, "pseudo op");

      if ( parseDefine( t, location, instr) &&
           token( t, SEMI)) {

         eatTo( t, EOL);
         token( t, EOL);

         return parseEnd( t, "define pseudo-recognized", true);
      }
      else
      if ( token( t, "micparse") &&
           token( t, SEMI)) {

         parseMode = MIC_MODE;
         eatTo( t, EOL);
         token( t, EOL);
         return parseEnd( t, "micparse pseudo-recognized", true);
      }
      else
      if ( token( t, "macparse") &&
           token( t, SEMI)) {

         parseMode = MAC_MODE;
         eatTo( t, EOL);
         token( t, EOL);
         return parseEnd( t, "macparse pseudo-recognized", true);
      }

      return parseEnd( t, "not a pseudo-op", false);
   }





   ///////////////////////////////////////////////////////////////////
   //  RULE: <label> ::= <word> COLIN
   //
   //  Labels are the first structure on a line, and they are optional
   //  Parsed labels are inserted into the symbol table along with the
   //  current value of the location counter.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseLabel( Tokenizer t, int location) throws IOException
   {
      parseBegin( t, "label");

      if ( token( t, "")) {

         if ( MicMacSymbol.lookupMicKeywordValue( t.sval) == SYM_UNDEFINED &&
              MicMacSymbol.lookupMicSymbol( t.sval) == SYM_UNDEFINED) {

            MicMacSymbol.insertMicSymbol( t.sval, location);

            if ( !token( t, COLIN))
               t.pushBack();

            return parseEnd( t, "label found", true);

         }
         else
            t.pushBack();
      }

      return parseEnd( t, "not a label", true);
   }




   ///////////////////////////////////////////////////////////////////
   //  RULE: <statements> ::= [<label>] <statement>* EOL
   //
   //  One or more statements per line which may begin with a label.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseStatements( Tokenizer t, int location, long[] instr) throws IOException
   {
      parseBegin( t, "statements");

      instr[ location] = 0;

      parseLabel( t, location);   // each line may have a label

      while (!token( t, EOL))
         if ( !parseStatement( t, location, instr))
            eatTo( t, EOL);


      // assign uncommitted registers to buses

      flexibleRegisterAssignment( instr, location);



      if ( (instr[ location] & GEN_CODE) > 0)
         return parseEnd( t, "statements recognized", true);

  
      return parseEnd( t, "not statements", false);
   }




   ///////////////////////////////////////////////////////////////////
   //  RULE: <statement> ::= <assignment>|<conditional>|<branch>|
   //                        <action>|<define> SEMI
   //
   //  <define> is a pseudo-statement; the parser should recognize it
   //  but not acknowledge that it is a valid statement.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseStatement( Tokenizer t, int location, long[] instr) throws IOException
   {
      parseBegin( t, "statement");

      if ( (parseAssignment ( t, location, instr)  ||
            parseConditional( t, location, instr)  ||
            parseBranch     ( t, location, instr)  ||         
            parseAction     ( t, location, instr)) &&
            token( t, SEMI)) {

         instr[ location] |= GEN_CODE;

         return parseEnd( t, "statement recognized", true);
      }

      error("Syntax error near: "+tokenToString(t));

      return parseEnd( t, "not a statement", false);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE: <action> ::= "rd" | "wr" | "halt"
   //
   //  Actions have no parameters (so there're easy to parse!).  
   //  We only have three at the moment: RD, RW & HALT.  Generating 
   //  code is easy too.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseAction( Tokenizer t, int location, long[] instr) throws IOException
   {
      parseBegin( t, "action");
  
      if ( token( t, "rd")) {
         instr[ location] |= 0x00400000;                     // set the RD bit
         return parseEnd( t, "action(rd) recognized", true);
      }
      else
      if ( token( t, "wr")) {
         instr[ location] |= 0x00200000;                     // set the WR bit 
         return parseEnd( t, "action(wr) recognized", true);
      }
      else
      if ( token( t, "halt")) {
         instr[ location] |= 0x06000000;                       // uset the "Unused" shift code 3
         return parseEnd( t, "action(halt) recognized", true); // to implement the halt function
      }

      return parseEnd( t, "not an action", false);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE: <assignment> ::= <register> COLIN EQUALS <shift> | 
   //                         <function>
   //
   //  It doesn't look like it here, but this is where most of most 
   //  of the effort has been expended.                
   ///////////////////////////////////////////////////////////////////

   private static boolean parseAssignment( Tokenizer t, int location, long[] instr) throws IOException
   {
      parseBegin( t, "assignment");
      
      if ( !parseRegister( t, location, instr))
         return parseEnd( t, "not an assignment", false);


      boolean destMAR = false;
      int     dest    = 0;


      switch ( (dest = MicMacSymbol.lookupMicKeywordValue( t.sval))) {

         case MAR: destMAR = true;  
                   instr[ location] |= 0x00800000l;    break;

         case MBR: instr[ location] |= 0x01000000l;    break;
         case ALU:                                     break;

         default:  instr[ location] |= 0x00100000l | ((registerAddr( dest) << 16) & 0x000F0000l);
      }


      if ( !token( t, COLIN))
         parseEnd( t, "not an assignment", false);

      if ( !token( t, EQUALS))
         parseEnd( t, "not an assignment", false);
         

      if ( parseShift(    t, location, instr))
         return parseEnd( t, "assignment recognized", true);
      else
      if ( parseFunction( t, location, instr, destMAR))
         return parseEnd( t, "assignment recognized", true);

      return parseEnd( t, "not an assignment", false);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE:  <operand> ::= <constant> | <register>
   //
   //  Put the operand on the operand stack.
   //  If the operand is MBR, set the AMUX bit in the instruction.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseOperand( Tokenizer t, int location, long[] instr) throws IOException
   {
      parseBegin( t, "operand");
      
      if ( parseConstant( t, location, instr)   ||
           parseRegister( t, location, instr)) {

         int addr;

         if ( t.ttype == NUMBER) {  // constant registers

            switch ((int) t.nval) {
               case  1: t.sval = "Constant +1"; addr = 6; break;
               case -1: t.sval = "Constant -1"; addr = 7; break;
               case  0:
               default: t.sval = "Constant 0";  addr = 5;
            }
         }
         else
            addr = registerAddr( MicMacSymbol.lookupMicKeywordValue( t.sval));
 
         // Now that we know the register involved...


         stack.push((Object) new Integer(addr));


         if ( addr == MBR) {
            instr[ location] |= 0x80000000l; // set AMUX on

            installAddr( instr, location, A_BUS_USED);  // pops operand off the stack
         }

         return parseEnd( t, "recognized an operand", true);
      }

      return parseEnd( t, "not an operand", false);
   }




   ///////////////////////////////////////////////////////////////////
   //  RULE:  <constant> ::= 0 | 1 | LPAREN MINUS 1 RPAREN
   //
   //  There are only three constants in this grammer and they 
   //  represent the three constant registers 0, +1 and -1 in the Mic
   //  architecture. Statements that look like arithmetic are actual
   //  the addion of one of these three constants -- so much for 
   //  expression evalution!
   ///////////////////////////////////////////////////////////////////

   private static boolean parseConstant( Tokenizer t, int location, long[] instr) throws IOException
   {
      parseBegin( t, "constant");
      
      if ( token( t, LPAREN) &&    // -1 constant
           token( t, MINUS)  &&
           token( t, 1.0)    &&
           token( t, RPAREN)) {

         t.nval = -1;  t.ttype = NUMBER;

         return parseEnd( t, "recognized -1 constant", true);
      }

      if ( token( t, 0.0)) {
         if ( t.nval == 1)
            return parseEnd( t, "recognized +1 constant", true);
         else
         if ( t.nval == 0)
            return parseEnd( t, "recognized 0 constant", true);

         return parseEndPushBack( t, "not a valid constant", false);
      }

      return parseEnd( t, "not a constant", false);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE:  <register> ::= <word>
   //
   //  Not just any <word>, but one that is a register reserve word
   //  in the symbol table!
   ///////////////////////////////////////////////////////////////////

   private static boolean parseRegister( Tokenizer t, int location, long[] instr) throws IOException
   {
      parseBegin( t, "register");

      if ( token( t, "")) {
         int value = MicMacSymbol.lookupMicKeywordValue( t.sval);

         if ( isRegister( MicMacSymbol.lookupMicKeywordValue( t.sval)))
            return parseEnd( t, "recognized register", true);
         else
            return parseEndPushBack( t, "not a valid register", false);
      }

      return parseEnd( t, "not a register", false);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE:  <sum> ::= "sum" ( <operand> | PLUS <operand>)
   //
   //  This covers a simple assignment (passthrough the ALU) as well
   //  as ALU addition.  Negative numbers exist only in the form of
   //  the -1 constant (see parseConstant()).
   //
   //  Since addition is communitive, it does not matter which 
   //  register is gated to which bus -- so defer this to the 
   //  flexibleRegister() phase.  If MBR is an operand, then MBR 
   //  requires the A bus.
   //
   //  However, simple assignment DOES require the A bus, because 
   //  that's where the ALU expects its operand for this operation.
   //  This does commit the bus.  Likewise, assignments to MAR 
   //  require the B bus.
   ///////////////////////////////////////////////////////////////////
   
   private static boolean parseSum( Tokenizer t, int location, long[] instr, boolean destMAR) throws IOException
   {
      parseBegin( t, "sum");

      if ( !parseOperand( t, location, instr))
         return parseEnd( t, "not a sum", false);


      if ( token( t, PLUS)) {
         if ( parseOperand( t, location, instr)) {

            if ( (instr[ location] & ALU_USED) != 0)
               error("ALU already in use: add");
      
            instr[ location] |= 0x00000000 | ALU_USED;  // addition in ALU

            // Keep the operands on the stack, we will assign them to
            // a bus last since it does not matter which bus either
            // operand is assigned to.

            return parseEnd( t, "recognized sum of 2 operands", true);
         }

         return parseEnd( t, "not a sum", false);
      }


      // Assign pass-through code to ALU

      if ((instr[ location] & ALU_USED) != 0)
         error("ALU already in use: add");
      
      if ( !destMAR)
         instr[ location] |= 0x10000000 | ALU_USED;  // pass-through in ALU
  

      if ( destMAR) {
         // We are forced to use the B bus to load the Memory Address Register

         installAddr( instr, location, B_BUS_USED);  // pops operand off the stack
      }
      else 
      if ( (instr[location] & 0x80000000l) == 0) {
         // We are forced to use the A bus for a "pass-through" operation
         // which does not involve MBR.  (MBR operand has already forced the A Bus.)

         instr[ location] |= 0x10000000 | ALU_USED;  // pass through in ALU

         installAddr( instr, location, A_BUS_USED);  // pops operand off the stack
      }

      return parseEnd( t, "recognized sum of 1 operand", true);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE:  <commaSequence> ::= <operand> COMMA <operand>
   //
   //  The band() operation is a function requiring 2 operands in the
   //  form parsed by this rule.  Since AND (band) is communitve, it
   //  matters not which bus gets what register, so we defer this 
   //  decision.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseCommaSequence( Tokenizer t, int location, long[] instr) throws IOException
   {
      parseBegin( t, "sum");
      
      if ( !parseOperand( t, location, instr))
         return parseEnd( t, "not a comma sequence", false);

      long a = (long) t.nval;

      if ( !token( t, COMMA))
         return parseEnd( t, "not a comma sequence", false);

      if ( !parseOperand( t, location, instr))
         return parseEnd( t, "not a comma sequence", false);

      long b = (long) t.nval;


      // Keep the operands on the stack, we will assign them to
      // a bus last since it does not matter which bus either
      // operand is assigned to.

      return parseEnd( t, "recognized a comma sequence", true);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE:  <function> ::= <band> | <inv> | <sum>
   //
   //  Notice that we pass in a flag denoting an assignment to MAR
   //  since this has an effect how the operand will be processed in
   //  parseSum()
   ///////////////////////////////////////////////////////////////////

   private static boolean parseFunction( Tokenizer t, int location, long[] instr, boolean destMAR) throws IOException
   {
      parseBegin( t, "function");

      if ( parseBand(  t, location, instr) ||
           parseInv(   t, location, instr) ||
           parseSum(   t, location, instr, destMAR )) { 

         return parseEnd( t, "function recognized", true);
      }

      return parseEnd( t, "not a function", false);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE:  <shift> ::= ("lshift" | "rshift") LPAREN <function> 
   //                     RPAREN
   //
   //  Though Tanenbaum does note point this out, shifting may be 
   //  combined with ALU operations, since the shifter is a seperate 
   //  component in the Mic architecture:   lshift(band(a,ir))   
   //  is valid, for example.
   //
   // Generate the appropriate shift in the instruction and note
   // that the shifter is in use.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseShift( Tokenizer t, int location, long[] instr) throws IOException
   {
      parseBegin( t, "shift");

      if ( !token( t, "lshift") && !token( t, "rshift"))
         return parseEnd( t, "not a shift", false);

      long shift = t.sval.charAt(0) == 'l' ? 0x04000000 : 0x02000000;

      if ( token( t, LPAREN)   &&
           parseFunction( t, location, instr, false) && /* can't write to MAR from here */
           token( t, RPAREN)) {

         if ( (instr[ location] & SHIFT_USED) != 0)
            error("ALU already in use: band()");
      
         instr[ location] |= shift | SHIFT_USED;  // shift in ALU

         return parseEnd( t, "shift recognized", true);
      }

      return parseEnd( t, "not a shift", false);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE:  <band> ::= "band" LPAREN <commaSequence> RPAREN
   //
   // This encodes the ALU's AND function.
   //
   // Generate the AND ALU operation and note that ALU is in use.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseBand( Tokenizer t, int location, long[] instr) throws IOException
   {
      parseBegin( t, "band");

      if ( token( t, "band") &&
           token( t, LPAREN) &&
           parseCommaSequence( t, location, instr) &&
           token( t, RPAREN)) {

         if ( (instr[ location] & ALU_USED) != 0)
            error("ALU already in use: band()");
      
         instr[ location] |= 0x08000000 | ALU_USED;  // band in ALU

         return parseEnd( t, "band recognized", true);
      }

      return parseEnd( t, "not a band", false);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE:  <inv> ::= "inv" LPAREN <operand> RPAREN
   //
   // This is Mic NOT or INVerse function.
   //
   // Generate the ALU code and mark the ALU as in-use.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseInv( Tokenizer t, int location, long instr[]) throws IOException
   {
      parseBegin( t, "inv");

      if ( token( t, "inv")  &&
           token( t, LPAREN) &&
           parseOperand( t, location, instr) &&
           token( t, RPAREN)) {

         if ( (instr[ location] & ALU_USED) != 0)
            error("ALU already in use: inv()");
      
         instr[ location] |= 0x18000000 | ALU_USED;

         // We must commit A bus NOW... (Unless we have a memory operand, then it's 
         // already been commited in parseOperand

         if ( (instr[location] & 0x80000000l) == 0)
            installAddr( instr, location, A_BUS_USED); // pops operand off the stack

         return parseEnd( t, "inv recognized", true);
      }

      return parseEnd( t, "not an inv", false);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE:  <conditional> ::= "if" ("n" | "z") "then" <branch>
   //
   //  Here is our 'if' statement.
   //
   //  Notice how we have to mask some of the effects of 
   //  parseBranch().  when we generate the appropriate instruction
   //  bits.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseConditional( Tokenizer t, int location, long[] instr) throws IOException
   {
      parseBegin( t, "conditional");

      if ( !token( t, "if"))
         return parseEnd( t, "not a conditional", false);

      if ( !token( t, "z") && !token( t, "n"))
         return parseEnd( t, "not a conditional", false);


      // save the condition bits for later application...

      int condition = t.sval.equals("n") ? 0x20000000 : 0x40000000;

      if ( token( t, "then") &&
           parseBranch( t, location, instr)) {

         instr[ location] &= 0xFFF9FFFFFFFl;  // parseBranch() sets condition to unconditional
         instr[ location] |= condition;       // we want a conditional branch here.

         return parseEnd( t, "conditional recognized", true);
      }

      return parseEnd( t, "not a conditional", false);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE:  <branch> ::= "goto" (<number> | <word>)
   //
   //  <number> represents a literal address in the microstore.  
   //  <word> represents a symbolic address.
   //
   //  Recognize & generate code for an UNCONDITIONAL branch.  If the
   //  branch is literal, simple insert the masked value into the \
   //  address field of the current instruction.  If the address is
   //  symbolic, put its masked value into address field.  If the 
   //  symbol is undefined, add it to the fixup list for later 
   //  resolution.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseBranch( Tokenizer t, int location, long[] instr) throws IOException
   {
      parseBegin( t, "branch");

      // Recognize the "goto" keyword...

      if ( !token( t, "goto"))
         return parseEnd( t, "not a branch", false);


      instr[location] |= 0x60000000; // jump always


      // Recognize the branch address...

      if ( token( t, 0.0)) {

         instr[location] |= 0x000000FF & (int) t.nval;  // literal address

         return parseEnd( t, "branch recognized", true);
      }
      else
         if ( token( t, "")) {                          // symbolic address

         int addr = MicMacSymbol.lookupMicSymbol( t.sval);

         if ( addr == SYM_UNDEFINED)
            //            mic fixups always add the symbols value to the lower 8 bits
            //            of the Mic instruction (address field).
            fixups += "MIC|" + t.sval + "|+|" + location + "|255|0|i|"+srcLocation+"|";
         else
            instr[location] |= 0x000000FF & addr;

         return parseEnd( t, "branch recognized", true);
      }


      return parseEnd( t, "not a branch", false);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE:  <define> ::= "define" <macParameter>*
   //
   //  One or more <parameters> are expected.  The first <parameter>
   //  is taken to be the Mac instruction name and its instruction 
   //  mask.  Subsequent <parameters> represent fields in the Mac 
   //  instruction.
   //
   //  Note that no code is generated here.  These definitions are
   //  for the benefit of the Mac Assembler so that it may recognize
   //  the Mac instruction set built by a Mic program.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseDefine( Tokenizer t, int location, long[] instr) throws IOException
   {
      String instrName = null;

      parseBegin( t, "define");
      
      if ( !token( t, "define"))
         return parseEnd( t, "not a define", false);

      if ( token( t, "")) {   // Capture the new instruction's name
         instrName = t.sval;
         t.pushBack();
      }

      if ( !parseParameter( t, location, instr, 0, null))
         return parseEnd( t, "not a define - no instruction name", false);

      int paramNo = 0;

      do { paramNo++; } while ( parseParameter( t, location, instr, paramNo, instrName))
         ;

      return parseEnd( t, "define recognized", true);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE:  <parameter> ::= <word> COLIN <number>
   //
   //  Parameters represent a name and mask association.  No code 
   //  generated here but the association is remembered for the Mac
   //  Assembler.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseParameter( Tokenizer t, int location, long[] instr, int paramNo, String instrName) throws IOException
   {
      parseBegin( t, "parameter");
  

      if ( !token( t, ""))
         return parseEnd( t, "not a parameter", false);

      String opcode = t.sval;

      if ( !token( t, COLIN))
         return parseEnd( t, "not a parameter, missing COLIN", false);


      if ( !token( t, 0.0))
         return parseEnd( t, "not a parameter, missing mask value", false);


      int mask = t.nval;


      // MSB hi indicates this is a Mac Instruction/Parameter
      // Bits 20-23 indicate the number of bits we must shift
      // the parameter up when we mask it into the instruction

      if ( paramNo == 0)
         MicMacSymbol.insertMacOpcode( opcode, mask);
      else {                // Mac instruction parameters

         int shift = 0;
         for ( int vv = mask; (vv % 2) == 0; shift++, vv /= 2)
            ;

         MicMacSymbol.insertMacParameter( instrName, paramNo, mask, shift);
      }

      return parseEnd( t, "parameter recognized", true);
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //
   //  Mac Specific Rules
   //
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////



   ///////////////////////////////////////////////////////////////////
   //  RULE: <macLabel> ::= <word> COLIN [ "equ" <macValue> ]
   //
   //  Labels are the first structure on a line, and they are optional
   //  Parsed labels are inserted into the symbol table along with the
   //  current value of the location counter.
   ///////////////////////////////////////////////////////////////////

   private static boolean parseMacLabel( Tokenizer t, int location) throws IOException
   {
      parseBegin( t, "macLabel");

      if ( token( t, "")) {

         if ( MicMacSymbol.lookupMacOpcodeValue( t.sval) == SYM_UNDEFINED &&
              MicMacSymbol.lookupMacSymbol( t.sval) == SYM_UNDEFINED) {

            String symbol = new String( t.sval);

            if ( !token( t, COLIN))
               t.pushBack();


            // EQUATE? 

            if ( token( t, "equ")) {

               int value = 0;  t.ttype = PLUS;

               do {
                  if ( parseMacConstant( t, symbol, value, t.ttype))
                     value = ((Integer) stack.pop()).intValue();
                  else
                     value = 0;
               } while ( (token(t, PLUS) || token(t, MINUS) || token(t, DIV) || token(t, MULT)));

               MicMacSymbol.insertMacSymbol( symbol, value);
            }
            else {
               t.pushBack();
               MicMacSymbol.insertMacSymbol( symbol, location);
            }

            return parseEnd( t, "macLabel found", true);
         }
         else
            t.pushBack();
      }

      return parseEnd( t, "not a macLabel", true);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE: <macConstant> ::= <number> | <symbol>
   ///////////////////////////////////////////////////////////////////

   private static boolean parseMacConstant( Tokenizer t, String symbol, int before, int operator) throws IOException
   {
      parseBegin( t, "macConstant");

      int value = 0;

      if ( token( t, 0.0))        // numeric?
         value = (int) t.nval;
      else
      if ( token( t, "")) {      
         if ( (value = MicMacSymbol.lookupMacSymbol( t.sval)) == SYM_UNDEFINED) {
            error("Symbol '"+t.sval+"' undefined, no forward references here!");
            value = 0;
         }
      }

      before = arithmetic( operator, before, value);

      stack.push( new Integer(before));

      return parseEnd( t, "recognized macConstant", true);
   }



   ///////////////////////////////////////////////////////////////////
   //  RULE: <macLine> ::= [<macLabel>] <storage> | <opcode> 
   //                      <macParameter>* EOL
   //
   //  One Mac (assembly language) statement per line
   ///////////////////////////////////////////////////////////////////

   private static boolean parseMacLine( Tokenizer t, int location, int[] instr) throws IOException
   {
      parseBegin( t, "macLine");

      instr[ location] = 0;

      parseMacLabel( t, location);   // each line may have a label

      // check for a defined opcode

      int opcode = 0;

      if ( parseMacStorage( t, location, instr)) {
         eatTo( t, EOL);
         token( t, EOL);

         return parseEnd( t, "recognized macLine", true);
      }
      else
      if ( token( t, "")) {

         if ( (opcode = MicMacSymbol.lookupMacOpcodeValue( t.sval)) != SYM_UNDEFINED) {

            instr[ location] = opcode & 0xFFFF;

            int paramNo = 0;   String instrName = t.sval;

            do { paramNo++; } while ( parseMacParameter( t, location, instr, paramNo, instrName, PLUS));

            eatTo( t, EOL);
            token( t, EOL);

            return parseEnd( t, "recognized macLine", true);
         }
         else
            error( "'"+t.sval+"' is not a defined Mac opcode");
      }

      eatTo( t, EOL);
      token( t, EOL);

      return parseEnd( t, "not macLine", false);
   }





   ///////////////////////////////////////////////////////////////////
   //  RULE:  <macStorage> ::= ("dcls" | "dclw") <macConstant>
   //
   ///////////////////////////////////////////////////////////////////

   private static boolean parseMacStorage( Tokenizer t, int location, int[] instr) throws IOException
   {
      parseBegin( t, "macStorage");

      if ( !token( t, "dcls") && !token( t, "dclw"))
         return parseEnd( t, "not a macStorage", false);

      String directive = t.sval;

      if ( !token( t, 0.0) && !token( t, ""))
         return parseEnd( t, "not a macStorage, no value given", false);

      if ( directive.equals( "dclw")) {
         if ( t.ttype == NUMBER)
            instr[location] = t.nval;
         else {
            int top = t.sval.length();

            for (int i = 0; i < top; i++)
               instr[location++] = t.sval.charAt(i);

            macLocation = location - 1;
         }
      }
      else
      if ( directive.equals( "dcls")) {
         for ( int i = 0; i < t.nval; i++)
            instr[location++] = 0;

         macLocation = location - 1;
      }

      return parseEnd( t, "macStorage recognized", true);
   }




   ///////////////////////////////////////////////////////////////////
   //  RULE:  <parameter> ::= (<number> | <word>) [(+|-|*|/) 
   //                         <parameter>] [COMMA]
   ///////////////////////////////////////////////////////////////////

   private static boolean parseMacParameter( Tokenizer t, int location, int[] instr, int paramNo, String instrName, int operator) throws IOException
   {
      parseBegin( t, "macParameter");

      if ( !token( t, 0.0) && !token( t, ""))
         return parseEnd( t, "not a macParameter", false);


      // Reduce the parameter to an integer value

      int v = 0;  boolean found = false;

      if ( t.ttype == NUMBER) {
         v = (int) t.nval;
         found = true;
      }
      else
      if ( (v = MicMacSymbol.lookupMacSymbol( t.sval)) != SYM_UNDEFINED)
         found = true;


      MicMacSymbol sy = MicMacSymbol.lookupMacParameter( instrName, paramNo);

      if ( sy != null) {
         int mask  = (int) sy.getValue();
         int shift = sy.getShift();

         if ( found) {
            int rangeMask = (mask >> shift);

            if ( (v & rangeMask) != v)
               error("parameter " + paramNo + " out of range: 0-" + rangeMask);

            int field = (instr[ location] &  mask) >> shift;
            int dleif = (instr[ location] & ~mask);

            field = arithmetic( operator, field, v);

            instr[ location] = dleif | ((field << shift) & mask);
         }
         else {
            fixups += "MAC|" + t.sval + "|+|" + location + "|" +
               mask + "|" + shift + "|i|"+srcLocation+"|";
         }
      }
      else
         error( "Parameter "+paramNo+" undefined for: "+instrName);

      if ( token( t, PLUS) || token( t, MINUS) || token( t, MULT) || token( t, DIV))
         return parseMacParameter( t, location, instr, paramNo, instrName, t.ttype);

      token( t, COMMA);

      return parseEnd( t, "parameter recognized", true);
   }





   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //
   //                       Lexical Analysis
   //
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////


   ///////////////////////////////////////////////////////////////////
   //  Initialize Mic Lexer.  Multiple semicolin delmited statements
   //  per line, with '{' prefixed comments.
   ///////////////////////////////////////////////////////////////////

   private static Tokenizer initMicLexer( String source)
   {
      Tokenizer t = new Tokenizer( 
                          new StringBufferInputStream( source));

      t.commentChar( COMMENT);

      t.quoteChar('"');
      t.quoteChar('\'');

      t.eolIsSignificant( true);
      t.lowerCaseMode   ( true);

      t.ordinaryChar( PLUS);
      t.ordinaryChar( MINUS);
      t.ordinaryChar( MULT);
      t.ordinaryChar( DIV);
      t.ordinaryChar( EQUALS);
      t.ordinaryChar( LPAREN);
      t.ordinaryChar( RPAREN);
      t.ordinaryChar( COLIN);
      t.ordinaryChar( COMMA);
      t.ordinaryChar( SEMI);

      return t;
   }



   ///////////////////////////////////////////////////////////////////
   //  Lexical analyzer based on Java's Tokenizer.  We want to
   //  restrict the terminals returned by Tokenizer to those of
   //  interest.
   ///////////////////////////////////////////////////////////////////

   private static int micLexer( Tokenizer T) throws IOException
   {
      int c = 0;

      while ( c != EOL && c != EOF) {
         switch ( (c = T.nextToken())) {
            case WORD:
            case NUMBER:
            case EOF:
            case EOL:
            case MINUS:
            case PLUS:
            case MULT:
            case DIV:
            case EQUALS:
            case LPAREN:
            case RPAREN:
            case COLIN:
            case COMMA:
            case SEMI: return c;
         }
      }

      return c;
   }





   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //
   //                       Support Methods
   //
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////

 

   ///////////////////////////////////////////////////////////////////
   // Match a given word or (if s == "") any word as a token.  As with
   // the other token() methods return true if the token is matched,
   // false otherwise.
   ///////////////////////////////////////////////////////////////////

   private static boolean token( Tokenizer t, String s) throws IOException
   {
      if ( micLexer(t) == WORD) {
         if ( s.length() == 0)                // match any word
            return parseTracer( t, "word matched", true, 0);
         else                                 // match given word
         if ( s.equals( t.sval))   
            return parseTracer( t, "keyword matched", true, 0);
      }

      t.pushBack();
      return parseTracer( t, "word unmatched", false, 0);
   }



   ///////////////////////////////////////////////////////////////////
   //  Match any numeric token.
   ///////////////////////////////////////////////////////////////////

   private static boolean token( Tokenizer t, double d) throws IOException
   {
      boolean sign = false;

      if ( token( t, MINUS))
         sign = true;

      if ( micLexer(t) == NUMBER) {
         if ( sign)
            t.nval *= -1;

         return parseTracer( t, "number match", true, 0);
      }
      
      t.pushBack();
      return parseTracer( t, "number unmatched", false, 0);
   }



   ///////////////////////////////////////////////////////////////////
   //  Match a terminal character (Like EOL, COMMA, LPAREN, etc.)
   ///////////////////////////////////////////////////////////////////

   private static boolean token( Tokenizer t, int i) throws IOException
   {
      if ( micLexer(t) == i)
         return parseTracer( t, "terminal match", true, 0);
      
      t.pushBack();
      return parseTracer( t, "terminal unmatched", false, 0);
   }

   

   ///////////////////////////////////////////////////////////////////
   //  Consume any remaining tokens until the end-of-line or end-of-file.
   //  We execute this after we have found a problem wth a given source
   //  line.
   ///////////////////////////////////////////////////////////////////

   private static void eatTo( Tokenizer t, int i) throws IOException
   {
      for (int u = t.nextToken(); u != i && u != EOF; u = t.nextToken())
         ;

      t.pushBack();
   }



   ///////////////////////////////////////////////////////////////////
   // Is the given token a register?  Syntactic candy...
   ///////////////////////////////////////////////////////////////////

   private static boolean isRegister( int i)
   {
      return i >= PC && i <= MBR ? true:false;
   }



   ///////////////////////////////////////////////////////////////////
   // Install a given address to a given bus field in the micr-
   // instruction.  This is syntactic candy...
   ///////////////////////////////////////////////////////////////////

   private static void installAddr( long[] instr, int location, long bus)
   {
      if ( bus == A_BUS_USED) {

         if ( (instr[ location] & A_BUS_USED) != 0)
            error("A bus is already committed");

         instr[ location] |= A_BUS_USED |
            (((((Integer) stack.pop()).intValue()) << 8) & 0x00000F00l);
      }
      else {

         if ( (instr[ location] & B_BUS_USED) != 0)
            error("B bus is already committed");

         instr[ location] |= B_BUS_USED |
            (((((Integer) stack.pop()).intValue()) << 12) & 0x0000F000l);
      }
   }




   ///////////////////////////////////////////////////////////////////
   //  Return the Mic address of a given register.  Constant 
   //  registers are not considered and MBR is a special case.
   ///////////////////////////////////////////////////////////////////

   private static int registerAddr( int token)
   {
      int addr = 0;

      switch ( token) {
         case PC:    addr =  0;  break;
         case AC:    addr =  1;  break;
         case SP:    addr =  2;  break;
         case IR:    addr =  3;  break;
         case TIR:   addr =  4;  break;
         case AMASK: addr =  8;  break;
         case SMASK: addr =  9;  break;
         case A:     addr = 10;  break;
         case B:     addr = 11;  break;
         case C:     addr = 12;  break;
         case D:     addr = 13;  break;
         case E:     addr = 14;  break;
         case F:     addr = 15;  break;
         case MBR:   addr = MBR; break;
      }

      return addr;
   }





   ///////////////////////////////////////////////////////////////////
   //  Preload the symbol table with opcodes. These, of course, are
   //  our reserve words.  All symbols share the same table, and an 
   //  operand stack is initialized.
   ///////////////////////////////////////////////////////////////////

   private static boolean installKeywords()
   {
      try {
         stack = new Stack();

         MicMacSymbol.clearTable();

         MicMacSymbol.insertMicKeyword( "pc",       PC);
         MicMacSymbol.insertMicKeyword( "ac",       AC);
         MicMacSymbol.insertMicKeyword( "sp",       SP);
         MicMacSymbol.insertMicKeyword( "ir",       IR);
         MicMacSymbol.insertMicKeyword( "tir",      TIR);
         MicMacSymbol.insertMicKeyword( "amask",    AMASK);
         MicMacSymbol.insertMicKeyword( "smask",    SMASK);
         MicMacSymbol.insertMicKeyword( "a",        A);
         MicMacSymbol.insertMicKeyword( "b",        B);
         MicMacSymbol.insertMicKeyword( "c",        C);
         MicMacSymbol.insertMicKeyword( "d",        D);
         MicMacSymbol.insertMicKeyword( "e",        E);
         MicMacSymbol.insertMicKeyword( "f",        F);
         MicMacSymbol.insertMicKeyword( "if",       IF);
         MicMacSymbol.insertMicKeyword( "goto",     THEN);
         MicMacSymbol.insertMicKeyword( "then",     GOTO);
         MicMacSymbol.insertMicKeyword( "rd",       RD);
         MicMacSymbol.insertMicKeyword( "wr",       WR);
         MicMacSymbol.insertMicKeyword( "alu",      ALU);
         MicMacSymbol.insertMicKeyword( "mar",      MAR);
         MicMacSymbol.insertMicKeyword( "mbr",      MBR);
         MicMacSymbol.insertMicKeyword( "lshift",   LSHIFT);
         MicMacSymbol.insertMicKeyword( "rshift",   RSHIFT);
         MicMacSymbol.insertMicKeyword( "band",     BAND);
         MicMacSymbol.insertMicKeyword( "define",   DEFINE);
         MicMacSymbol.insertMicKeyword( "halt",     MICHALT);

         MicMacSymbol.insertMacOpcode(  "dclw",      0);
         MicMacSymbol.insertMacOpcode(  "dcls",      0);
         MicMacSymbol.insertMacOpcode(  "halt", 0xFF00);
      }
      catch (Exception e) { return false; }

      return true;
   }





   ///////////////////////////////////////////////////////////////////
   //  Fixup Pass. Resolve the branch addresses in the fixup table
   //  now that all the labels have been defined.  All forward branch 
   //  references find their way into the fixup table. Each fixup is
   //  a set of four fields in a string:  MIC|symbolName|operator|
   //  address|mask|shift. Where MIC/MAC determines which space the 
   //  fixup is for.  SymbolName is the forward refrenced symbol. 
   //  Operator is how we will apply symbolName's value to the 
   //  instruction field.  Mask is what part of the instruction field
   //  the value will be applied. Shift is the number of bits the 
   //  value must be shifted to get it into position.
   ///////////////////////////////////////////////////////////////////

   private static void fixupPass( String fixups, long[] micInstr, int[] macInstr, String[] sourceLine)
   {
      StringTokenizer t = new StringTokenizer( fixups, "|");

      int     location = 0, addr = 0, mask, shift, sLoc;
      String  symbol, symbol2;
      char    operator;
      char    mode;
      boolean doMic;

      while ( t.hasMoreTokens()) {
         doMic = t.nextToken().equals("MIC");

         symbol   = t.nextToken();
         operator = t.nextToken().charAt(0);
         symbol2  = t.nextToken();
         mask     = Integer.parseInt( t.nextToken());
         shift    = Integer.parseInt( t.nextToken());
         mode     = t.nextToken().charAt(0);
         sLoc     = Integer.parseInt( t.nextToken());


         if ( mode == 'i') {  // Instruction mode

            // Lookup the value and extract the intruction field

            location = Integer.parseInt( symbol2);

            long instr, field, dleif;

            if ( doMic) {
               instr = addr = MicMacSymbol.lookupMicSymbol( symbol);

               if (addr == SYM_UNDEFINED)
                  addErrorList( "Undefined Mic symbol: '"+symbol+"'", sourceLine[ sLoc], true);

               field = (micInstr[ location] &  mask) >> shift;
               dleif = (micInstr[ location] & ~mask);
            }
            else {
               instr = addr = MicMacSymbol.lookupMacSymbol( symbol);

               if (addr == SYM_UNDEFINED)
                  addErrorList( ("Undefined Mac symbol:'"+symbol+"'"), sourceLine[ sLoc], true);

               field = (macInstr[ location] &  mask) >> shift;
               dleif = (macInstr[ location] & ~mask);
            }

            // Apply the value to the instruction field

            field = arithmetic( operator, (int) field, (int) instr);


            // Replace the modified instruction field

            field = (field << shift) & mask;

            if ( doMic)
               micInstr[ location] = dleif | field;
            else
               macInstr[ location] = (int) dleif | (int) field;
         }
         else
         if ( mode == 's') {  // Symbol Mode
            int value = 0, value2 = 0;

            if ( doMic) {
               value  = MicMacSymbol.lookupMicSymbol( symbol);
               value2 = MicMacSymbol.lookupMicSymbol( symbol2);

               if (value == SYM_UNDEFINED)
                  addErrorList( "Undefined Mic symbol:'"+symbol+"'", sourceLine[ sLoc], true);

               if (value2 == SYM_UNDEFINED)
                  addErrorList( "Undefined Mic symbol:'"+symbol2+"'", sourceLine[ sLoc], true);


               value2 = arithmetic( operator, value2, value2);
               MicMacSymbol.insertMicSymbol( symbol2, value2);
            }
            else {
               value  = MicMacSymbol.lookupMacSymbol( symbol);
               value2 = MicMacSymbol.lookupMacSymbol( symbol2);

               if (value == SYM_UNDEFINED)
                  addErrorList( "Undefined Mac symbol:'"+symbol+"'", sourceLine[ sLoc], true);

               if (value2 == SYM_UNDEFINED)
                  addErrorList( "Undefined Mac symbol:'"+symbol2+"'", sourceLine[ sLoc], true);

               value2 = arithmetic( operator, value2, value);
               MicMacSymbol.insertMicSymbol( symbol2, value2);
            }
         }


         if ( parseTraceEnable) {
              parseTrace.append( "fixup " + (doMic? "MIC":"MAC"));

            if ( mode == 'i') {
               parseTrace.append(" instruction at: " + location + " with address: " + addr +
                                 " for label: " + symbol + ", mask: " + Util.format("-09x ",mask) + 
                                 ", shift " + shift + "\n");
            }
            else {
               parseTrace.append(" symbol: " + symbol2 + " with value of symbol: " + symbol);
            }
         }
      }
   }



   ///////////////////////////////////////////////////////////////////
   //  Flexible register assignment.  This routine assigns the 
   //  stacked operand pairs to the A and B buses.  It is assumed 
   //  that any operations which must commit one data bus or the 
   //  other, have already done so.  The operands assigned here do 
   //  not care which bus they are gated onto.  
   ///////////////////////////////////////////////////////////////////

   private static void flexibleRegisterAssignment( long[] instr, int location)
   {
      long i = 0, j = 0, a, b, I = instr[ location];

      boolean aUsed, bUsed;

      if ( !stack.empty()) {

         while ( !stack.empty()) {                            // each operand pair

            if ( !stack.empty())
               i = ((Integer) stack.pop()).intValue();

            if ( !stack.empty())
               j = ((Integer) stack.pop()).intValue();

            a = (I & 0x00000F00) >>  8;
            b = (I & 0x0000F000) >> 12;


            aUsed = (I & A_BUS_USED) != 0;
            bUsed = (I & B_BUS_USED) != 0;

            if ( (i == a && j == b) || (i == b && j == a))    // already assigned?
               continue;


            if ( aUsed && bUsed) {                            // full?
               error("Infeasible combination of assignments");
               continue;
            }


            if ( !aUsed && !bUsed) {                          // both free?
               I |= ((i << 8) & 0x00000F00) | A_BUS_USED;
               I |= ((j <<12) & 0x0000F000) | B_BUS_USED;
            }
            else
            if ( aUsed && i == a)
               I |= ((j <<12) & 0x0000F000) | B_BUS_USED;     // a used, assign to b
            else
            if ( bUsed && j == b)
               I |= ((i << 8) & 0x00000F00) | A_BUS_USED;     // b used, assign to a
            else
            if ( aUsed && j == a)
               I |= ((i <<12) & 0x0000F000) | B_BUS_USED;     // a used, assign to b
            else
            if ( bUsed && i == b)
               I |= ((j << 8) & 0x00000F00) | A_BUS_USED;     // b used, assign to a
            else
               error("Infeasible combination of assignments");
         }

         instr[ location] |= I & 0xFFFFFFFFl;  // mask the resource allocation
                                               // bits away.
      }
   }



   ///////////////////////////////////////////////////////////////////
   // Called when a portion of the input has been parsed.  Provides 
   // an optional way of viewing the parse process.  The tracing
   // grows in a StringBuffer for speed.
   ///////////////////////////////////////////////////////////////////

   private static void parseBegin( Tokenizer t, String remark)
   {
      parseTracer( t, remark, true, 2);
   }


   private static boolean parseEnd( Tokenizer t, String remark, boolean flag)
   {
      return parseTracer( t, remark, flag, -2);
   }


   private static boolean parseEndPushBack( Tokenizer t, String remark, boolean flag)
   {
      parseTracer( t, remark, flag, -2);
      t.pushBack();
      return flag;
   }


   private static boolean parseTracer( Tokenizer t, String remark, boolean matched, int indent)
   {
      if ( parseTraceEnable) {
         if ( indent > 0)
            margin += indent;

         char dir = indent > 0 ? '>' : '<';

         if ( margin >= marginStr.length())
            margin = marginStr.length()-1;

         int i;

         if ( (i = remark.indexOf('\r')) >- 0)
            remark = remark.substring(0,i);
         


         if ( indent > 0)
            parseTrace.append( Util.format("-04d ",lineno) + dir + 
               marginStr.substring(0,margin) + remark.trim() + "\n");
         else
            parseTrace.append( Util.format("-04d ",lineno) + dir + 
               marginStr.substring(0,margin) + " <" + 
               tokenToString(t)+"> " + remark.trim() + "\n");



         if ( indent < 0)
            margin += indent;

         if ( margin < 0)
            margin = 0;
      }

      return matched;
   }



   ///////////////////////////////////////////////////////////////////
   // Return the string representation of a token for parse tracing.
   ///////////////////////////////////////////////////////////////////

   private static String tokenToString( Tokenizer t)
   {
      switch (t.ttype) {
         case WORD:   return t.sval;

         case NUMBER: return "" + t.nval;

         case EOL:    return "EOL";
         case EOF:    return "EOF";
         case PLUS:   return "PLUS";
         case MINUS:  return "MINUS";
         case MULT:   return "MULT";
         case DIV:    return "DIV";
         case EQUALS: return "EQUALS";
         case COLIN:  return "COLIN";
         case LPAREN: return "LPAREN";
         case RPAREN: return "RPAREN";
         case SEMI:   return "SEMI";

         default:     if ( t.ttype >= ' ' && t.ttype <= 128)
                         return "" + (char) t.ttype;
                      else
                         return "char("+t.ttype+")";
      }
   }



   ///////////////////////////////////////////////////////////////////
   // Log an error associated with the current source line.
   ///////////////////////////////////////////////////////////////////

   private static void error(String e)
   {
      if ( e == null || e.equals(""))
         return;

      String key   = new String( ERROR_TEXT+lineno);
      String error;

      numErrors++;

      if ( (error = MicMacSymbol.lookupSpecialText(key)) != null)
         e = error + "\n" + e;
      else
         e = "ERROR: " + e;

      MicMacSymbol.insertSpecial( key, e);
   }




   ///////////////////////////////////////////////////////////////////
   // Build the errorList used by the editor to point the user to
   // the correct error
   ///////////////////////////////////////////////////////////////////

   private static void addErrorList( String error, String sourceLine, boolean countIt)
   {
      if ( countIt)
         numErrors++;

      errorList += error + "\f" + sourceLine + "\n";
   }




   ///////////////////////////////////////////////////////////////////
   // Do Arithmetic Operation
   ///////////////////////////////////////////////////////////////////

   private static int arithmetic( int operator, int opr1, int opr2)
   {
      switch ( operator) {
         case MINUS: return opr1 - opr2;
         case MULT:  return opr1 * opr2;
         case DIV:   return (opr2 > 0) ? (opr1 / opr2) : opr1;
       
         case PLUS:  
         default:    return opr1 + opr2;
      }    
   }
}

