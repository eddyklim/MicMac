import java.awt.Frame;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.Insets;
import java.awt.Event;
import java.awt.Font;


//////////////////////////////////////////////////////////////////////
// 
//  Edit MicMac Program Breakpoints.  Given a FastList (subclass of
//  List), full of Mic or Mac source lines.  Allow the user to pick
//  multiple items.  Each list element represents an instruction
//  and setting one makes that instruction with a breakpoint.
//
//  Upon exit, try to return focus to the invoking window.
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 MicMac's source-code level breakpoint user-interface
 @see MicMac
 */

public class EditBreakpoints extends Frame
{

   ///////////////////////////////////////////////////////////////////
   //  Constructor
   ///////////////////////////////////////////////////////////////////


   /**
    Allows the user to add or remove Mic or Mac breakpoints.  Pops-up
    automatically.

    @param parent Frame to which focus returns
    @param title  Describes the type of breakpoints being manipulated
    @param breaks A breakpoint table, implemented by a FastList
    */

   public EditBreakpoints( Frame parent, String title, FastList breaks)
   {
      this.parent = parent;
      this.breaks = breaks;

      breaks.setFont( new Font( "Courier", Font.BOLD, 10));

      setTitle( title + " Select to Enable.");

      setBackground( background);
      breaks.setBackground( background);

      setLayout( new GridLayout(1,1));

      add( breaks);      
      
      pack();  resize( 300, size().height);


      Util.nextWindowCorner(this);

      if ( breaks == null || breaks.countItems() == 0)
         exit();
      else
         show();
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Public Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   public boolean handleEvent( Event e)
   {
      if ( e.id == Event.WINDOW_DESTROY)
         exit();
      else
      if ( e.id == Event.LIST_SELECT)
         breaks.fastSelected( ((Integer) e.arg).intValue(), true);
      else
      if ( e.id == Event.LIST_DESELECT)
         breaks.fastSelected( ((Integer) e.arg).intValue(), false);

      return super.handleEvent( e);
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Private Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   private static final Color background = new Color( 255,255,204);
   private static final int   LINES = 8;

   private Frame    parent = null;
   private FastList breaks;


   ///////////////////////////////////////////////////////////////////
   //  Convenient way to give the invoking window the focus.
   ///////////////////////////////////////////////////////////////////

   private void exit()
   {
      hide();

      if ( parent != null)
         parent.requestFocus();

      dispose();
   }
}

