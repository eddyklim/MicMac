import java.awt.Frame;
import java.awt.Color;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.Event;
import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.MenuBar;

import java.util.StringTokenizer;
import java.util.Enumeration;


//////////////////////////////////////////////////////////////////////
// 
//  Text Editor for the IDE
//
//  Upon exit, try to return focus to the invoking window.
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 MicMac's source-code and text-viewer user-interface.
 @see MicMac
 */

public class Editor extends Frame
{   
   ///////////////////////////////////////////////////////////////////
   //  Constructors
   ///////////////////////////////////////////////////////////////////


   ///////////////////////////////////////////////////////////////////
   //  Construct a simple text-viewer which is not editable.  Used
   //  to display listings and help files.
   ///////////////////////////////////////////////////////////////////

   /**
    Pop-up a text viewer
    @param parent Frame to which focus returns
    @param title Description of this text viewer
    @param text Text to be displayed
    */

   public Editor( Frame parent, String title, String text)
   {
      newDocument( parent, title, text, null, null, LIST);
   }


   ///////////////////////////////////////////////////////////////////
   //  Construct a text editor to edit the current source code in
   //  the simulator instance.
   ///////////////////////////////////////////////////////////////////

   /**
    Pop-up a text editor.
    @param parent Frame to which focus returns.
    @param ui user-interface to callback.
    @param sim simulator object for this MicMac session.
    */

   public Editor( Frame parent, MicMac ui, Simulator sim)
   {
      newDocument( parent, null, null, ui, sim, EDIT);
   }





   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Public Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////

   


   public static final int LIST = 0;
   public static final int EDIT = 1;



   ///////////////////////////////////////////////////////////////////
   //  Show the text in the window.  If this is an editor instead of
   //  a simple text-viewer, fetch the source code from the given
   //  simulator instance.
   ///////////////////////////////////////////////////////////////////

   public void show()
   {
      if ( editing)
         document.setText( sim.getSource());

      super.show();
   }



   ///////////////////////////////////////////////////////////////////
   //  Accessor methods
   ///////////////////////////////////////////////////////////////////

   /**
    Return the 'text modified' flag.
    @return True if the text has been modified.
    */

   public boolean getDirty()           { return dirty; }

   /**
    Set the 'text modified' flag.
    @param dirty New value of the 'text modified' flag.
    */

   public void    setDirty( boolean dirty) { this.dirty = dirty; }

   /**
    Return the editor/viewer's text.
    @return This editor/viewer's text.
    */

   public String  getText()                { return document.getText(); }

   /**
    Set the editor/viewer's text.
    @param text Editor/viewer's new text.
    */

   public void    setText(String text)     { document.setText(text); }



   ///////////////////////////////////////////////////////////////////
   //  Find the last desired string in the document
   ///////////////////////////////////////////////////////////////////

   /**
    Find and highlight the next occurrence of a string in the text
    */

   public void findString() {
      findString( lastFoundString, lastFindIgnoreCase);
   }



   ///////////////////////////////////////////////////////////////////
   //  Find the given string in the document
   ///////////////////////////////////////////////////////////////////

   /**
    Find and highlight the first occurrence of a string in the text.
    @param value String to find.
    */

   public void findString( String value, boolean ignoreCase) {
      String s = document.getText();
      int    found;


      // Ignoring case is EXPENSIVE!

      if ( ignoreCase) {
         if ( (found = s.toUpperCase().indexOf( value.toUpperCase(), findPos)) < 0)
            found = 0;
      }
      else {
         if ( (found = s.indexOf( value, findPos)) < 0)
            found = 0;
      }


      document.insertText( "", found);

      findPos = found;

      if ( found > 0) {
         findPos++;
         document.select( found, found+value.length());
      }

      toFront();
      document.requestFocus();

      lastFoundString    = value;
      lastFindIgnoreCase = ignoreCase;
   }



   ///////////////////////////////////////////////////////////////////
   //  Top-level event handler for the editor.
   ///////////////////////////////////////////////////////////////////

   public boolean handleEvent( Event e) {

      findPos = document.getSelectionEnd(); // Reposition find cursor

      if ( e.id == Event.KEY_PRESS) {   // any non-function key 
         dirty = true;                  // dirties the source file.
         return super.handleEvent( e);
      }
      else
      if ( e.target == mItemCommit  || 
           e.target == mItemAbandon ||
           e.target == mItemRebuild ||
           e.id == Event.WINDOW_DESTROY) {

         // Destroy the window

         if ( e.id == Event.WINDOW_DESTROY || e.target == mItemAbandon) {
            hide();
            parentFocus();


            dirty = false;

            if ( editing)
               document.setText( sim.getSource());
            else
               dispose();

            return true;
         }
         else

         // Commit the changes

         if ( e.target == mItemCommit || e.target == mItemRebuild) {

            hide();
            parentFocus();

            if ( editing)
               sim.setSource( document.getText());

            
            if ( e.target == mItemRebuild)
               ui.buildSource();

            return true;
         }
         else
            dirty = true;
      }
      else
      if ( e.id == Event.ACTION_EVENT || e.id == Event.KEY_ACTION) {

         // Try to find a given string

         if ( e.key == Event.F2 || e.target == mItemFind)
            new FindDialog( lastFindIgnoreCase, lastFoundString, this);
         else
         if ( e.key == Event.F3 || e.target == mItemNext)
            findString( lastFoundString, lastFindIgnoreCase);
         else

         // Try to find an ERROR string

         if ( e.key == Event.F4 || e.target == mItemNextError) {
            if ( style == EDIT)
               findNextError();
            else
               findString("ERROR:", false);
         }
      }

      return super.handleEvent( e);
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Private Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   



   private static final Color background = new Color( 255,255,204);

   private int       style = LIST;

   private int       findPos = 0;
   private String    lastFoundString = "";
   private boolean   lastFindIgnoreCase = true;

   private StringTokenizer errorList = null;

   private MenuItem  mItemCommit;
   private MenuItem  mItemAbandon;
   private MenuItem  mItemFind;
   private MenuItem  mItemNext;
   private MenuItem  mItemNextError;
   private MenuItem  mItemRebuild;

   private MicMac    ui;
   private Simulator sim;
   private TextField status;
   private TextArea  document;
   private boolean   dirty = false;
   private boolean   editing;

   private Frame     parent = null;




   ///////////////////////////////////////////////////////////////////
   //  Create the memubar
   ///////////////////////////////////////////////////////////////////

   private void setupMenuBar()
   {
      MenuBar mb = new MenuBar();
      Menu    m  = new Menu("Edit");


      switch (style) {
         case EDIT: m.add( (mItemRebuild = new MenuItem("Rebuild")));
                    m.add( (mItemCommit  = new MenuItem("Save Changes")));
                    m.add( (mItemAbandon = new MenuItem("Abandon")));
                    mb.add(m);
                    break;

      }

      m = new Menu("Find");

      m.add( (mItemFind      = new MenuItem("F2  Find String")));
      m.add( (mItemNext      = new MenuItem("F3  Find Next")));

      if ( style == EDIT)
         m.add( (mItemNextError = new MenuItem("F4  Find Error")));

      mb.add(m);

      setMenuBar(mb);
   }




   ///////////////////////////////////////////////////////////////////
   //  Construct any one of three types of editors/viewers.
   ///////////////////////////////////////////////////////////////////

   private void newDocument( Frame parent, String title, String text, MicMac ui, Simulator sim, int style)
   {
      this.parent = parent;
      this.sim    = sim;
      this.style  = style;
      this.ui     = ui;

      editing = false;

      setBackground( background);

      status = new TextField( "", 80);

      setLayout( new BorderLayout());


      switch (style) {

         case LIST: if ( title != null && !title.equals(""))
                       setTitle( "   " + title);

                    document = new TextArea( text, 24, 80);
                    break;


         case EDIT: editing = true;
                    setTitle( "   " + sim.getSourceName());

                    int numErrors = MicMacMake.getNumErrors();

                    if ( numErrors > 0) {
                       status.setText( numErrors + ((numErrors == 1) ? " Error" : " Errors") + 
                          ", select 'Find/Find Error' or F4 to locate the errors.");

                       add("South", status);

                       document = new TextArea( sim.getSource(), 22, 80);
                    }
                    else
                       document = new TextArea( sim.getSource(), 24, 80);

                    break;
      }


      document.setBackground( background);

      document.setFont( new Font( "Courier", Font.BOLD, 12));

      
      add("Center", document);
      
      setupMenuBar();

      pack();

      Util.nextWindowCorner(this);

      document.requestFocus();

      show();
   }



   ///////////////////////////////////////////////////////////////////
   //  Try to give the invoking window the focus
   ///////////////////////////////////////////////////////////////////

   private void parentFocus()
   {
      if ( parent != null)
         parent.requestFocus();
   }




   ///////////////////////////////////////////////////////////////////
   //  Find the next error in the last build listing and position
   //  the editor's cursor at the point.
   ///////////////////////////////////////////////////////////////////

   private void findNextError()
   {
      if ( errorList != null && !errorList.hasMoreTokens())
         errorList = null;

      if ( errorList == null)
         errorList = new StringTokenizer( MicMacMake.getErrorList(), "\r\n");

      StringTokenizer t = new StringTokenizer( errorList.nextToken(), "\f");

      if ( t.hasMoreTokens()) {
         status.setText( t.nextToken());

         if ( t.hasMoreTokens()) {
            findPos = 0;
            findString( t.nextToken(), false);
         }
      }
   }
}

