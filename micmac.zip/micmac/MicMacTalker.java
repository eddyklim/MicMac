import java.lang.Thread;
import java.util.Random;
import java.util.StringTokenizer;


//////////////////////////////////////////////////////////////////////
// 
//  MicMacTalker is a background thread which talks about MicMac.
//  Originally, it seared as a "Heartbeat" monitor so that I could
//  be sure that the virtual machine was still alive in the face
//  of appparent hang-ups.  This is a daemon thread -- it dies
//  when that application finally dies.
//  
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 Create a background thread to write eye-catching things to the user.
 */

public class MicMacTalker extends Thread
{
   ///////////////////////////////////////////////////////////////////
   //  Constructor
   ///////////////////////////////////////////////////////////////////

   /**
    Create a daemon thread to talk to the user.
    @param Reference to the current MicMacCanvas in order to write to its TTY device area.
    */

   public MicMacTalker( MicMacCanvas ui) 
   { 
      setDaemon(true); 

      this.ui = ui; 

      setPriority( Thread.MIN_PRIORITY);

      start();
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Public Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////



   ///////////////////////////////////////////////////////////////////
   //  This thread runs through the array of messages, writing them
   //  into the simulator's TTY window.  At the end of this display
   //  write a random "quip" into the same window.  Then do it all
   //  over again until silence is called-for.
   ///////////////////////////////////////////////////////////////////

   /**
    Display a set of eye-catching messages to the user in the simulator's
    TTY area.
    */

   public void run()
   {  
      try {  // Just temporary till we find that null pointer exception in Linux!


      int    count = 0;
      int    ticks;
      Random rand = new Random();

      StringTokenizer t;

  
      Util.sleep(1000);

      while (true) {

         ticks = 1000;

         if ( ui != null && seconds == 0) {

            if ( count >= message.length) {

               Util.sleep( ticks);

               int randIndex = rand.nextInt() % extramess.length;

               if (randIndex < 0)
                  randIndex *= -1;

               t = new StringTokenizer( extramess[ randIndex], "|");

               count = 0;
            }
            else
               t = new StringTokenizer( message[ count++], "|");

            if ( t.hasMoreTokens())
               ticks = Integer.parseInt( t.nextToken()) * 1000;

            ui.ttyChar('\f');

            if ( t.hasMoreTokens())
               ui.ttyString( t.nextToken());
         }

         if ( seconds > 0)
            seconds--;

         Util.sleep( ticks);
      }

      }
      catch( Exception e) {
         System.out.println("Reported from MicMacTalker.class: ");
         System.out.println("   Exeception: " + e.getMessage());
         e.printStackTrace();
      }
   }     




   ///////////////////////////////////////////////////////////////////
   //  Accessor/Mutator methods
   ///////////////////////////////////////////////////////////////////

   /**
    Make the talker quite for a while
    @param seconds to be quiet
    */

   public void quiet( int seconds)
   {
      this.seconds = seconds;

      ui.ttyChar('\f');
   }





   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Private Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   int     seconds          = 0;
   private MicMacCanvas ui  = null;
  
   private String message[] = { 

     //123456789-123456789-123456789-12   There are 32 chars on a line

      "1|",                             // Pause for a second


      "4|"+                             // Pause for 4 seconds
      "Welcome to MicMac "+
      MicMac.getVersion() + ",\n"+      // after displaying this message
      "Tweaked for Navigator 4+\n"+
      "and IE4+, March 1998",


      "5|"+
      "MicMac is a Microprogrammed\n" +
      "Computer Simulator & Integrated\n" +
      "Development Environment.",


      "5|"+
      "MicMac helps teach Computer\n" +
      "Organization, Assembler,\n" +
      "Microprogramming and even Java!",


      "5|"+
      "MicMac is based on the\n" +
      "example computer presented in\n" +
      "A.S. Tanenbaum's computer text:",


      "4|"+
      "     Structured Computer\n" +
      "   Organization, 3rd, 4th Ed.\n" +
      "      Prentice-Hall, 1990 ",


      "5|"+
      " This program was also inspired\n"+
      "      by Delmar E. Searls'\n"+
      "     MicSim Simulator & IDE.",


      "1|",


      "7|"+
      "I'm now running a very simple\n" +
      "microprogram just to show-off\n" +
      "for the mildly interested ;-) ",


      "5|"+
      "Selecting 'Control/Halt' on\n" +
      "the menubar will stop the demo,\n" +
      "and this running message.",


      "1|",


      "5|"+
      "Microcode is NOT the same thing\n" +
      "Machine Language: Think of it\n" +
      "the Sub-basement of a building.",

     //123456789-123456789-123456789-12


      "5|"+
      "MICroachitectures are the\n" +
      "machine-within-the-machine\n" +
      "driving most modern computers.",


      "5|"+
      "MACroarchitectures are what\n" +
      "folks tend to think are at the\n" +
      "lowest level (Machine Language)",


      "1|",


      "5|"+
      "MICroarchitectures allow\n" +
      "computer designers to produce\n" +
      "complicated computers easier.",


      "5|"+
      "But this ease & flexibility\n" +
      "cost SPEED. That's why the\n"+  
      "fastest serial computers are..",


      "5|"+
      "still built with so-called\n"+
      "\"random-logic\" where each MAC\n"+
      "op-code has dedicated circuits",


      "1|",


      "4|"+
      "A microarchitecture is a very\n" +
      "simple computer that quickly\n" +
      "interprets tiny programs...",


      "6|"+
      "which produce the illusion\n" +
      "of the type of computer the\n" +
      "designer had in mind all along.",


      "5|"+
      "MicMac lets YOU be that\n" +
      "designer. Create and run your\n" +
      "own MICro-program...",


      "5|"+
      "Then once you have created the\n" +
      "instruction set, use it to make\n" +
      "your Assembler/MACro-programs",
     

      "5|"+
      "MicMac's Java source code is\n"+
      "available to anyone for study\n"+
      "along with my project notes.",


      "5|"+
      "I used this project to learn\n"+
      "Java, and I hope my experiences\n"+
      "help others along the way! ",
     

      "1|",


      "5|"+
      "Your constructive comments are\n"+
      "welcome at: brettrix@yahoo.com\n"+
      "Tell me what you think :-) ",


      "1|",


      "4|"+
      "Let me thank the following\n"+
      "people for their help,\n" +
      "encouragement, and patience...",


      "6|"+
      "My loving wife Judi and son\n" +
      "Joshua, who gave me the time\n" +
      "I needed to do this project.",


      "6|"+
      "Mentors of past: Julian King,\n" +
      "C. Scott Bowers, Dutch Owens\n" +
      "Peter Dow, and Vicki Archibald",


      "5|"+
      "And more recently, Bill Beery,\n" +
      "Roger Shore, and Richard Steed ",
 

      "6|"+
      "Thanks to the people of Bell\n"+
      "Labs and Xerox PARC.  I aspire\n"+
      "to the great work you all do!",


      "5|"+
      "  Thanks to Andrew S. Tanenbaum\n" +
      "      and Delmar E. Searls ",


      "7|"+
      "Finally, thank you LORD.\n"+
      " You have given me all I have,\n"+
      "  and made me all that I am.",

     //123456789-123456789-123456789-12
   };



   private String extramess[] = { 

      "6|"+
      "Hey Mom & Dad!\n" +
      "My name's in lights: BRETT\n" +
      "Thanks for a great beginning!",


      "6|"+
      "Simple Things Should be\n" +
      "Simple. Complex things should\n" +
      "be possible - Alan Kay, Xerox",
     

      "4|"+
      "A computer's attention-span is\n" +
      "only as long as its power cord.",


      "6|"+
      "In Computers, Weeks are Forever\n" +
      "As a Result, Everyone is a\n" +
      "Newbie at Something!",


      "5|"+
      "A craftsman is known\n"+
      "  by the quality of his Tools\n"+
      "    -- ancient proverb",


      "5|"+
      "Reflect on how you solve\n" +
      "problems, and you will grow.",


      "5|"+
      "Be a Collector and User of\n"+
      "Fine Intellectual Tools.",


      "7|"+
      "See a man skilled in his work?\n"+
      "That person will work for kings\n"+
      "and not obscure men. -Proverbs",


      "5|"+
      "One person's Data is another\n"+
      "  person's Program.\n"+
      "    -Guy Steele, Tartan Labs.",


      "5|"+
      "Computers are not merely\n" +
      "number-crunchers, rather they\n" +
      "are Language-Machines.",


      "5|"+
      "Dare to be Creatively Lazy: \n" +
      "Make the Computer do Your Work!",


      "7|"+
      "   Small Minds Discuss People" +
      "  Average Minds Discuss Events" +
      "   Great Minds Discuss Ideas",


      "6|"+
      "Heisenberg Probably Slept Here.",


      "5|"+
      "Whenever Possible, Steal Code.\n" +
      "   -Tom Duff, Bell Labs",


      "6|"+
      "Brook's Law of Prototypes:\n" +
      "   Plan to throw one away,\n" +
      "          You will anyhow.",

      "5|"+
      "Don't keep doing\n" +
      "   What doesn't work!",


      "6|"+
      "Good judgement comes from\n"+
      "experience and experience comes\n"+
      "from bad judgement. -F. Brooks",


      "5|"+
      "The fastest I/O is no I/O\n" +
      "  -Nils-Peter Nelson, Bell Labs",


      "6|"+
      "Don't debug standing up. It\n"+
      "cuts your patience in half, and\n"+
      "you need all you can muster",
     

      "6|"+
      "When in doubt, use brute force."+
      "  -Ken Thompson, Bell Labs",


      "4|"+
      "Details Count\n" +
      "  -Peter Weinberger, Bell Labs",


      "6|"+
      "If you can't write it down in\n"+
      " English {your language}, you\n"+
      "  can't code it. -Peter Halpern",


      "7|"+
      "The first step to fixing a\n"+
      " broken program is to get it to\n"+
      "  fail repeatably. -Tom Duff",
     

      "7|"+
      "Program Optimization Rule #1\n"+
      " Don't Do It!  Rule #2 (for\n"+
      " experts only) Don't Do It Yet!",


      "6|"+
      "Compiler Writers' Motto\n"+
      " (optimization pass): Making a\n"+
      " wrong program worse is no sin.",


      "6|"+
      "System Programmers' Motto:\n"+
      " Don't test for an error you\n"+
      " you don't know how to handle.",


      "6|"+
      "The Maintainers' Motto:\n"+
      "  If we can't fix it,\n"+
      "     It ain't broke.",


      "5|"+
      "If you lie to the computer,\n"+
      "   It will get you.\n"+
      "      -Perry Farrar",


      "5|"+
      "One person's constant is\n"+
      "   another person's variable.\n"+
      "      -Susan Gerhart",


      "6|"+
      "I'd rather write programs to\n"+
      " write programs, than write\n"+
      "   programs.  -Dick Sites, DEC",


      "6|"+
      "    Representation is the\n"+
      "   Essence of Programming",


      "6|"+
      "      Size is not bad\n"+
      "  Unnecessary size is.",


      "6|"+
      "Perceived Speed May be More\n"+
      "Important than Actual Speed.",


      "6|"+
      "Good Tools Magnify Productivity\n"+
      "As a Lever Magnifies Force.\n",
   };
}


