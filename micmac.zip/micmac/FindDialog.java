import java.awt.Dialog;
import java.awt.Event;
import java.awt.Container;
import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.Dimension;
import java.awt.TextField;
import java.awt.Checkbox;

import java.util.StringTokenizer;

//////////////////////////////////////////////////////////////////////
// 
//  Find Dialog pops-up a small dialog to allow the user to enter a
//  search string.  Used in the Editor to find strings in the source
//  or errors in a listing.
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 String search dialog used by Editor
 @see Editor
 */

public class FindDialog extends Dialog
{
   ///////////////////////////////////////////////////////////////////
   //  Constructors
   ///////////////////////////////////////////////////////////////////


   ///////////////////////////////////////////////////////////////////
   //  Use this to find a string you've already specified.
   ///////////////////////////////////////////////////////////////////

   /**
    Find dialog where the user must enter the search string.
    @param parent Frame to which focus returns.
    */

   public FindDialog( Editor parent)
   {
      this( false, null, parent);
   }


   ///////////////////////////////////////////////////////////////////
   //  Use this to find a new string.
   ///////////////////////////////////////////////////////////////////

   /**
    Find dialog where a search string is suggested, but the user may overide
    @param ignoreCaseFlag True to ignore case.
    @param findString Suggested string.
    @param parent Frame to which focus returns.
    */

   public FindDialog( boolean ignoreCaseFlag, String findString, Editor parent)
   {
      super( parent, true);

      this.parent = parent;

      setBackground( background);

      setTitle("   Find String");

      setFont( new Font("Sanserif", Font.BOLD, 12));

      findThis = new TextField( " ", 20); 
      findThis.setBackground( background);

      ignoreCase = new Checkbox( "Ignore Case");
      ignoreCase.setState( ignoreCaseFlag);

      add( "West", findThis);
      add( "Center", new Label(" "));
      add( "East",  ignoreCase);

      if ( findString != null)
         findThis.setText(findString);

      pack();

      Util.centerContainer(this);

      show();


      // HACK! Untrusted mode does not resize properly to take the size of the
      // warning message of the new window into account!

      if ( !Util.isTrusted())
         resize( preferredSize());

      findThis.selectAll();

      findThis.requestFocus();
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Public Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   ///////////////////////////////////////////////////////////////////
   //  Top-level event handler
   ///////////////////////////////////////////////////////////////////

   public boolean handleEvent( Event e) 
   {
      if ( e.id == Event.WINDOW_DESTROY) {

         hide();
         dispose();

         return true;
      }
      else
      if ( e.id == Event.KEY_PRESS && e.key == '\n') {
         hide();

         String unpadded = findThis.getText().trim();

         findThis.setText( unpadded);

         if ( findThis.getText().equals(""))
            parent.findString();
         else
            parent.findString( findThis.getText(), ignoreCase.getState());
     

         dispose();

         return true;
      }


      
      return super.handleEvent(e);
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Private Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   private static final Color background = new Color( 255,255,204);

   private Editor    parent = null;
   private TextField findThis;
   private Checkbox  ignoreCase;
}

