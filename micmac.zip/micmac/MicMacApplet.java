import java.applet.Applet;

//////////////////////////////////////////////////////////////////////
// 
//  MicMacApplet.  The entry point for applets
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////


/**
 Entry point for the MicMac microprogramming simulator & IDE for applet mode.
 @see MicMac
 */

public class MicMacApplet extends Applet
{
   public void init()
   {
      micmac = new MicMac(this);
   }

   public void start()
   {
      micmac.start();
   }

   public void stop()
   {
      micmac.stop();
      System.gc();
   }

   private static MicMac micmac;
}

