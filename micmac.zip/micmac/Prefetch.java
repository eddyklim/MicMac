import java.lang.Thread;
import java.applet.Applet;
import java.util.Hashtable;
import java.awt.List;


////////////////////////////////////////////////////////////////////////
//  This daemon thread caches files in the background beneath the user's
//  attention:  Perceived speed is often more important than actual 
//  speed.  It simply calls Util's readFile() method.
////////////////////////////////////////////////////////////////////////

/**
 This daemon thread caches files in the background beneath the user's
 attention.  The hope is that the help/example/java file will already
 be loaded by the time the user wants to see it.  This works for both
 disk files and downloadable ones, but the most gain is from perceived
 shorter downloads.  There should only be one instance of this running,
 and it starts itself.
 */

public class Prefetch extends Thread
{
   //////////////////////////////////////////////////////////////////////
   //  Return a list object in "Serialized" form
   //////////////////////////////////////////////////////////////////////

   Prefetch( Applet applet)
   {
      Util.log("Prefetch thread started");

      this.applet = applet;

      setPriority( MIN_PRIORITY);

      fileCache = Util.getFileCache();

      setDaemon( true);

      start();
   }



   //////////////////////////////////////////////////////////////////////
   //  Look through the prefetch list for files which have not yet been
   //  fetched (as indicated by the selected flag in each List item).
   //  Then fetch the file and mark it as having been fetched.  The
   //  readFile() method will do the actuall caching.  The sleeps are
   //  necessary to ensure that this thread does not hog the cpu.
   //////////////////////////////////////////////////////////////////////

   /**
   Look through the prefetch list for files which have not yet been
   fetched (as indicated by the selected flag in each List item).
   Then fetch the file and mark it as having been fetched.  The
   readFile() method will do the actuall caching.  The sleeps are
   necessary to ensure that this thread does not hog the cpu.
    */

   public void run()
   {
      try {  // Just temporary till we find that null pointer exception in Linux!

      int    top;

      while (true) {
         top = names.countItems();

         for (int i = 0; i < top; i++) {
            if ( names.isSelected(i) == false) {

               Util.readFile( applet, names.getItem(i));

               names.select(i);
            }

            Util.sleep(1000);
         }

         Util.sleep(1000);
      }

      }
      catch( Exception e) {
         System.out.println("Reported from Prefetch.class: ");
         System.out.println("   Exeception: " + e.getMessage());
         e.printStackTrace();
      }
   }




   //////////////////////////////////////////////////////////////////////
   //  Prefetch the given file name.
   //////////////////////////////////////////////////////////////////////

   /**
    Prefetch the given file name.
    @param name of the file to fetch.
    */

   public void add( String name)
   {
      names.addItem( name);
   }





   //////////////////////////////////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////
   //  Private Members
   //////////////////////////////////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////




   private Hashtable fileCache = null;
   private List      names     = new List(5, true);
   private Applet    applet    = null;
}

