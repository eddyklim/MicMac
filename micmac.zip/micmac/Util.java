import java.applet.Applet;

import java.awt.List;
import java.awt.Frame;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;

import java.io.File;
import java.io.PrintStream;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;

import java.net.URLEncoder;
import java.net.URL;
import java.net.URLConnection;

import java.util.Vector;
import java.util.StringTokenizer;
import java.util.Hashtable;


/////////////////////////////////////////////////////////////////////////
//
//  A class of generally useful methods.  All of these are Class methods.
//
//  * Datatype serialization (not like 1.1)
//  * Debug/Logging
//  * String handling
//    * String to array and back
//    * Tab expanding
//    * String formatting
//    * String padding
//  * Automatic window positioning/centering
//  * Fast Array Filling/Clearing
//  * File Reading both locally and remotely
//  * File Writing locally
//  * Multi-radix number parsing
//  * Message box
//  * Java & Operating System information
//  * Put the current thread to sleep for a while
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 Generally useful class methods.  Do not instantiate.
 */

public class Util extends Object
{
   //////////////////////////////////////////////////////////////////////
   //  Serialization here means reducing various datatypes to URL encoded
   //  strings and back again.  There methods are used by the simulator
   //  to load and save its state.  (Something I don't really exploit
   //  in this project, unfortunately.)
   //////////////////////////////////////////////////////////////////////

   //////////////////////////////////////////////////////////////////////
   //  Return a list object in "Serialized" form
   //////////////////////////////////////////////////////////////////////

   /**
    Externalize a List.
    @param l List.
    @return String form of List.
    */

   static String serializeList( List l)
   {
      int items = l.countItems();

      String t = new String(""), u = new String("");

      for ( int i = 0; i < items; i++) {
         try {
            u =  i + SER_SEP + l.getItem(i) + SER_SEP;
            u += l.isSelected(i) ? "1":"0";
            u += SER_SEP;
         }
         catch( Exception e) { u = ""; }

         t += u;
      }
 
      return serializeString( t);
   }




   //////////////////////////////////////////////////////////////////////
   //  Return an array in "Serialized" form
   //////////////////////////////////////////////////////////////////////

   /**
    Externalize an array of longs.
    @param l Long array.
    @return String form of Long array.
    */

   static String serializeArray( long[] l)    // Long Arrays
   {
      String t = new String( l.length + SER_SEP);

      for ( int i = 0; i < l.length; i++)
         if ( l[i] != 0)
            t += i + SER_SEP + l[i] + SER_SEP;
 
      return serializeString( t);
   }



   /**
    Externalize an array of Strings.
    @param l String array.
    @return String form of String array.
    */

   static String serializeArray( String[] l)  // String Arrays
   {
      String t = new String( l.length + SER_SEP);

      for ( int i = 0; i < l.length; i++)
         if ( l[i] != null && !l[i].equals(""))
            t += i + SER_SEP + l[i] + SER_SEP;
 
      return serializeString( t);
   }



   //////////////////////////////////////////////////////////////////////
   //  Return primative type in "Serialized" form
   //////////////////////////////////////////////////////////////////////

   /**
    Externalize an int.
    @return String form of int.
    */

   static String serializeInt( int i)
   {
      return Integer.toString(i);
   }


   /**
    Externalize an long.
    @return String form of long.
    */

   static String serializeLong( long i)
   {
      return Long.toString(i);
   }


   /**
    Externalize a boolean.
    @return String form of boolean.
    */

   static String serializeBoolean( boolean b)
   {
      return b ? "1" : "0";
   }


   /**
    Externalize an String.
    @return URLEncoder form of String.
    */

   static String serializeString( String s)
   {
      return URLEncoder.encode(s);
   }



   //////////////////////////////////////////////////////////////////////
   //  "De-serialize" the following primatives
   //////////////////////////////////////////////////////////////////////

   /**
    Internalize a String.
    @param Externalized form of String.
    @return String.
    */

   static String deserializeString( String s)
   {
      if ( s == null || s.equals(""))
         return "";

      StringBuffer x = new StringBuffer("00");

      char   c, k[] = s.toCharArray();
      int    v;

      StringBuffer t = new StringBuffer("");

      for (int i = 0; i < k.length; i++) {

         if ( (c = k[i]) == '+')             // Space conversion
            t.append(' ');
         else
         if ( c == '%') {
            x.setCharAt(0,k[i+1]);
            x.setCharAt(1,k[i+2]);
            t.append( (char) Integer.parseInt(x.toString(),16));
            i += 2;
         }
         else
            t.append(c);
      }

      return t.toString();
   }



   /**
    Internalize an int.
    @param Externalized int.
    */

   static int deserializeInt( String s)
   {
      return Integer.parseInt(s);
   }


   /**
    Internalize an long.
    @param Externalized long.
    */

   static long deserializeLong( String s)
   {
      return Long.parseLong(s);
   }


   /**
    Internalize an boolean.
    @param Externalized boolean.
    */

   static boolean deserializeBoolean( String s)
   {
      return s.equals("0") ? false : true;
   }


   //////////////////////////////////////////////////////////////////////
   //  "De-serialize" a list
   //////////////////////////////////////////////////////////////////////

   /**
    Internalize a List.
    @param Externalized List.
    */

   static List deserializeList( String S)
   {
      if ( S == null)
         return null;

      String          s = deserializeString( S);
      StringTokenizer t = new StringTokenizer( s, SER_SEP);
      int             items = t.countTokens() / 3;
      int             j;
      List            l = new List();

      for ( int i = 0; i < items; i++) {
         j = deserializeInt( t.nextToken());
         l.addItem( t.nextToken(), j);

         if ( deserializeBoolean( t.nextToken()))
            l.select(j);
      }
 
      return l;
   }


   /**
    Internalize an int.
    @param Externalized int.
    @param Preexising List to internalize into.
    */


   static void deserializeList( String S, List L)
   {
      if ( S != null) {
         List l = deserializeList( S);

         int len = l.countItems();

         for ( int i = 0; i < len; i++) {
            L.addItem( l.getItem( i), i);

            if ( l.isSelected( i))
               L.select(i);
         }
      }
   }




   //////////////////////////////////////////////////////////////////////
   //  "De-serialize" Arrays
   //////////////////////////////////////////////////////////////////////

   /**
    Internalize an array of longs.
    @param Externalized array of longs.
    */

   static long[] deserializeLongArray( String S)    // Long Arrays
   {
      if ( S == null)
         return null;

      String          s = deserializeString( S);
      StringTokenizer t = new StringTokenizer( s, SER_SEP);

      int len = deserializeInt( t.nextToken());

      long[] a = new long[ len];

      int j;

      while ( t.hasMoreTokens()) {
         j    = deserializeInt(  t.nextToken());
         a[j] = deserializeLong( t.nextToken());
      }

      return a;
   }


   /**
    Internalize an array of longs.
    @param Externalized array of longs.
    @param Array of longs to internalize into.
    */

   static void deserializeArray( String S, long[] A)
   {
      if ( S != null) {
         long[] a = deserializeLongArray( S);
         System.arraycopy( a, 0, A, 0, A.length);
      }
   }


   /**
    Internalize an array of Strings.
    @param Externalized array of Strings.
    */

   static String[] deserializeStringArray( String S)    // String Arrays
   {
      if ( S == null)
         return null;

      String          s = deserializeString( S);
      StringTokenizer t = new StringTokenizer( s, SER_SEP);

      int len = deserializeInt( t.nextToken());

      String[] a = new String[ len];

      int j;

      while ( t.hasMoreTokens()) {
         j    = deserializeInt( t.nextToken());
         a[j] = t.nextToken();
      }

      return a;
   }


   /**
    Internalize an array of Strings.
    @param Externalized array of Strings.
    @param Array of Strings to internalize into.
    */

   static void deserializeArray( String S, String[] A)
   {
      if ( S != null) {
         String[] a = deserializeStringArray( S);

         System.arraycopy( a, 0, A, 0, A.length);
      }
   }




   //////////////////////////////////////////////////////////////////////
   //  Primitive debugging aids...
   //////////////////////////////////////////////////////////////////////

   /**
    Log text to Java console.
    */

   public static void log(String s)
   {
      System.out.println("LOG: "+s);
   }

   /**
    Log numeric value to Java console.
    */

   public static void log(int i)
   {
      System.out.println("LOG: "+i);
   }

   /**
    Pause until user keys a newline.
    */

   public static void pauseExit()
   {
      try { System.in.read(); } catch( Exception e) {}
      System.exit(0);
   }



   //////////////////////////////////////////////////////////////////////
   //  String routines
   //////////////////////////////////////////////////////////////////////


   //////////////////////////////////////////////////////////////////////
   //  Expand tab characters of a given width to spaces.
   //  This is time consuming!
   //////////////////////////////////////////////////////////////////////

   /**
    Return a given string with the tab characters of a given width expanded to spaces.
    @param s Input string with tabs.
    @param width Tab width in spaces.
    @return String with tabs expanded to spaces.
    */

   public static String expandTabs( String s, int width)
   {
      int i, j;

      while ( (i = s.indexOf('\t')) >= 0) {
         if ( (j = (i % width)) == 0)
            s = s.substring(0,i)+padd.substring(0,width)+s.substring(i+1);
         else
            s = s.substring(0,i)+padd.substring(0,width-j)+s.substring(i+1);
      }

      return s;
   }



   //////////////////////////////////////////////////////////////////////
   //  Create an array of strings one element per line of a given string
   //////////////////////////////////////////////////////////////////////

   /**
    Create a String array from a String containing many lines.
    */

   public static String[] stringToArray( String S)
   {
      if ( S == null || S.equals(""))
         return null;

      StringTokenizer t = new StringTokenizer(S, "\n", true);
      Vector          v = new Vector(32);
      String          s, u;
      
      int             lineno = 0;


      while ( t.hasMoreTokens()) {
         if ( !(s = t.nextToken()).equals("\n"))
            if ( t.hasMoreTokens())
               t.nextToken();

         v.addElement( (Object) s);
      }

      v.trimToSize();   int top = v.size();

      String[] a = new String[ top];

      for ( int i = 0; i < top; i++)
         a[i] = (String) v.elementAt(i);

      v = null;

      return a;
   }




   //////////////////////////////////////////////////////////////////////
   //  Make a single string from an array of strings, where each element
   //  makes a separate line.
   //////////////////////////////////////////////////////////////////////

   /**
    Create a multi-line String from an array of Strings.
    */

   public static String arrayToString( String[] a)
   {
      String s = new String("");

      for ( int i = 0; i < a.length; i++)
         s += a[i] + "\n";

      return s;
   }


   /**
    Create a multi-line String from an array of StringBuffers.
    */

   public static String arrayToString( StringBuffer[] a)
   {
      StringBuffer s = new StringBuffer(60000);

      for ( int i = 0; i < a.length; i++) {
         s.append( a[i]);
         s.append( '\n');
      }

      return s.toString();
   }




   //////////////////////////////////////////////////////////////////////
   //  lPadd/rPadd: Padd the string with chars on the left/right
   //  Using StringBuffer is three times faster than using String!
   //////////////////////////////////////////////////////////////////////

   /**
    Padd the given string with characters to the left.
    @param s Input string.
    @param padd Padding characters.
    @param len Number of padding characters.
    */

   public static String lPadd( String s, char padd, int len)
   {
      return padd( s, padd, len, false);
   }


   /**
    Padd the given string with characters to the right.
    @param s Input string.
    @param padd Padding characters.
    @param len Number of padding characters.
    */

   public static String rPadd( String s, char padd, int len)
   {
      return padd( s, padd, len, true);
   }


   /**
    Padd the given string with characters to the left or left.
    @param s Input string.
    @param padd Padding characters.
    @param len Number of padding characters.
    @param True to page on right, otherwise, left.
    */

   public static String padd( String s, char padd, int len, boolean rjustify)
   {
      StringBuffer b = new StringBuffer(len);

      int plen = len - s.length();

      if ( rjustify) {
         for ( int i = 0; i < plen; i++)
            b.append( padd);

         b.append( s);
      }
      else {
         b.append( s);

         for ( int i = 0; i < plen; i++)
            b.append( padd);
      }

      return b.toString();
   }



   //////////////////////////////////////////////////////////////////////
   // A basic value to string formatter.  Like a poor-man's printf
   // see _format() for details.
   //////////////////////////////////////////////////////////////////////

   /**
    Format a given string with a given format.
    @param f Format like 'C' printf() format for a single variable.
    @param s Input string.
    */

   public static String format( String f, String s)
   {
      return _format( f, s, 0);
   }


   /**
    Format a given int with a given format.
    @param f Format like 'C' printf() format for a single variable.
    @param s Input int.
    */

   public static String format( String f, int v)
   {
      return _format( f, null, (long) v);
   }


   /**
    Format a given long with a given format.
    @param f Format like 'C' printf() format for a single variable.
    @param s Input long.
    */

   public static String format( String f, long v)
   {
      return _format( f, null, v);
   }






   //////////////////////////////////////////////////////////////////////
   //  Put a window in the center of the user's screen.
   //////////////////////////////////////////////////////////////////////

   /**
    Center a given Container (usually Frame) on the user's screen.
    */

   public static void centerContainer( Container c)
   {
      Dimension d = c.size();
      Dimension s = c.getToolkit().getScreenSize();

      c.move( (s.width-d.width)/2, (s.height-d.height)/2);
   }




   //////////////////////////////////////////////////////////////////////
   //  Where the next window should be placed.  Using these, stagger
   //  newly created windows in a fasion similar to the way other 
   //  window's apps do it.
   //////////////////////////////////////////////////////////////////////

   /**
    Establish the upper-left-hand corner Container.
    */

   public static void setWindowCorner( Container c)
   {
      cornerComponent = c;
   }


   /**
    Position the given Container in the next slot to the lower-right relative to
    the current cornerComponent.  This is for automatic staggering of new windows.
    */

   public static void nextWindowCorner( Container c)
   {
      if ( cornerComponent == null)
         centerContainer( c);
      else {
         Insets    i = cornerComponent.insets();
         Dimension d = cornerComponent.size();

         int width  = (d.width  - i.left - i.right)  / 2;
         int height = (d.height - i.top  - i.bottom) / 2;

         if ( i.top == 0)
            i.top = 12;

         int max = height / i.top;

         c.move( cornerComponent.location().x+((nextCorner+1)*(i.top/2)),
                 cornerComponent.location().y+((nextCorner+1)*(i.top/2)));

         nextCorner++;  nextCorner %= max;
      }
   }




   //////////////////////////////////////////////////////////////////////
   //  Fill array VERY QUICKLY -- This is a neat trick!
   //////////////////////////////////////////////////////////////////////

   /**
    Quickly fill an array of longs with a given value.
    @param a Array to fill.
    @param v Value to fill array with.
    */

   public static void fillArray( long[] a, long v)
   {
      int len = a.length;

      if ( len > 0)
         a[0] = v;

      for ( int i = 1; i < len; i += i)
         System.arraycopy( a, 0, a, i, ((len - i) < i) ? (len - i) : i);
   }


   /**
    Quickly fill an array of ints with a given value.
    @param a Array to fill.
    @param v Value to fill array with.
    */

   public static void fillArray( int[] a, int v)
   {
      int len = a.length;

      if ( len > 0)
         a[0] = v;

      for ( int i = 1; i < len; i += i)
         System.arraycopy( a, 0, a, i, ((len - i) < i) ? (len - i) : i);
   }



   /**
    Quickly fill an array of bytes with a given value.
    @param a Array to fill.
    @param v Value to fill array with.
    */

   public static void fillArray( byte[] a, byte v)
   {
      int len = a.length;

      if ( len > 0)
         a[0] = v;

      for ( int i = 1; i < len; i += i)
         System.arraycopy( a, 0, a, i, ((len - i) < i) ? (len - i) : i);
   }


   /**
    Quickly fill an array of Objects with a given value.
    @param a Array to fill.
    @param v Value to fill array with.
    */

   public static void fillArray( Object[] a, Object v)
   {
      int len = a.length;

      if ( len > 0)
         a[0] = v;

      for ( int i = 1; i < len; i += i)
         System.arraycopy( a, 0, a, i, ((len - i) < i) ? (len - i) : i);
   }





   //////////////////////////////////////////////////////////////////////
   //  Return the read file cache.  The key is the file name String and
   //  the value is a String representing the contents of a text file.
   //////////////////////////////////////////////////////////////////////

   /**
    Return the read file cache.  The key is the file name String and
    the value is a String representing the contents of a text file.
    @return Return the read file cache.
    */

   public static Hashtable getFileCache()
   {
      return fileCache;
   }



   //////////////////////////////////////////////////////////////////////
   //  Read a file either locally or remotely
   //////////////////////////////////////////////////////////////////////

   /**
    Read a file either locally or from our code base of our applet (if
    we are in applet mode).
    @param applet Reference to current applet, or null if in application mode.
    @param name File name.
    @return String containing text of file.
    */

   public static String readFile( Applet applet, String name)
   {

      //Util.log("Util.readFile("+name+")");

      InputStream is = null;
      int len = 0;

      String newName    = name;
      String cacheValue = "";
      URL    url        = null;


      if ( (cacheValue = (String) fileCache.get( (Object) name)) != null)
         return cacheValue;


      try {
         File f  = new File( name);
         newName = f.getAbsolutePath(); // without these two this routine   HACK!
                                        // won't be able to find its files
                                        // after the load/save routines run

         f = new File( newName);
         len = (int) f.length();

         is = new BufferedInputStream( new FileInputStream( f));
      }
      catch (Exception x) {
         //Util.msgBox("readFile() failed to open file '"+newName+"'");
         //Util.log("Util.readFile() failed to open local file '"+newName+"'");

         if ( applet == null)
            return null;
   

         try {
            url = new URL( applet.getDocumentBase(), name);

            URLConnection connection = url.openConnection();
            connection.connect();

            len = connection.getContentLength();

            is = new BufferedInputStream( connection.getInputStream());
         }
         catch (Exception e) { 
            //Util.msgBox("readFile() failed to open URL '"+url.toExternalForm()+"'");
            //Util.log("Util.readFile() failed to open URL '"+url.toExternalForm()+"'");
            return null;
         }
      }

      byte[] buffer = new byte[len];

      //Util.msgBox("readFile("+name+") survived");
      //Util.log("readFile("+name+") survived");

      int read = 0, r = 0;

      try {
         while ( read < len && r >= 0) {
            r = is.read( buffer, read, (len-read));
            read += r;
         }

         is.close();
      }
      catch (Exception e) { return null; }


      cacheValue = new String( buffer, 0);

      fileCache.put( (Object) name, (Object) cacheValue);

      return cacheValue;
   }



   //////////////////////////////////////////////////////////////////////
   //  Write a text file
   //////////////////////////////////////////////////////////////////////

   /**
    Write a string to a file on the local file system.
    @param name File name.
    @param contents Text.
    */

   public static void writeTextFile( String name, String contents)
   {
      File f = new File( name);

      try {
         PrintStream ps = new PrintStream( new BufferedOutputStream( new FileOutputStream( f)));

         StringTokenizer t = new StringTokenizer( contents, "\n\r");

         while ( t.hasMoreTokens())
            ps.println( t.nextToken());

         ps.close();
      }
      catch (Exception e) { msgBox("Cannot write '"+name+"'"); }
   }




   /////////////////////////////////////////////////////////////////
   // Given a string number of the form 0000h, 0000b, 0000o or 0000,
   // return its value as a long.
   /////////////////////////////////////////////////////////////////

   /**
    Parse a numeric string which may be in a different radix than decimal.  Numeric
    values will always begin with a decimal digit and may have a radix suffix at the
    end.  Suffixes are: b, B, o, O, h, H, for binary, octal, and hex.  No suffix
    indicates a decimal value.  Hex values should be preceeded with a leading zero
    if the most significant digit is in the set 'A' to 'F'.<p>
    Examples:   255 = 0ffh = 0FFH = 377o = 1111111b
    @return v String form of number.
    @return Long form of the number in decimal.
    */

   public static long parseValue(String v)
   {
      long  i = 0;
      int   len = v.length() -1;

      if ( len >= 0) {
         try {
            switch (v.charAt(len)) {
               case 'h':
               case 'H': i = Long.parseLong(v.substring(0,len),16); break;

               case 'o':
               case 'O': i = Long.parseLong(v.substring(0,len),8);  break;

               case 'b':
               case 'B': i = Long.parseLong(v.substring(0,len),2);  break;

               default:  i = Long.parseLong(v);
            }
         }
         catch( Exception e) { msgBox("Cannot convert '"+v+"'"); i = 0; }
      }

      return i;
   }




   //////////////////////////////////////////////////////////////////////
   //  Pop up a message box with the given string
   //////////////////////////////////////////////////////////////////////

   /**
    Pop-up a messages box with the given text.
    */

   public static void msgBox( String s)
   {
      Frame f = new Frame();

      MessageDialog d = new MessageDialog( f, s);

      //d.dispose();  // HACK! depending on where you pop these up
      //f.dispose();  // you may need to comment these lines out.
   }




   //////////////////////////////////////////////////////////////////////
   //  Return the current Java Version information in a string.
   //  There are no security restrictions on this information.
   //////////////////////////////////////////////////////////////////////

   /**
    Return a string with the current Java version.
    @return Version string.
    */

   public static String getJavaVersion()
   {
      String javaVer     = System.getProperty("java.version");
      String javaVendor  = System.getProperty("java.vendor");
      String javaAPIVer  = System.getProperty("java.class.version");

      return  "Java "+javaVer+", API "+javaAPIVer+", "+javaVendor;
   }




   //////////////////////////////////////////////////////////////////////
   //  Return the current Operating System Version information in a string
   //  There are no security restrictions on this information.
   //////////////////////////////////////////////////////////////////////

   /**
    Return a string with the current operating system name and version.
    @return OS name & version string.
    */

   public static  String getOSVersion()
   {
      String osName      = System.getProperty("os.name");
      String osArch      = System.getProperty("os.arch");
      String osVersion   = System.getProperty("os.version");

      return osName+", version "+osVersion+", on "+osArch;
   }



   //////////////////////////////////////////////////////////////////////
   //  Cause the current thread to sleep for given milliseconds
   //////////////////////////////////////////////////////////////////////

   /**
    Cause the current thread to sleep for a given number is milliseconds.
    @param milliseconds Time to sleep.
    */

   public static void sleep( int milliseconds)
   {
      try {
         Thread.currentThread().sleep( milliseconds);
      }
      catch (Exception e) {}
   }

   

   
   //////////////////////////////////////////////////////////////////////
   //  Return true if we are "trusted" with no security restrictions.
   //////////////////////////////////////////////////////////////////////

   /**
    Return true if we are "trusted" with no security restrictions.
    @return True if we are a in "trusted" mode.
    */

   public static boolean isTrusted()
   {
      if ( trustCheck)
         return trustedMode;

      trustCheck = true;

      try {
         String jdir = System.getProperties().getProperty("java.home");

         return trustedMode = true;
      }
      catch (Exception e) { return trustedMode = false; }
   }
   



   //////////////////////////////////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////
   //  Private Members
   //////////////////////////////////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////




   private static final String SER_SEP = "\0";

   private static final String padd = new String("                ");

   private static int          nextCorner = 0;
   private static Container    cornerComponent = null;

   private static Hashtable    fileCache = new Hashtable(32,32);

   private static boolean      trustCheck  = false;
   private static boolean      trustedMode = false;



   //////////////////////////////////////////////////////////////////////
   // Format a string according to f string.  The formatting is very
   // similar to printf() in 'C', only one variable may be formatted
   // and the specification is NOT preceeded with the '%' character.
   // String and integer types are supports, justification, leading/
   // trailing zeros, and base conversion.
   //////////////////////////////////////////////////////////////////////

   private static String _format( String fmt, String vs, long vl)
   {
      if ( fmt == null || fmt.equals(""))
         return "";

      char[] f = fmt.toCharArray();

      int pos, top = f.length;   char c = '0';


      boolean rightJustify = false;
      char    paddChar     = ' ';
      int     len          = 0;

      switch ( (c = f[0])) {
         case '-': rightJustify = true;   break;
         case '0': paddChar     = '0';    break;       // padding zeros?
         default:  len = (int) (c-'0');   break;
      }

      if ( top > 1 && f[1] == '0' && len == 0)  // padding zeros?
         paddChar = '0';


      // Complete the field length assesment

      for ( pos = 1; pos < top; pos++) {
         if ( (c = f[pos]) >= '0' && c <= '9')
            len = (len * 10) + (int) (c-'0');
         else
            break;
      }


      if ( pos == top)
         return padd( "?", paddChar, len, rightJustify);;

      // locate any suffix after the typespec

      StringBuffer suffix = new StringBuffer(32);

      for ( int i = pos+1; i < top; i++)
         suffix.append(f[i]);
         
      // act on the typespec, applying what we already know...

      switch (f[pos]) {
         case 's': return padd( vs+suffix.toString(),          paddChar, len, rightJustify);
         case 'd': return padd( Long.toString( vl, 10)+suffix, paddChar, len, rightJustify);
         case 'x': return padd( Long.toString( vl, 16)+suffix, paddChar, len, rightJustify);
         case 'o': return padd( Long.toString( vl,  8)+suffix, paddChar, len, rightJustify);
         case 'b': return padd( Long.toString( vl,  2)+suffix, paddChar, len, rightJustify);
         case 'X': return padd( 
                      (Long.toString( vl, 16)).toUpperCase()+suffix, paddChar, len, rightJustify);

         default:  return padd( "?", paddChar, len, rightJustify);
      }
   }
}