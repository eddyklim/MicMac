import java.awt.Dialog;
import java.awt.Frame;
import java.awt.Color;
import java.awt.Event;
import java.awt.Container;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Panel;
import java.awt.Label;
import java.awt.GridLayout;

import java.util.StringTokenizer;


//////////////////////////////////////////////////////////////////////
// 
//   Post a multi-line dialog box like the sort used for About boxes.
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 Pop-up a generic dialog box
 */

public class MessageDialog extends Dialog
{
   ///////////////////////////////////////////////////////////////////
   // Constructor
   ///////////////////////////////////////////////////////////////////

   /**
    Pop-up a dialog box with the given message.
    @param parent Frame to which focus returns.
    @param string Message to display, may contain newlines.
    */

   public MessageDialog( Frame parent, String message) 
   {
      super( parent, true);

      this.parent = parent;

      setBackground( background);

      setFont( new Font("Sanserif", Font.BOLD, 12));

      Panel p = new Panel();

      p.setBackground( background);

      p.add( (buttonOk = new Button("OK")));
      add("South", p);

      Label l;

      add("North", (p = new Panel())); p.setBackground( background); p.add( (l = new Label(" "))); l.setBackground( background);
      add("East",  (p = new Panel())); p.setBackground( background); p.add( (l = new Label(" "))); l.setBackground( background);
      add("West",  (p = new Panel())); p.setBackground( background); p.add( (l = new Label(" "))); l.setBackground( background);

      StringTokenizer s = new StringTokenizer( message, "\n");

      Panel p1 = new Panel(); p1.setBackground( background);

      p1.setLayout( new GridLayout(s.countTokens()+1,1, 0, 0));


      while ( s.hasMoreTokens()) {
         p1.add( (l = new Label(" "+s.nextToken()+" ", Label.CENTER)));
         l.setBackground( background);
      }

      p1.add( (l = new Label(" ")));  l.setBackground( background);

      add("Center", p1);

      pack();

      Util.centerContainer(this);

      show();
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Public Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   public boolean handleEvent( Event e) 
   {
      if ( e.id == Event.ACTION_EVENT || e.id == Event.WINDOW_DESTROY ) {
         hide();

         parent.requestFocus();

         dispose();
         return true;
      }
      
      return super.handleEvent(e);
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Private Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   private static final Color background = new Color( 255,255,204);

   private Frame  parent   = null;
   private Button buttonOk;
}

