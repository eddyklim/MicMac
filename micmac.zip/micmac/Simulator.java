import java.applet.Applet;

import java.awt.Frame;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;

import java.util.Properties;
import java.util.Vector;
import java.util.StringTokenizer;

import java.net.URL;
import java.net.URLConnection;


//////////////////////////////////////////////////////////////////////
// 
//  Instances of this class are the actual MicMac simulators.  The
//  simulator calls an instance of MicMac canvas to update the
//  visble parts of the simulation.  There are really two simulators
//  in one here; each Mic machine cycle phase has a fast and slow
//  version. The slow version updates the canvas, while the fast
//  one is for flat-out speed.  They are identical copies except
//  that the fast version has the UI stuff stripped-out. (If you
//  need to modify any of the phases substantially, you might find
//  it easier to get it working in the UI mode, then copy the code
//  into the fast version and strip the I/O yourself.
//
//  A Mic machine cycle has four phases.
//
//  This class is implemented as a thread so that it can cause
//  itself to run continously by repeatidly single-stepping itself.
//  This works well and gives the UI a chance to respond to the user.
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 Mic instruction interpreter.
 @see MicMac
 @see MicMacMake
 @see MicMacCanvas
 */

public final class Simulator extends Thread
{
   //////////////////////////////////////////////////////////////////////
   //  Constructors
   //////////////////////////////////////////////////////////////////////

   /**
    Create a simulator for this MicMac session.
    @param applet Reference to applet, or null if in application mode.
    @param parent Frame to which focus returns
    @param ui User interface canvas to callback
    */

   public Simulator( Applet applet) { this( applet, null, null); }


   public Simulator( Applet applet, Frame parent, MicMacCanvas ui) 
   { 
      this.userInterface = ui;
      this.applet = applet; 
      parentFrame = parent;
      
      start();  
   }




   //////////////////////////////////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////
   //  Public Members
   //////////////////////////////////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////




   public static final String DEFAULT_EXTENSION = "sim";
   public static final String DEFAULT_SIM_NAME  = "Simulator";  // Used by serializer

   public static final int MAXCYCLES  =   50;   // Maximum Mic cycles allowed for a Mac cycle
   public static final int CORE_SIZE  = 4096;   // Size of main memory
   public static final int STORE_SIZE =  256;   // Size of microstore
   public static final int TRACE_SIZE =  256;   // Max steps to trace
   public static final int REGS       =   16;   // Max number of registers

   public static int CONSOLE_INPUT_REG  = 4092; // Memory-mapped
   public static int CONSOLE_ISTAT_REG  = 4093; // addresses for 
   public static int CONSOLE_OUTPUT_REG = 4094; // Console I/O
   public static int CONSOLE_OSTAT_REG  = 4095;

   public static final int RESET_PHASE = 4;      // For mic step sequencer
   public static final int HALT_PHASE  = 5;




   //////////////////////////////////////////////////////////////////////
   //  Next Mic Phase
   //////////////////////////////////////////////////////////////////////

   /**
    Advance by one Mic machine cycle phase visibly.
    */

   public void nextMicPhase()
   {
      switch (micPhase) {
         case 0:  micPhase++;                phase0();   break;
         case 1:  micPhase++;                phase1();   break;
         case 2:  micPhase++;                phase2();   break;
         case 3:  micPhase = 0;  micCycle++; phase3();   break;

         case RESET_PHASE: micPhase = 0;                 break;
         case HALT_PHASE:                                break;
      }
   }


   /**
    Advance by one Mic machine cycle phase quickly.
    */

   public void nextMicPhaseFast()
   {
      switch (micPhase) {
         case 0:  micPhase++;                phase0Fast();  break;
         case 1:  micPhase++;                phase1Fast();  break;
         case 2:  micPhase++;                phase2Fast();  break;
         case 3:  micPhase = 0;  micCycle++; phase3Fast();  break;

         case RESET_PHASE: micPhase = 0;                    break;
         case HALT_PHASE:                                   break;
      }
   }





   //////////////////////////////////////////////////////////////////////
   //  Next Mic Cycle
   //////////////////////////////////////////////////////////////////////

   /**
    Advance by one Mic machine cycle visibly.
    */

   public void nextMicCycle()
   {
      while ( micPhase != 0)     // Sync to cycle boundry
         nextMicPhase();

      nextMicPhase();            // Now execute a full cycle...

      while ( micPhase != 0)
         nextMicPhase();
   }



   /**
    Advance by one Mic machine cycle quickly.
    */

   public void nextMicCycleFast()
   {
      while ( micPhase != 0)     // Sync to cycle boundry
         nextMicPhaseFast();

      nextMicPhaseFast();           // Now execute a full cycle...

      while ( micPhase != 0)
         nextMicPhaseFast();
   }





   //////////////////////////////////////////////////////////////////////
   //  Next Mac Cycle.  Continue for MAXCYCLES or till the PC changes.
   //////////////////////////////////////////////////////////////////////

   
   /**
    Advance by one Mac instruction visibly.
    */

   public void nextMacCycle()
   {
      long pc = PC;

      inCycle = true;

      if ( continuousExecution) {
         for (int i = 0; continuousExecution && i < MAXCYCLES && pc == PC; i++)
            nextMicCycle();
      }
      else {
         for (int i = 0; i < MAXCYCLES && pc == PC; i++)
            nextMicCycle();
      }

      macCycle++;

      inCycle = false;
   }



   /**
    Advance by one Mac instruction quickly.
    */

   public void nextMacCycleFast()
   {
      long pc = PC;

      inCycle = true;

      if ( continuousExecution) {
         for (int i = 0; continuousExecution && i < MAXCYCLES && pc == PC; i++)
            nextMicCycleFast();
      }
      else {
         for (int i = 0; i < MAXCYCLES && pc == PC; i++)
            nextMicCycleFast();
      }

      macCycle++;

      inCycle = false;
   }



   //////////////////////////////////////////////////////////////////////
   //  Display the next Mac source line, if possible.  We do this by
   //  sending a message to the UI
   //////////////////////////////////////////////////////////////////////

   
   /**
    Callback the user-interface to draw the current Mac instruction source line.
    */

   private void drawMacInstruction()
   {
      try {
         macInstructionText = macBreakpoints.getItem( (int) PC);
      }
      catch( Exception e) { macInstructionText = msgUndefinedAt; }
      
      if ( macTraceEnable)
         addTrace( "", macInstructionText);

      if ( userInterface != null)
         userInterface.drawMacInstruction( macInstructionText);
   }




   //////////////////////////////////////////////////////////////////////
   //  Reset the simulator.  Changes here need to stay in sync with
   //  the temporary registers in the UI -- Sorry, there does not seem
   //  to be a clean & fast way to do this -- I had to choose fast!
   //////////////////////////////////////////////////////////////////////

   /**
    Reset the simulator and the computer it models.
    */

   public void reset()
   {
      // Reset processor state

      MIR = AMUX = ALU = SHIFT = LatchA = LatchB = 0;  MPC = MAR = MBR = 0;

      PC = AC = IR = TIR = A = B = C = D = E = F = 0;

      CZero  =  0;
      CPlus  =  1;
      CMinus = -1;

      AMask  = 0x0FFF;
      SMask  = 0x00FF;

      SP     = 0x0FB4;

      Zero   = Negative = false;


      core[ CONSOLE_INPUT_REG] = 0;
      core[ CONSOLE_ISTAT_REG] = 0;
      core[ CONSOLE_OUTPUT_REG] = 0;
      core[ CONSOLE_OSTAT_REG] = 0xFFFF;


      // Reset control

      micCycle = macCycle = 0;

      micPhase = RESET_PHASE;

      if ( userInterface != null)
         userInterface.reset();
   }




   //////////////////////////////////////////////////////////////////////
   // Update the user interface with current register values
   //////////////////////////////////////////////////////////////////////

   /**
    Callback the user-interface to redraw all the visible parts of the simulator.
    */

   public void updateEntireUserInterface()
   {
      if ( userInterface != null) {
         int oldLevel = userInterface.getRedrawLevel();

         userInterface.setRedrawLevel( MicMacCanvas.REDRAW_FULL);

         userInterface.refreshRegisters();
         userInterface.drawMicInstruction( micInstructionText);
         userInterface.drawMacInstruction( macInstructionText);

         userInterface.setRedrawLevel( oldLevel);
      }
   }



   //////////////////////////////////////////////////////////////////////
   // Start the simulator:  Start the cycle-stepping thread
   //////////////////////////////////////////////////////////////////////

   /**
    Start contiuous execution of the simulator (continous stepping).
    */

   public void go()
   { 
      continuousExecution = true; 
   }



   //////////////////////////////////////////////////////////////////////
   // Halt the simulator
   //////////////////////////////////////////////////////////////////////

   /**
    Halt the simulator.
    */

   public void halt(String s)
   { 
      continuousExecution = false; 

      if ( s != null)
         parentFrame.setTitle( "   "+s);
   }



   //////////////////////////////////////////////////////////////////////
   // Simulator executing?
   //////////////////////////////////////////////////////////////////////

   /**
    Return true if the simulator is continuously executing a MicMac program.
    @return True if the simulator is continuously executing.
    */

   public boolean isRunning()
   {
      return continuousExecution;
   }



   //////////////////////////////////////////////////////////////////////
   // These methods let outsiders manipulate the simulator's insides
   //////////////////////////////////////////////////////////////////////
   


   //////////////////////////////////////////////////////////////////////
   // Fetch/Store a core location or clear the whole thing
   //////////////////////////////////////////////////////////////////////

   /**
    Return the addressed value of Mac memory.
    @return Memory value.
    */

   public int  fetchCore( int address)              { return (int) core[address]; }

   /**
    Store a value into Mac memory at the given address.
    */

   public void storeCore( int address, int value)   { core[address] = value & 0xFFFF; }

   /**
    Clear Mac main memory.
    */

   public void clearCore()                          { Util.fillArray( core, 0); }


   /**
    Produce a Mac core-dump.
    @return Core-dump.
    */

   public String dumpCore()         { return dumpMemory(core, "-018bb "); }

   /**
    Load Mac memory from a core-dump string.
    @param text Textual form of Mac memory.
    */

   public void   loadCore(String text) { loadMemory( core, text); }
   

   //////////////////////////////////////////////////////////////////////
   // Fetch/Store a micro(store) location or clear the whole thing
   //////////////////////////////////////////////////////////////////////

   /**
    Return the addressed value of Mic microstore.
    */

   public long fetchStore( int address)             { return store[address]; }


   /**
    Store a value into the addressed location of Mic microstore.
    */

   public void storeStore( int address, long value) { store[address] = value & 0xFFFFFFFF; }

   /**
    Clear the Mic microstore.
    */

   public void clearStore()                         { Util.fillArray( store, 0); }


   /**
    Return a dump of Mic microstore.
    @return Microstore dump.
    */

   public String dumpStore()                        { return dumpMemory(store, "-034bb "); }


   /**
    Load Mic microstore from a microstore dump string.
    @param text Textual form of Mic microstore.
    */

   public void   loadStore(String text)             { loadMemory( store, text); }


   //////////////////////////////////////////////////////////////////////
   // Fetch an addressed register
   //////////////////////////////////////////////////////////////////////

   /**
    Return the value of an addressed Mic register.
    */

   public long fetchReg( int address)
   {
      switch (address) {
         case 0:  return 0xFFFF & PC;
         case 1:  return 0xFFFF & AC;
         case 2:  return 0xFFFF & SP;
         case 3:  return 0xFFFF & IR;
         case 4:  return 0xFFFF & TIR;
         case 5:  return 0xFFFF & CZero;
         case 6:  return 0xFFFF & CPlus;
         case 7:  return 0xFFFF & CMinus;
         case 8:  return 0xFFFF & AMask;
         case 9:  return 0xFFFF & SMask;
         case 10: return 0xFFFF & A;
         case 11: return 0xFFFF & B;
         case 12: return 0xFFFF & C;
         case 13: return 0xFFFF & D;
         case 14: return 0xFFFF & E;
         case 15: return 0xFFFF & F;
         default: return 0;
      }
   }



   //////////////////////////////////////////////////////////////////////
   // Return registers as an array
   //////////////////////////////////////////////////////////////////////

   /**
    Return all the Mic registers in the form of an array.
    @return Registers.
    */

   public long[] fetchRegArray()
   {
      long[] a = new long[REGS];

      for ( int i = 0; i < REGS; i++)
         a[i] = fetchReg(i);

      return a;
   }



   
   //////////////////////////////////////////////////////////////////////
   // Store given array to registers
   //////////////////////////////////////////////////////////////////////

   /**
    Store a given array of values into the Mic register file.
    */

   public void storeRegArray( long[] array)
   {
      for ( int i = 0; i < REGS; i++)
         storeReg(i, array[i]);
   }



   //////////////////////////////////////////////////////////////////////
   // Store to an addressed register
   //////////////////////////////////////////////////////////////////////

   /**
    Store a value to a numerically addressed Mic register using.
    */

   public void storeReg( int address, long value)
   {
      switch (address) {
         case 0:  PC       = value & 0x0FFF;  break;
         case 1:  AC       = value;  break;
         case 2:  SP       = value & 0x0FFF;  break;
         case 3:  IR       = value;  break;
         case 4:  TIR      = value;  break;
         case 5:  CZero    = value;  break;
         case 6:  CPlus    = value;  break;
         case 7:  CMinus   = value;  break;
         case 8:  AMask    = value;  break;
         case 9:  SMask    = value;  break;
         case 10: A        = value;  break;
         case 11: B        = value;  break;
         case 12: C        = value;  break;
         case 13: D        = value;  break;
         case 14: E        = value;  break;
         case 15: F        = value;  break;
      }
   }



   //////////////////////////////////////////////////////////////////////
   // Return a register's name given its register number
   //////////////////////////////////////////////////////////////////////

   /**
    Return a Mic register's name given its numeric address in the register file.
    @return Register name.
    */

   public static String regName( int address)
   {
      switch (address) {
         case 0:  return "pc";
         case 1:  return "ac";
         case 2:  return "sp";
         case 3:  return "ir";
         case 4:  return "tir";
         case 5:  return "zero";
         case 6:  return "plus";
         case 7:  return "minus";
         case 8:  return "amask";
         case 9:  return "smask";
         case 10: return "a";
         case 11: return "b";
         case 12: return "c";
         case 13: return "d";
         case 14: return "e";
         case 15: return "f";
         default: return "???";
      }
   }



   //////////////////////////////////////////////////////////////////////
   // Get and Set Processor Flags
   //////////////////////////////////////////////////////////////////////

   /**
    Return the value of the ALU zero flag.
    @return Zero flag.
    */

   public boolean getZero()      { return Zero; }


   /**
    Return the value of the ALU negative flag.
    @return Nagative flag.
    */

   public boolean getNegative()  { return Negative; }


   /**
    Set the ALU's zero flag.
    @param New zero flag value.
    */

   public void setZero( boolean b)     { Zero = b; }

   /**
    Set the ALU's negative flag.
    @param New negative flag value.
    */

   public void setNegative( boolean b) { Negative = b; }



   //////////////////////////////////////////////////////////////////////
   // Get Mic & Mac Source & Build Listing
   //////////////////////////////////////////////////////////////////////


   /**
    Get the current Mic source text from the simulator structure.
    (Not used at this time.)
    */

   public String getMicSource()  { return micSource; }

   /**
    Get the current Mac source text from the simulator structure.
    (Not used at this time.)
    */

   public String getMacSource()  { return macSource; }

   /**
    Get the current MicMac source name from the simulator structure.
    */

   public String getSourceName()          { return sourceName; }

   /**
    Get the current MicMic source text from the simulator structure.
    */

   public String getSource()              { return source; }

   /**
    Set MicMac source text in the simulator structure.
    */

   public void   setSource( String s)     { source = s; }

   /**
    Set MicMac source text name in the simulator structure.
    */

   public void   setSourceName( String s) { sourceName = s; }


   //////////////////////////////////////////////////////////////////////
   // Get/Set Mic & Mac Breakpoints
   //////////////////////////////////////////////////////////////////////

   /**
    Return the current Mic breakpoint list
    @return Mic breakpoint list.
    */

   public FastList getMicBreakpoints() { return micBreakpoints; }


   /**
    Return the current Mac breakpoint list
    @return Mac breakpoint list.
    */

   public FastList getMacBreakpoints() { return macBreakpoints; }


   /**
    Set the current Mic breakpoint list
    @param Mic breakpoint list.
    */

   public void setMicBreakpoints(FastList l) { micBreakpoints = l; }


   /**
    Set the current Mac breakpoint list
    @param Mac breakpoint list.
    */

   public void setMacBreakpoints(FastList l) { macBreakpoints = l; }


   //////////////////////////////////////////////////////////////////////
   // Get Mac Instruction Definitions
   //////////////////////////////////////////////////////////////////////

   /**
    Return Mac instruction definitions in text form.
    (Not used at this time.)
    */

   public String     getMacDefines()         { return macDefines; }

   /**
    Return Mac instruction definition list.
    (Not used at this time.)
    */

   public FastList   getMacInstructions() { return macInstructions; }



   //////////////////////////////////////////////////////////////////////
   // Set the method by which Mac tracing logs the next Mac instruction.
   //////////////////////////////////////////////////////////////////////

   /**
    Set Mac Trace on PC change flag.  If true, then the execution tracer
    will log a new Mac instruction at the last Mic machine cycle phase in
    the Mic instruction that changes the PC.  Otherwise, log a new Mac
    instruction at the begining of a new Mic machine cycle where MPC
    is zero.
    @param flag New PC Trace state.
    */

   public void macTraceOnPC( boolean flag)
   {
      macTraceOnPCchange = flag;
   }


   //////////////////////////////////////////////////////////////////////
   // Get Trace Vectors & Tracing control
   //////////////////////////////////////////////////////////////////////

   /**
    Enable Mic execution tracing if true.
    @param flag New trace state.
    */

   public void micTraceEnable( boolean b) { micTraceEnable = b; }


   /**
    Enable Mac execution tracing if true.
    @param flag New trace state.
    */

   public void macTraceEnable( boolean b) { macTraceEnable = b; }


   /**
    Clear the execution trace memory.
    */

   public synchronized void   clearTrace()
   { 
      trace        = null;
      traceCounter = 0;
      trace = new String[TRACE_SIZE];
   }



   /**
    Log a string into the next available trace memory slot.
    @param text Text to log.
    */

   public void addTrace( String prefix, String text)
   {
      trace[ traceCounter] = prefix + text;  traceCounter++;

      traceCounter %= TRACE_SIZE;
   }



   /**
    Return the execution trace.
    @return Execution trace text.
    */

   public synchronized String getTrace()
   {
      String s = "";

      int next  = traceCounter + 1;  next %= TRACE_SIZE;
      int items = 0;

      for ( ; next != traceCounter; next++, next %= TRACE_SIZE) {
         if ( trace[next] != null) {
            s += trace[next] + "\n";
            items++;
         }
      }

      return "" + items + ((items == 1) ? " item:" : " items:") + "\n" + s;
   }



   //////////////////////////////////////////////////////////////////////
   // These methods let encapsulate the microinstruction layout.
   //////////////////////////////////////////////////////////////////////



   // Instruction Decoding:  Return the requested microinstruction field...

   /**
    Decode the AMUX field of the Mic microinstruction.
    @param i Instruction.
    */

   public static boolean   AMUX(long i)   { return (i & 0x80000000) != 0 ? true : false; }

   
   /**
    Decode the COND field of the Mic microinstruction.
    @param i Instruction.
    */

   public static int       COND(long i)   { return (int) (i & 0x60000000) >> 29; }

   
   /**
    Decode the ALU field of the Mic microinstruction.
    @param i Instruction.
    */

   public static int       ALU(long i)    { return (int) (i & 0x18000000) >> 27; }

   
   /**
    Decode the SH field of the Mic microinstruction.
    @param i Instruction.
    */

   public static int       SH(long i)     { return (int) (i & 0x06000000) >> 25; }

   
   /**
    Decode the MBR field of the Mic microinstruction.
    @param i Instruction.
    */

   public static boolean   MBR(long i)    { return (i & 0x01000000) != 0 ? true : false; }

   
   /**
    Decode the MAR field of the Mic microinstruction.
    @param i Instruction.
    */

   public static boolean   MAR(long i)    { return (i & 0x00800000) != 0 ? true : false; }

   
   /**
    Decode the RD field of the Mic microinstruction.
    @param i Instruction.
    */

   public static boolean   RD(long i)     { return (i & 0x00400000) != 0 ? true : false; }

   
   /**
    Decode the WR field of the Mic microinstruction.
    @param i Instruction.
    */

   public static boolean   WR(long i)     { return (i & 0x00200000) != 0 ? true : false; }

   
   /**
    Decode the ENC field of the Mic microinstruction.
    @param i Instruction.
    */

   public static boolean   ENC(long i)    { return (i & 0x00100000) != 0 ? true : false; }
   
   
   /**
    Decode the C register address field of the Mic microinstruction.
    @param i Instruction.
    */

   public static int       C(long i)      { return (int) (i & 0x000F0000) >> 16; }

   
   /**
    Decode the B register address field of the Mic microinstruction.
    @param i Instruction.
    */

   public static int       B(long i)      { return (int) (i & 0x0000F000) >> 12; }

   
   /**
    Decode the A register address field of the Mic microinstruction.
    @param i Instruction.
    */

   public static int       A(long i)      { return (int) (i & 0x00000F00) >> 8; }


   /**
    Decode the branch address field of the Mic microinstruction.
    @param i Instruction.
    */

   public static int       ADDR(long i)   { return (int) (i & 0x000000FF); }



   //////////////////////////////////////////////////////////////////////
   // Save & Restore...
   //////////////////////////////////////////////////////////////////////
   


   //////////////////////////////////////////////////////////////////////
   //  Save simulator state
   //////////////////////////////////////////////////////////////////////

   /**
    Save an externalized form of the simulator to a given file name.
    @param name File name.
    */

   public synchronized void save( String name)
   {
      int    i;
      String t, u;
      OutputStream os;

      name = name == null || name.equals("") ? DEFAULT_SIM_NAME + "." + DEFAULT_EXTENSION: name;

      try {
         Util.log("Save simulation: '" + name + "'");

         sourceName = name;

         os = (OutputStream) new BufferedOutputStream( new FileOutputStream( name));

         Properties p = new Properties();

         //
         // Save Source Code
         //

         p.put( "source",     Util.serializeString( source));

         p.put( "micSource",  Util.serializeString( micSource));
         p.put( "macSource",  Util.serializeString( macSource));
         p.put( "macDefines", Util.serializeString( macDefines));


         //
         // Save Processessor State
         //

         p.put( "regs",     Util.serializeArray(   fetchRegArray()));
         p.put( "store",    Util.serializeArray(   store));
         p.put( "core",     Util.serializeArray(   core));
         p.put( "Negative", Util.serializeBoolean( Negative));
         p.put( "Zero",     Util.serializeBoolean( Zero));

         p.put( "MPC",      Util.serializeInt(  MPC));
         p.put( "MIR",      Util.serializeLong( MIR));
         p.put( "AMUX",     Util.serializeLong( AMUX));
         p.put( "ALU",      Util.serializeLong( ALU));
         p.put( "SHIFT",    Util.serializeLong( SHIFT));
         p.put( "MAR",      Util.serializeInt(  MAR));
         p.put( "MBR",      Util.serializeInt(  MBR));
         p.put( "LatchA",   Util.serializeLong( LatchA));
         p.put( "LatchB",   Util.serializeLong( LatchB));

         p.put( "micPhase", Util.serializeInt(  micPhase));
         p.put( "micCycle", Util.serializeInt(  micCycle));
         p.put( "macCycle", Util.serializeInt(  macCycle));


         //
         // Save Debugging State
         //

         p.put( "micTraceEnable",     Util.serializeBoolean( micTraceEnable));
         p.put( "macTraceEnable",     Util.serializeBoolean( macTraceEnable));
         p.put( "traceCounter",    Util.serializeInt( traceCounter));
         p.put( "trace",           Util.serializeArray( trace));
         p.put( "micBreakpoints",  Util.serializeList( micBreakpoints));
         p.put( "macBreakpoints",  Util.serializeList( macBreakpoints));
         p.put( "macInstructions", Util.serializeList( macInstructions));


         p.save( os, name+"'s properties");

         os.close();
      }
      catch( Exception e) {System.out.println(e);}

      System.gc();
   }


   //////////////////////////////////////////////////////////////////////
   //  Restore simulator state
   //////////////////////////////////////////////////////////////////////

   /**
    Restore an 'externalized' simulation from a given file name.
    @param name File name.
    */

   public synchronized void load( String name)
   {
      InputStream is;

      name = name == null || name.equals("") ? DEFAULT_SIM_NAME + "." + DEFAULT_EXTENSION: name;

      try {
         Util.log("Load simulation: '" + name + "'");

         sourceName = name;

         is = (InputStream) new BufferedInputStream( new FileInputStream( name));

         Properties p = new Properties();

         p.load( is);


         //
         // Restore Source Code
         //

         source     = Util.deserializeString( p.getProperty("source"));

         micSource  = Util.deserializeString( p.getProperty("micSource"));
         macSource  = Util.deserializeString( p.getProperty("macSource"));
         macDefines = Util.deserializeString( p.getProperty("macDefines"));


         //
         // Save Processessor State
         //

         long regs[] = fetchRegArray();
            Util.deserializeArray( p.getProperty("regs"),  regs);
         storeRegArray( regs);


         Util.deserializeArray( p.getProperty("store"), store);
         Util.deserializeArray( p.getProperty("core"),  core);

         
         Negative = Util.deserializeBoolean( p.getProperty("Negative"));
         Zero     = Util.deserializeBoolean( p.getProperty("Zero"));



         MPC      = Util.deserializeInt(  p.getProperty("MPC"));

         MIR      = Util.deserializeLong( p.getProperty("MIR"));

         AMUX     = Util.deserializeLong( p.getProperty("AMUX"));
         ALU      = Util.deserializeLong( p.getProperty("ALU"));
         SHIFT    = Util.deserializeLong( p.getProperty("SHIFT"));
         MAR      = Util.deserializeInt(  p.getProperty("MAR"));
         MBR      = Util.deserializeInt(  p.getProperty("MBR"));
         LatchA   = Util.deserializeLong( p.getProperty("LatchA"));
         LatchB   = Util.deserializeLong( p.getProperty("LatchB"));

         micPhase = Util.deserializeInt( p.getProperty("micPhase"));
         micCycle = Util.deserializeInt( p.getProperty("micCycle"));
         macCycle = Util.deserializeInt( p.getProperty("macCycle"));


         //
         // Save Debugging State
         //

         micTraceEnable  = Util.deserializeBoolean( p.getProperty("micTraceEnable"));
         macTraceEnable  = Util.deserializeBoolean( p.getProperty("macTraceEnable"));
         traceCounter = Util.deserializeInt(     p.getProperty("traceCounter"));

         Util.deserializeArray( p.getProperty("trace"), trace);
         Util.deserializeList(  p.getProperty("micBreakpoints"),  micBreakpoints);
         Util.deserializeList(  p.getProperty("macBreakpoints"),  macBreakpoints);
         Util.deserializeList(  p.getProperty("macInstructions"), macInstructions);

         is.close();
      }
      catch( Exception e) {System.out.println(e);}

      System.gc();
   }



   //////////////////////////////////////////////////////////////////////
   // What we do as a thread...
   //////////////////////////////////////////////////////////////////////



   //////////////////////////////////////////////////////////////////////
   //  Execute continously
   //////////////////////////////////////////////////////////////////////

   /**
    Start the continuous execution of the current simulation.  This is done
    by repeatidly invoking our own Mic machine cycle phase method.
    */

   public void run()
   {
      try {  // Just temporary till we find that null pointer exception in Linux!

      while (true) {

         if ( core[ CONSOLE_OSTAT_REG] == 0) {

            if ( userInterface != null) {
               userInterface.ttyChar(
                  (char) (0xFF & core[ CONSOLE_OUTPUT_REG]));
            }
            
            core[ CONSOLE_OSTAT_REG]  = 0xFFFF;
         }

         // Run the simulation a step at a time...

         if (continuousExecution && !inCycle) {
            if (fastSimulate)
               nextMacCycleFast();
            else
               nextMacCycle();
         }
         else
            Util.sleep(100);
         
         yield();
      }


      }
      catch( Exception e) {
         System.out.println("Reported from Simulator.class: ");
         System.out.println("   Exeception: " + e.getMessage());
         e.printStackTrace();
      }
   }




   //////////////////////////////////////////////////////////////////////
   //  Memory & Microstore stuff
   //////////////////////////////////////////////////////////////////////



   //////////////////////////////////////////////////////////////////////
   //  Dump the given long array in "address value" form
   //  We don't want to waste time/space dumping runs of zeros -- so if
   //  a run is detected, indicate the run with elipses and done start
   //  dumping until the run is over.  Runs of non-zero values are dumped
   //  in the normal manner.
   //////////////////////////////////////////////////////////////////////

   /**
    Dump an array (presumed to be a memory image) in a dump textual form.
    @param core Memory array.
    @param format Format (radix, spacing) of the dump numeric values.
    @return Dump text.
    */

   public String dumpMemory( long[] core, String format)
   {
      String out = new String("");
      boolean series = false;
      int     top;
      long    lastm = 0;

      for (top = core.length-1; top >=0; top--)
         if ( core[top] != 0)
            break;

      
      for ( int i = 0; i <= top; i++) {

         if ( core[i] != lastm || lastm != 0) {
            series = false;

            out += Util.format("-06d  ", i) + 
                   Util.format(format, core[i]) + "\n";
         }
         else
         if ( !series) {
            out += "....  " + Util.format(format, 0) + "\n";
            series = true;
         }

         lastm = core[i];
      }

      return out;
   }




   //////////////////////////////////////////////////////////////////////
   //  Dump the registers like core & store, but with register names
   //////////////////////////////////////////////////////////////////////

   /**
    Dump the Mic register file in textual form with a given numeric format
    @param format Numeric format (radix, spacing).
    @return Dump.
    */

   public String dumpReg( String format)
   {
      String out = new String("");
      
      for ( int i = 0; i < REGS; i++) {
         out += Util.format("8s ", regName(i)) + 
                Util.format(format, fetchReg(i)) + "\n";
      }

      return out;
   }



   //////////////////////////////////////////////////////////////////////
   //  Load array from a string of lines in "address value" form.  The
   //  address and value may be expressed in decimal, hex, octal or binary.
   //  Ignore lines beginning with a period because these are "run"
   //  indicators (see dumpMemory()).  Note that the possible existence
   //  of NULL runs is facilitated by clearing the core array first.
   //////////////////////////////////////////////////////////////////////

   /**
    Load a textual dump image into a memory array.
    @param core Memory array to receive values.
    @param input Memory dump text input.
    */

   public void loadMemory( long[] core, String input)
   {
      StringTokenizer l = new StringTokenizer( input, "\n");

      int addr;  String tok;

      Util.fillArray( core, 0);

      while ( l.hasMoreTokens()) {
         StringTokenizer t = new StringTokenizer( l.nextToken(), " \t");

         tok = t.nextToken();

         if ( tok.charAt(0) == '.')
            continue;

         addr = (int) Util.parseValue( tok);

         if ( t.hasMoreTokens())
            core[addr] = Util.parseValue( t.nextToken());
      }
   }




   //////////////////////////////////////////////////////////////////////
   // Load the registers from a string like loadMemory()
   //////////////////////////////////////////////////////////////////////

   /**
    Load a register file dump back into the Mic register file.
    @param input Register file dump text input.
    */

   public void loadReg( String input)
   {
      StringTokenizer l = new StringTokenizer( input, "\n");

      int addr;  String reg;

      while ( l.hasMoreTokens()) {
         StringTokenizer t = new StringTokenizer( l.nextToken(), " \t");

         reg = t.nextToken(); addr = 0;

         for ( addr = 0; addr < REGS; addr++)
            if ( reg.equalsIgnoreCase( regName( addr)))
               break;
            
         if ( t.hasMoreTokens())
            storeReg( addr, (Util.parseValue( t.nextToken()) & 0xFFFF));
      }
   }


   //////////////////////////////////////////////////////////////////////
   //  Set simulation into high speed
   //////////////////////////////////////////////////////////////////////

   /**
    If true, use the 'fast' methods to execute Mic machine cycle phases 
    (without most user-interface updates.)
    @param flag New high speed state.
    */

   public void setHighSpeed( boolean flag) 
   { 
      fastSimulate = flag; 
   }




   //////////////////////////////////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////
   //  Private Members
   //////////////////////////////////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////




   // Processor State

   private long PC;        // Mac Program Counter
   private long AC;        // Mac Accumulator
   private long SP;        // Mac Stack Pointer
   private long IR;        // Instruction Register
   private long TIR;       // Temporary Instruction Register
   private long CZero;     // Constant Zero
   private long CPlus;     // Constant One
   private long CMinus;    // Constant Negative One
   private long AMask;     // Address Mask
   private long SMask;     // Mask
   private long A;         // General Purpose Register
   private long B;         // General Purpose Register
   private long C;         // General Purpose Register
   private long D;         // General Purpose Register
   private long E;         // General Purpose Register
   private long F;         // General Purpose Register

   private int  MPC;       // Mic Program Counter
   private long MIR;       // Mic Instruction Register
   private long AMUX;      // ALU Multiplexer
   private long ALU;       // ALU Results
   private long SHIFT;     // Shifter Results
   private int  MAR;       // Memory Address Register
   private int  MBR;       // Memory Buffer Register
   private long LatchA;    // A Bus Latch
   private long LatchB;    // B Bus Latch

   private boolean Zero;      // ALU Zero Flag
   private boolean Negative;  // ALU Negative Flag

   private long[] store = new long[STORE_SIZE]; // Mic Memory
   private long[] core  = new long[CORE_SIZE];  // Mac Memory


   // Simulator Control

   private int micPhase;   // Mic Subcycle 0-3
   private int micCycle;
   private int macCycle;

   private boolean macTraceOnPCchange  = false;

   private boolean continuousExecution = false;
   private boolean inCycle             = false;
   private boolean fastSimulate        = false;


   // User Interface items

   private Applet applet;  // Applet or Application (applet == null)

   private String micInstructionText  = "";                       // Current Mic instruction?
   private String macInstructionText  = "";                       // Current Mac instruction?

   private MicMacCanvas userInterface;
   private Frame        parentFrame;


   // Simulator Source

   static final String msgUndefinedAt = "No Source";

   private String sourceName = new String(DEFAULT_SIM_NAME+"."+DEFAULT_EXTENSION);
   private String source     = new String("");  // MicMac source

   private String micSource  = new String("");  // Mic program source
   private String macSource  = new String("");  // Mac program source
   private String macDefines = new String("");  // Instruction Definition
                                                // Source
   
   // Simulator Debug

   private FastList micBreakpoints  = new FastList();    // Breakpoint list
   private FastList macBreakpoints  = new FastList();    // Breakpoint list
   private FastList macInstructions = new FastList(); // Mac instruction list

   private String  trace[] = new String[TRACE_SIZE]; // trace memory
   private int     traceCounter = 0;                 // save next instr. here
   private boolean micTraceEnable  = false;
   private boolean macTraceEnable  = false;



   //////////////////////////////////////////////////////////////////////
   //  Phase 0 Processing: Fetch the next microinstruction.
   //////////////////////////////////////////////////////////////////////

   private void phase0()
   {
      if ( !macTraceOnPCchange && MPC == 0) {
         drawMacInstruction();

         try {
            if ( macBreakpoints.isSelected( (int) PC)) {
               halt("Halt at Mac Breakpoint.");
               updateEntireUserInterface();
            }
         }
         catch( Exception e) {}
      }



      MIR = store[ MPC];

      micCycle++;

      // Move this into the try section when breakpoints work...

      if ( userInterface != null)
         userInterface.phase0( MIR, MPC);

      try {
         micInstructionText = micBreakpoints.getItem( (int) MPC);

         if ( micBreakpoints.isFastSelected((int) MPC)) {
            halt("Halt at Mic Breakpoint.");
            updateEntireUserInterface();
         }
      }
      catch( Exception e) { micInstructionText = msgUndefinedAt; }
      
      if ( userInterface != null)
         userInterface.drawMicInstruction( micInstructionText);

      if ( micTraceEnable)
         addTrace( "   ", micInstructionText);
   }


   private void phase0Fast()
   {
      if ( !macTraceOnPCchange && MPC == 0) {
         try {
            if ( macBreakpoints.isFastSelected( (int) PC)) {
               halt("Halt at Mac Breakpoint.");
               micInstructionText = micBreakpoints.getItem( (int) MPC);
               macInstructionText = macBreakpoints.getItem( (int) PC);
               updateEntireUserInterface();
            }
         }
         catch( Exception e) {}
      }


      MIR = store[ MPC];

      micCycle++;

      try {
         if ( micBreakpoints.isFastSelected( (int) MPC)) {
            halt("Halt at Mic Breakpoint.");
            micInstructionText = micBreakpoints.getItem( (int) MPC);
            macInstructionText = macBreakpoints.getItem( (int) PC);
            updateEntireUserInterface();
         }
      }
      catch( Exception e) {}
   }






   //////////////////////////////////////////////////////////////////////
   //  Phase 1 Processing: Gate registers to buses & latch them.
   //////////////////////////////////////////////////////////////////////

   private void phase1()
   {
      LatchA = fetchReg( A( MIR));
      LatchB = fetchReg( B( MIR));

      if ( userInterface != null)
         userInterface.phase1( LatchA, LatchB);
   }


   private void phase1Fast()
   {
      LatchA = fetchReg( A( MIR));
      LatchB = fetchReg( B( MIR));
   }



   //////////////////////////////////////////////////////////////////////
   //  Phase 2 Processing: Compute latched values with ALU/Shifter.
   //  Load MAR if necessary.
   //////////////////////////////////////////////////////////////////////

   private void phase2()
   {
      // A comes from?

      long tA = AMUX = AMUX( MIR) ? MBR : LatchA;

      // Compute...

      switch ( ALU( MIR)) {
         case 0:  ALU = tA + LatchB;      break;   // Addition
         case 1:  ALU = tA & LatchB;      break;   // AND
         case 2:  ALU = tA;               break;   // Copy
         case 3:  ALU = ~tA;              break;   // NOT
      }


      // The results? 

      ALU &= 0xFFFF;

      Zero     = ALU == 0 ? true : false;    

      Negative = (ALU & 0x8000) > 0 ? true : false;


      // Now shift:

      switch ( SH( MIR)) {
         case 1:  SHIFT = ALU >> 1; break;
         case 2:  SHIFT = ALU << 1; break;

         //   3:  Unused shift 3 is used to halt the processor!

         default: SHIFT = ALU;      break;
      }


      // Load MAR?

      if ( MAR( MIR))
         MAR = (int) LatchB % CORE_SIZE;


      if ( userInterface != null)
         userInterface.phase2( ALU, SHIFT, Zero, Negative);
   }



   private void phase2Fast()
   {
      // A comes from?

      long tA = AMUX = AMUX( MIR) ? MBR : LatchA;

      // Compute...

      switch ( ALU( MIR)) {
         case 0:  ALU = tA + LatchB;      break;   // Addition
         case 1:  ALU = tA & LatchB;      break;   // AND
         case 2:  ALU = tA;               break;   // Copy
         case 3:  ALU = ~tA;              break;   // NOT
      }


      // The results? 

      ALU &= 0xFFFF;

      Zero     = ALU == 0 ? true : false;    

      Negative = (ALU & 0x8000) > 0 ? true : false;


      // Now shift:

      switch ( SH( MIR)) {
         case 1:  SHIFT = ALU >> 1; break;
         case 2:  SHIFT = ALU << 1; break;

         //   3:  Unused shift 3 is used to halt the processor!

         default: SHIFT = ALU;      break;
      }


      // Load MAR?

      if ( MAR( MIR))
         MAR = (int) LatchB % CORE_SIZE;
   }



   //////////////////////////////////////////////////////////////////////
   //  Phase 3 Processing: Gate shifter to C bus and store if required.
   //  Load MBR if necessary.
   //////////////////////////////////////////////////////////////////////

   private void phase3()
   {
      long pc = PC;

      if ( ENC( MIR))                     // Registers <- SHIFT
         storeReg( C( MIR), SHIFT);

      if ( MBR( MIR))                     // MBR <- SHIFT
         MBR = (int) SHIFT & 0xFFFF;

      if ( RD( MIR))                      // MBR <- memory[MAR]
         MBR = (int) core[ MAR] & 0xFFFF;

      if ( WR( MIR))                      // memory[MAR] <- MBR
         core[ MAR] = MBR;


      if ( macTraceOnPCchange && pc != PC) {
         drawMacInstruction();

         try {
            if ( macBreakpoints.isSelected( (int) PC))
               halt("Halt at Mac Breakpoint.");
         }
         catch( Exception e) {}
      }


      // Use the last instruction and ALU flags to determine the location
      // of the next microinstruction.


      switch ( COND( MIR)) {
         case 0:  MPC = MPC + 1;                            break;
         case 1:  MPC = Negative ?  ADDR( MIR) : MPC + 1;   break;
         case 2:  MPC = Zero ?      ADDR( MIR) : MPC + 1;   break;
         case 3:  MPC = ADDR( MIR);                         break;
      }

      MPC %= 256; // wrap around to the beginning again

      if ( userInterface != null)
         userInterface.phase3( MBR, core);


      if ( SH( MIR) == 3) { // Shifter code 3 is used to halt the processor
         halt("Processor Halt.");
         updateEntireUserInterface();
      }
   }



   private void phase3Fast()
   {
      if ( ENC( MIR))                     // Registers <- SHIFT
         storeReg( C( MIR), SHIFT);

      if ( MBR( MIR))                     // MBR <- SHIFT
         MBR = (int) SHIFT & 0xFFFF;

      if ( RD( MIR))                      // MBR <- memory[MAR]
         MBR = (int) core[ MAR] & 0xFFFF;

      if ( WR( MIR))                      // memory[MAR] <- MBR
         core[ MAR] = MBR;


      // Use the last instruction and ALU flags to determine the location
      // of the next microinstruction.


      switch ( COND( MIR)) {
         case 0:  MPC = MPC + 1;                            break;
         case 1:  MPC = Negative ?  ADDR( MIR) : MPC + 1;   break;
         case 2:  MPC = Zero ?      ADDR( MIR) : MPC + 1;   break;
         case 3:  MPC = ADDR( MIR);                         break;
      }

      MPC %= 256; // wrap around to the beginning again

      if ( SH( MIR) == 3) { // Shifter code 3 is used to halt the processor
         halt("Processor Halt.");

         try {
            micInstructionText = micBreakpoints.getItem( (int) MPC-1);
         }
         catch( Exception e) { micInstructionText = msgUndefinedAt; }

         try {
            macInstructionText = macBreakpoints.getItem( (int) PC-1);
         }
         catch( Exception e) { macInstructionText = msgUndefinedAt; }

         updateEntireUserInterface();
      }
   }
}

