import java.awt.List;

import java.util.StringTokenizer;
import java.util.Random;


/////////////////////////////////////////////////////////////////////////
//
//  A cute little class which sorts primative arrays, awt lists and stings.
//  The CombSort is the featured algorithm -- short, sweet & FAST!
//
//  Sort can sort arrays of ints, longs, floats, doubles, and Strings.
//  It can also sort items in an AWT List and lines in a String.
//
//  The sort defaults to ascending sequence but may be set to descending.
//
//
//  See the main() method for an example of how to use this class.  Also
//  study the Sort( List ) and Sort( String) constructors.
//
//  The CombSort was invented by Stephen Lacey and Richard Box; they
//  fully described in the April 1991 issue of Byte magazine pp 315-320
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 Sort sets of common data types using the Comb-sort algorithm
 */

public class Sort extends Object
{

   public static final int ASCEND  = 0;
   public static final int DESCEND = 1;
   

   //////////////////////////////////////////////////////////////////////
   // Constructors
   //////////////////////////////////////////////////////////////////////

   /**
    Sort an array of ints in ascending order.
    @param a Input array
    */

   public Sort( int[]    a) { combSort( a, ASCEND); }


   /**
    Sort an array of longs in ascending order.
    @param a Input array
    */

   public Sort( long[]   a) { combSort( a, ASCEND); }


   /**
    Sort an array of floats in ascending order.
    @param a Input array
    */

   public Sort( float[]  a) { combSort( a, ASCEND); }


   /**
    Sort an array of doubles in ascending order.
    @param a Input array
    */

   public Sort( double[] a) { combSort( a, ASCEND); }


   /**
    Sort an array of Strings in ascending order.
    @param a Input array
    */

   public Sort( String[] a) { combSort( a, ASCEND); }


   /**
    Sort an array of ints in a given direction.
    @param a Input array
    @param d Direction: ASCEND or DECEND.
    */

   public Sort( int[]    a, int d) { combSort( a, d); }


   /**
    Sort an array of longs in a given direction.
    @param a Input array
    @param d Direction: ASCEND or DECEND.
    */

   public Sort( long[]   a, int d) { combSort( a, d); }


   /**
    Sort an array of floats in a given direction.
    @param a Input array
    @param d Direction: ASCEND or DECEND.
    */

   public Sort( float[]  a, int d) { combSort( a, d); }


   /**
    Sort an array of doubles in a given direction.
    @param a Input array
    @param d Direction: ASCEND or DECEND.
    */

   public Sort( double[] a, int d) { combSort( a, d); }


   /**
    Sort an array of Strings in a given direction.
    @param a Input array
    @param d Direction: ASCEND or DECEND.
    */

   public Sort( String[] a, int d) { combSort( a, d); }


   //////////////////////////////////////////////////////////////////////
   // Sort the items of a AWT List. (does not preserve selection state)
   //////////////////////////////////////////////////////////////////////

   /**
    Sort the elements of a List in acending order.
    @param l List
    */

   public Sort( List l) { new Sort( l, ASCEND); }


   /**
    Sort the elements of a List in a given direction.
    @param l List
    @param d Direction: ASCEND or DECEND.
    */

   public Sort( List l, int direction)
   {
      int items;

      if ( l == null || (items = l.countItems()) < 2)
         return;

      String a[] = new String[ items];

      for ( int i = 0; i < items; i++)
         a[i] = l.getItem(i);

      new Sort( a, direction);

      l.clear();

      for ( int i = 0; i < items; i++)
         l.addItem( a[i]);
   }




   //////////////////////////////////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////
   //  Public Members
   //////////////////////////////////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////




   //////////////////////////////////////////////////////////////////////
   // Sort the lines of a string.  These are class methods
   //////////////////////////////////////////////////////////////////////

   /**
    Sort a set of lines in a String in ascending order.
    @param s Input string to sort.
    @return Sorted string of lines.
    */

   public static String string( String s)
   {
      return string( s, ASCEND);
   }


   /**
    Sort a set of lines in a String in a given direction.
    @param s Input string to sort.
    @param direction Sort order: ASCEND or DESCEND.
    @return Sorted string of lines.
    */

   public static String string( String s, int direction)
   {
      if ( s == null || s.equals(""))
         return s;

      int i;   // Count the number of lines in the string

      StringTokenizer t = new StringTokenizer( s, "\n", true);

      for ( i = 0; t.hasMoreTokens(); i++) {
         if (!(t.nextToken()).equals(""))
            if ( t.hasMoreTokens())
               t.nextToken();
      }


      // Make an array of strings, one element for each line

      t = new StringTokenizer( s, "\n", true);

      String a[] = new String[i];

      for ( i = 0; t.hasMoreTokens(); i++) {
         if (!(a[i] = t.nextToken()).equals(""))
            if ( t.hasMoreTokens())
               t.nextToken();
      }


      // Sort them and reassemble them into a string again

      new Sort( a, direction);    s = "";

      for ( i = 0; i < a.length; i++)
         s += a[i] + "\n";

      return s;
   }





   //////////////////////////////////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////
   //  Private Members
   //////////////////////////////////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////




   //////////////////////////////////////////////////////////////////////
   //  A series of CombSort routines to handle the numeric and String
   //  types.  I wish there was a cleaner way to do this, but I don't
   //  know of one now.
   //
   //  The CombSort is a Warp-speed version of the classic bubble sort.
   //  I'm using it because its' so easy to implement, yet nearly as
   //  fast as QuickSort.  The CombSort11 optimization is employed, see
   //  newGap() for details.
   //////////////////////////////////////////////////////////////////////

   private static void combSort( int[] a, int direction)
   {
      int i, top = a.length - 1, gap = top / 2; // set gap to 1/2 table size

      boolean swapped = true, test = false;

      while (swapped) {
         swapped = false;

         top = a.length - gap;

         for ( i = 0; i < top; i++) {
            test = a[i] > a[i+gap];

            test = direction == DESCEND ? !test:test;

            if ( test) {
               int t = a[i];
               a[i] = a[i+gap];
               a[i+gap] = t;
               swapped = true;
            }
         }

         gap = newGap( gap);
      }
   }

   //////////////////////////////////////////////////////////////////////

   private static void combSort( long[] a, int direction)
   {
      int i, top = a.length - 1, gap = top / 2;

      boolean swapped = true, test = false;

      while (swapped) {
         swapped = false;

         top = a.length - gap;

         for ( i = 0; i < top; i++) {
            test = a[i] > a[i+gap];

            test = direction == DESCEND ? !test:test;

            if ( test) {
               long t = a[i];
               a[i] = a[i+gap];
               a[i+gap] = t;
               swapped = true;
            }
         }

         gap = newGap( gap);
      }
   }

   //////////////////////////////////////////////////////////////////////

   private static void combSort( float[] a, int direction)
   {
      int i, top = a.length - 1, gap = top / 2;

      boolean swapped = true, test = false;

      while (swapped) {
         swapped = false;

         top = a.length - gap;

         for ( i = 0; i < top; i++) {
            test = a[i] > a[i+gap];

            test = direction == DESCEND ? !test:test;

            if ( test) {
               float t = a[i];
               a[i] = a[i+gap];
               a[i+gap] = t;
               swapped = true;
            }
         }

         gap = newGap( gap);
      }
   }

   //////////////////////////////////////////////////////////////////////

   private static void combSort( double[] a, int direction)
   {
      int i, top = a.length - 1, gap = top / 2;

      boolean swapped = true, test = false;

      while (swapped) {
         swapped = false;

         top = a.length - gap;

         for ( i = 0; i < top; i++) {
            test = a[i] > a[i+gap];

            test = direction == DESCEND ? !test:test;

            if ( test) {
               double t = a[i];
               a[i] = a[i+gap];
               a[i+gap] = t;
               swapped = true;
            }
         }

         gap = newGap( gap);
      }
   }

   
   //////////////////////////////////////////////////////////////////////

   private static void combSort( String[] a, int direction)
   {
      int i, top = a.length - 1, gap = top / 2;

      boolean swapped = true, test = false;

      while (swapped) {
         swapped = false;

         top = a.length - gap;

         for ( i = 0; i < top; i++) {
            if (direction == ASCEND)
               test = a[i].compareTo( a[i+gap]) > 0;
            else
               test = a[i+gap].compareTo( a[i]) > 0;

            if ( test) {
               String t = a[i];
               a[i] = a[i+gap];
               a[i+gap] = t;
               swapped = true;
            }
         }

         gap = newGap( gap);
      }
   }



   //////////////////////////////////////////////////////////////////////
   //  Choose a new gap size.  Lacey & Box did exhaustive research on the
   //  optimum gap size and shrink factor.  They found a shrink factor
   //  of 1.3 provided the best overall performance and that gap sizes
   //  of 9 and 10 provided less performance than others, while gap size
   //  11 provided unusually good performance.
   //
   //  Notice that the last pass of CombSort is actually our old friend
   //  the bubble sort.  i.e. Bubble sort is a special case of CombSort.
   //////////////////////////////////////////////////////////////////////
      
   private static int newGap( int gap)
   {
      switch ( (gap = (int) ((double) gap / 1.3))) { // shrink the gap

         case 0:   gap = 1;  break;   // this makes a bubble sort!
         case 9:
         case 10:  gap = 11; break;   // this makes CombSort11
      }

      return gap;
   }



   //////////////////////////////////////////////////////////////////////
   //  Test example.    usage:   java Sort [maxNumbersToSort]
   //////////////////////////////////////////////////////////////////////

   public static void main( String[] args)
   {
      int  max;     
      long startTime, endTime;

      try {
         max = Integer.parseInt( args[0]);
      }
      catch( Exception e) { max = 100; }     // default to 100 numbers


      System.out.println("CombSort " + max + " random integers");

      int[] table = new int[max];  Random rnd = new Random();

      for ( int i = 0; i < table.length; i++) {
         table[i] = rnd.nextInt() % max;
         System.out.print( table[i] + " \t");
     }

      System.out.println("\nNow sorted:\n");


      startTime = System.currentTimeMillis();

         new Sort( table); // Here is how we "call" the sort

         // new Sort( table, Sort.DESCEND);  // if you prefer...

      endTime = System.currentTimeMillis();


      for ( int i = 0; i < table.length; i++)
         System.out.print( table[i] + " \t");

      System.out.println( "\nTest concluded.  Sort required " +
         (endTime - startTime) + "ms");
   }
}