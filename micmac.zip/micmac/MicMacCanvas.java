import java.awt.Canvas;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Event;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.MediaTracker;
import java.awt.Toolkit;

import java.applet.Applet;
import java.net.URL;


//////////////////////////////////////////////////////////////////////
// 
//  Instances of this class paint the user interface for MicMac.
//  It paints the background images of the UI and then updates the
//  registers values, highlight lines, and teletype display.
//
//  This class is declared final, in an effort to speed things up.
//  (The optimizer can inline things if it knows there will not be
//  any subclasses.)
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 Responsible for drawing the user's view of the MicMac simulator.
 @see Simulator
 @see MicMac
 */

public final class MicMacCanvas extends Canvas
{
   ///////////////////////////////////////////////////////////////////
   //  Constructor
   ///////////////////////////////////////////////////////////////////

   /**
    Create a new simulator view point.
    @param Reference to calling applet, or null if in application mode.
    */

   public MicMacCanvas( Applet applet)
   {
      this.applet = applet;

      sansFont = new Font("Sanserif", Font.BOLD, 10);

      monoFont = new Font("Courier",  Font.PLAIN, 10);

      setFont( sansFont);
   }



   //////////////////////////////////////////////////////////////////////
   //  Let us know when the peer canvas has been made so we take some
   //  metrics and act on them.
   //////////////////////////////////////////////////////////////////////

   /**
    Let this canvas know when it is safe to measure itself.
    */

   public void addNotify()
   {
      super.addNotify();

      FontMetrics f = getFontMetrics( getFont());
      textHeight    = f.getAscent();

      digits  = setupDigits("Digits.gif");
      chars   = setupChars("Chars.gif");
      resetRegisters();

      gr = this.getGraphics();

      uiReady = true;

      cpu    = getImage( "Cpu.gif");      
 
      width  = cpu.getWidth(this);
      height = cpu.getHeight(this);

      this.resize( width, height);

      paintNow();
   }




   //////////////////////////////////////////////////////////////////////
   //  Overiding the standard canvas methods, especially the painting
   //  methods.
   //////////////////////////////////////////////////////////////////////

   public Dimension minimumSize()
   {
      return new Dimension(width, height);
   }


   public Dimension preferredSize()
   {
      return minimumSize();
   }



   public void update( Graphics G)
   {
      paint(G);
   }


   /**
    Immediately repaint the current state of the simulator.
    */

   // HACK!  Sometimes the repaint thread does not actually
   // work!

   public void paintNow()
   {
      if ( gr != null)
         paint(gr);
   }


   public void paint( Graphics G)
   {     
      setGraphics( G);

      G.drawImage( cpu, 0, 0, beigeColor, this);

      drawRegisters();

      drawPaths();

      drawTTY();
   }
   



   //////////////////////////////////////////////////////////////////////
   //  Top level event handler
   //////////////////////////////////////////////////////////////////////

   public boolean handleEvent( Event e) {

      if ( e.id == Event.MOUSE_DOWN) {
         int oldLevel = redrawLevel;

         redrawLevel = REDRAW_FULL;

         repaint(); 

         redrawLevel = oldLevel;

         return true;
      }
      
      return super.handleEvent(e);
   }




   //////////////////////////////////////////////////////////////////////
   //  Draw all the visible simulator registers
   //////////////////////////////////////////////////////////////////////

   /**
    Draw the current state of all of MicMac's visible registers.
    */

   public void drawRegisters()
   {
      drawMicRegisters();
      drawLatches();
      drawMacRegisters();
      drawConsoleRegisters();
      drawInstruction();
   }



   //////////////////////////////////////////////////////////////////////
   //  Clear the UI
   //////////////////////////////////////////////////////////////////////
 
   /**
    Reset the visible state of the simulator.
    */

   public void reset()
   {
      while (!uiReady)
         ;

      resetImage();
      resetRegisters();

      repaint();

      ttyChar('\f');        // clear console screen, home cursor
   }



   //////////////////////////////////////////////////////////////////////
   //  Used by the MicMacMark benchmark to dest drawing speed
   //////////////////////////////////////////////////////////////////////

   /**
    Draw test lines for the MicMacMark benchmark
    @see MicMac#runJavaBenchmark
    */

   public void testDraw()
   {
      for ( int i = 0; i < 16; i++) {
         drawPathToBusA(i, false);
         drawPathToBusB(i, false);
         drawPathToBusC(i, false);
         drawOtherPath( i, false, true);
      }

      for ( int i = 0; i < 16; i++) {
         drawPathToBusA(i, true);
         drawPathToBusB(i, true);
         drawPathToBusC(i, true);
         drawOtherPath( i, true, true);
      }

      gr.drawImage( cpu, 0, 0, beigeColor, this);
   }



   //////////////////////////////////////////////////////////////////////
   //  Repaint the background and clear all the highlights
   //////////////////////////////////////////////////////////////////////

   /**
    Repaint the simulator background and clear all the data path highlights.
    */

   public void resetImage()
   {
      if ( !uiReady)
         return;

      int oldLevel = redrawLevel;
      redrawLevel = REDRAW_FULL;

      for ( int i = 0; i < 16; i++) {
         drawPathToBusA(i, false);
         drawPathToBusB(i, false);
         drawPathToBusC(i, false);
         drawOtherPath( i, false, false);
      }

      otherPaths = 0; // restart accumulating "Other" paths (as in drawOtherPath())

      drawInstructionStandout( false);

      redrawLevel = oldLevel;
   }



   //////////////////////////////////////////////////////////////////////
   //  These registers ape the ones in the simulator, and are what the
   //  UI bases its drawing on.
   //////////////////////////////////////////////////////////////////////

   /**
    Reset the canvases copy of the simulator's registers.
    */

   public void resetRegisters()
   {
      MIC = PC = AC = IR = TIR = CZ = A = B = C = D = E = F = 0;

      CP = 1; CM = 0xFFFFl;  SP = 0xFB4;  SP2 = SP+1; SP3 = SP+2;

      AMASK = 0xFFF;   SMASK = 0xFF;

      LA = LB = AMUX = SH = MBR = MAR = ZF = NF = 0;

      SPv1 = SPv2 = SPv3 = In = Inf = Out = Outf = 0;

      iMPC = iAMUX = iCOND = iALU = iSH = iMBR = iMAR = iRD = iWR = 0;


      iENC = iC = iB = iA = iADDR = 0;
   }





   //////////////////////////////////////////////////////////////////////
   //  Fetch the latest values from all the simulator's visible registers
   //////////////////////////////////////////////////////////////////////

   /**
    Refresh the canvas' copy of the simulator's registers.
    */

   public void refreshRegisters()
   {
      if ( sim == null)
         return;

      PC    = sim.fetchReg(0);
      AC    = sim.fetchReg(1);
      SP    = sim.fetchReg(2);
      IR    = sim.fetchReg(3);
      TIR   = sim.fetchReg(4);
      CZ    = sim.fetchReg(5);
      CP    = sim.fetchReg(6);
      CM    = sim.fetchReg(7);
      AMASK = sim.fetchReg(8);
      SMASK = sim.fetchReg(9);
      A     = sim.fetchReg(10);
      B     = sim.fetchReg(11);
      C     = sim.fetchReg(12);
      D     = sim.fetchReg(13);
      E     = sim.fetchReg(14);
      F     = sim.fetchReg(15);

      drawRegisters();
   }



   //////////////////////////////////////////////////////////////////////
   //  Draw Mic machine cycle phase 0.  The simulator invokes this method
   //////////////////////////////////////////////////////////////////////

   /**
    Simulator callback to make phase0 activities visible.
    @param MIC Current MIC instruction.
    @param MPC Current MIC MPC (microprogram counter)
    @see Simulator#phase0
    */

   public void phase0( long MIC, int MPC)
   {
      resetImage();

      this.MIC = MIC;

      iMPC = MPC;

      iAMUX = (MIC & 0x80000000) >> 31;
      iCOND = (MIC & 0x60000000) >> 29;
      iALU  = (MIC & 0x18000000) >> 27;
      iSH   = (MIC & 0x06000000) >> 25;
      iMBR  = (MIC & 0x01000000) >> 24;
      iMAR  = (MIC & 0x00800000) >> 23;
      iRD   = (MIC & 0x00400000) >> 22;
      iWR   = (MIC & 0x00200000) >> 21;
      iENC  = (MIC & 0x00100000) >> 20;
      iC    = (MIC & 0x000F0000) >> 16;
      iB    = (MIC & 0x0000F000) >> 12;
      iA    = (MIC & 0x00000F00) >> 8;
      iADDR = (MIC & 0x000000FF);

      drawInstruction();
      drawPhase(0);
      drawInstructionStandout( true);
   }



   //////////////////////////////////////////////////////////////////////
   // Draw Mic machine cycle phase 1
   //////////////////////////////////////////////////////////////////////

   /**
    Simulator callback to make phase1 activities visible.
    @param LatchA Current value of the A Latch.
    @param LatchB Current value of the B Latch.
    @see Simulator#phase1
    */

   public void phase1(long LatchA, long LatchB)
   {
      drawInstructionStandout( false);
      drawPhase(1);

      drawPathToBusA( (int) iA, true);
      drawPathToBusB( (int) iB, true);

      LA = LatchA < 0 ? LatchA + 65536 : LatchA;
      LB = LatchB < 0 ? LatchB + 65536 : LatchB;

      drawLatches();
   }



   //////////////////////////////////////////////////////////////////////
   // Draw Mic machine cycle phase 2
   //////////////////////////////////////////////////////////////////////

   /**
    Simulator callback to make phase2 activities visible.
    @param ALU Current value of the ALU (arithmetic-logic-unit).
    @param SH  Current value of the Shifter.
    @param ZF  Current value of the ALU's zero flag.
    @param NF  Current value of the ALU's negative flag.
    @see Simulator#phase2
    */

   public void phase2( long ALU, long SH, boolean ZF, boolean NF)
   {
      this.ZF = ZF ? 1 : 0;
      this.NF = NF ? 1 : 0;

      if ( iAMUX == 1) {
         drawOtherPath( 2, true, false);
         AMUX = MBR;
      }
      else {
         drawOtherPath( 0, true, false);
         AMUX = LA;
      }


      drawOtherPath( 1, true, false);


      if ( iMAR == 1) {
         drawOtherPath( 6, true, false);
         MAR = LB % Simulator.CORE_SIZE;
      }
      else
         drawOtherPath( 7, true, false);


      drawOtherPath( 5, true, false);

      this.ALU = ALU;
      this.SH  = SH;

      drawPhase(2);
      drawLatches();
   }



   //////////////////////////////////////////////////////////////////////
   // Draw Mic machine cycle phase 3
   //////////////////////////////////////////////////////////////////////

   /**
    Simulator callback to make phase3 activities visible.
    @param MBR  Current value of the MBR (memory buffer register).
    @param core Reference to the main memory array.
    @see Simulator#phase3
    */

   public void phase3( long MBR, long[] core)
   {
      this.MBR = MBR;

      int tC = (int) iC;

      if ( iENC == 1) {
         drawPathToBusC( tC, true);

         switch ( tC) {
            case  0: PC = SH;    break;
            case  1: AC = SH;    break;
            case  2: SP = SH & 0xFFF;    break;
            case  3: IR = SH;    break;
            case  4: TIR = SH;   break;
            case  5: CZ = SH;    break;
            case  6: CP = SH;    break;
            case  7: CM = SH;    break;
            case  8: AMASK = SH; break;
            case  9: SMASK = SH; break;
            case 10: A = SH;     break;
            case 11: B = SH;     break;
            case 12: C = SH;     break;
            case 13: D = SH;     break;
            case 14: E = SH;     break;
            case 15: F = SH;     break;
         }
      }

      if ( iMBR == 1) {
         drawOtherPath( 10, true, false);
         MBR = SH;
      }


      if ( iMBR == 1 && iENC == 1)
         drawOtherPath( 11, true, false);


      if ( iRD == 1) {
         drawOtherPath( 3, true, false);
         drawOtherPath( 9, true, false);
      }

      if ( iWR == 1) {
         drawOtherPath( 4, true, false);
         drawOtherPath( 9, true, false);
      }

      if ( iRD == 1 && iWR == 1)
         drawOtherPath(12, true, false);


      // Stack grows downward

      SP2 = (SP+1) % Simulator.CORE_SIZE;
      SP3 = (SP+2) % Simulator.CORE_SIZE;

      SPv1 = core[ (int) SP];
      SPv2 = core[ (int) SP2];
      SPv3 = core[ (int) SP3];

      drawRegisters();
      drawPhase(3);
   }



   //////////////////////////////////////////////////////////////////////
   //  Draw Console I/O registers
   //////////////////////////////////////////////////////////////////////

   /**
    Draw the TTY device I/O and status registers.
    */

   public void drawConsoleRegisters()
   {
      if ( redrawLevel < REDRAW_MAC)
         return;

      In   = sim.fetchCore( Simulator.CONSOLE_INPUT_REG);
      Inf  = sim.fetchCore( Simulator.CONSOLE_ISTAT_REG);
      Out  = sim.fetchCore( Simulator.CONSOLE_OUTPUT_REG);
      Outf = sim.fetchCore( Simulator.CONSOLE_OSTAT_REG);

      //             y    x   reg  bits digs
      drawRegister( 182, 308,   In,16,  2, REDF);    // In
      drawRegister( 182, 320,  Out,16,  2, REDF);    // Out
      drawRegister( 198, 308,  Inf, 2,  1, YELLOWF); // In flag
      drawRegister( 198, 320, Outf, 2,  1, YELLOWF); // Out flag
   }



   //////////////////////////////////////////////////////////////////////
   //  Draw the given string to the Mic Source code area
   //////////////////////////////////////////////////////////////////////

   /**
    Draw the given text into the Mic source line area.
    @param source Text to draw.
    */

   public void drawMicInstruction( String source)
   {
      if ( redrawLevel < REDRAW_MIC)
         return;


      // HACK!  IE4.x won't let me cache a graphics context reliably
      // so I have to set it again here!

      gmic = gr.create(95,242,350,30);


      Rectangle r = gmic.getClipRect();

      int x = r.height;

      gmic.drawImage( cpu, -95, -242, beigeColor, this);
      gmic.setColor(Color.black);
      gmic.drawString(source,0, ((x-textHeight)/2)+textHeight);
   }




   //////////////////////////////////////////////////////////////////////
   //  Draw the given string to the Mic Source code area
   //////////////////////////////////////////////////////////////////////

   /**
    Draw the given text into the Mac source line area.
    @param source Text to draw.
    */

   public void drawMacInstruction( String source)
   {
      if ( redrawLevel < REDRAW_MAC)
         return;


      // HACK!  IE4.x won't let me cache a graphics context reliably
      // so I have to set it again here!

      gmac = gr.create(95,337,340,18);

      Rectangle r = gmac.getClipRect();

      int x = r.height;

      gmac.setColor( Color.black);
      gmac.fillRect(0,0,r.width, r.height);
      gmac.setColor(Color.green);
      gmac.drawString(source,0, ((x-textHeight)/2)+textHeight);
   }





   //////////////////////////////////////////////////////////////////////
   //  Draw a "clock" to indicate one of four phases
   //////////////////////////////////////////////////////////////////////

   /**
    Draw a 'clock-like' phase indicator.
    @param phase Phase number (0 to 3) to draw.
    */

   private void drawPhase( int phase)
   {
      if ( redrawLevel < REDRAW_MIC)
         return;

      int x = 585;   int w = 10;
      int y = 145;   int h = 10;

      gr.setColor( grayColor);
      gr.fillOval( x, y, w, h);
      gr.setColor( Color.red);

      switch (phase) {
         case 0: gr.fillArc( x, y, w, h,    0, 90); break;
         case 1: gr.fillArc( x, y, w, h,  -90, 90); break;
         case 2: gr.fillArc( x, y, w, h, -180, 90); break;
         case 3: gr.fillArc( x, y, w, h, -270, 90); break;
      }
   }




   //////////////////////////////////////////////////////////////////////
   //  Highlight the instruction area of the display
   //////////////////////////////////////////////////////////////////////

   /**
    Highlight the microinstruction field area.
    @param highlight True to highlight, false to return to normal.
    */

   private void drawInstructionStandout( boolean highlight)
   {
      if ( redrawLevel < REDRAW_PATHS)
         return;

      Color c;

      if ( highlight)
         c = coralColor;
      else
         c = grayColor;

      gr.setColor(c);
      gr.drawRoundRect( 458, 135, 146,224,14,14);

      if (!highlight) {
         gr.setColor( beigeColor);
         gr.drawLine( 458,236,458,281);
      }
   }




   //////////////////////////////////////////////////////////////////////
   // Draw Test
   //////////////////////////////////////////////////////////////////////

   /**
    Draw a set of tests into the TTY device area for the MicMacMark benchmark
    @see MicMac#runJavaBenchmark
    */

   public void test()
   {
      int x = 10, y = 10, p = 0;

      for (int i = (int) 'A'; i < 127; i++) {
         drawChar( x+(p*7), y, (char) i);
         p++;
      }

   }




   //////////////////////////////////////////////////////////////////////
   // Console TTY emulator.  Draw the character if it's printable, 
   // otherwise perform the appropriate control function.
   //////////////////////////////////////////////////////////////////////

   /**
    Draw a character into the TTY device area at the current cursor position.
    @param c Character to draw.
    */

   public void ttyChar( char c)
   {
      ttyCharAt( conRowPos, conColPos, ' ');

      switch (c) {
         case 0x08: // Backspace
                    ttyCharAt( conRowPos, conColPos, ' ');

                    conColPos--;

                    if ( conColPos < 0) {
                       conColPos = 0;

                       if ( conRowPos > 0)
                          conColPos = CONSOLE_COLS-1;

                       conRowPos--;

                       if ( conRowPos < 0)
                          conRowPos = 0;
                    }
                    break;


         case 0x0C: // Form Feed (clear screen, home cursor)
                    gcon.setColor( blackColor);
                    gcon.fillRect( 0, 0, (7*CONSOLE_COLS), (13*CONSOLE_ROWS));
                    conRowPos = conColPos = 0;

                    for (int i = 0; i < CONSOLE_ROWS; i++)
                       for (int j = 0; j < CONSOLE_COLS; j++)
                          ttyImage[i][j] = ' ';

                    break;
     

         case 0x0A: // Line Feed
                    conRowPos++;  conRowPos %= CONSOLE_ROWS;

         case 0x0D: // Carriage Return
                    conColPos = 0;
                    break;

         default:   // "Printable" character
                    ttyCharAt( conRowPos, conColPos, c); conColPos++;
      }

      if ( conColPos >= CONSOLE_COLS) {
         conColPos = 0;
         conRowPos++;

         // If last char on screen, do a vertical scroll

         if ( conRowPos >= CONSOLE_ROWS) {
            conColPos = 0;
            conRowPos = CONSOLE_ROWS-1;

            gcon.copyArea( 0,     13, (7*CONSOLE_COLS), 13, 0, -13); 

            gcon.copyArea( 0, (2*13), (7*CONSOLE_COLS), 13, 0, -13); 

            gcon.setColor( blackColor);
            gcon.fillRect( 0, (2*13), (7*CONSOLE_COLS), 13);
         }
      }

      ttyCharAt( conRowPos, conColPos, CURSOR_CHAR);
   }



   //////////////////////////////////////////////////////////////////////
   //  Draw a character at row, col.
   //////////////////////////////////////////////////////////////////////

   /**
    Draw a character into the TTY device area at the current row, col.
    Do not update the cursor position.
    @param row Row 0 to 2.
    @param col Column 0 to 31.
    @param c Character to draw.
    */

   public void ttyCharAt( int row, int col, char c)
   {
      int x = (col *  7);
      int y = (row * 13);

      drawChar( x, y, c);

      ttyImage[row][col] = c;
   }



   //////////////////////////////////////////////////////////////////////
   //  Draw a string at the current tty cursor position.
   //////////////////////////////////////////////////////////////////////

   /**
    Draw a string into the TTY device area at the current cursor position.
    */

   public void ttyString( String s)
   {
      int top = s.length();

      for (int i = 0; i < top; i++)
         ttyChar( s.charAt(i));
   }



   //////////////////////////////////////////////////////////////////////
   //  Repaint the tty screen to refresh it, painting only printables.
   //////////////////////////////////////////////////////////////////////

   /**
    Redraw the current TTY device area contents.
    */

   public void drawTTY()
   {
      for (int i = 0; i < CONSOLE_ROWS; i++)
         for (int j = 0; j < CONSOLE_COLS; j++)
            ttyCharAt(i, j, ttyImage[i][j]);
   }




   //////////////////////////////////////////////////////////////////////
   //  Return true if the user-interface is on the screen and ready.
   //////////////////////////////////////////////////////////////////////

   /**
    Return a boolean to indicate user-interface readiness.
    */

   public boolean getUiReady() { return uiReady; }




   //////////////////////////////////////////////////////////////////////
   //  Connect the UI with the simulator.  (There is a two way connection)
   //////////////////////////////////////////////////////////////////////

   /**
    Connect a simulator object with this user-interface.
    @param sim Simulator object associated with the current MicMac session.
    */

   public void setSimulator( Simulator sim)
   {
      this.sim = sim;
   }



   //////////////////////////////////////////////////////////////////////
   //  Get/Set the amount of UI drawing we want.  
   //////////////////////////////////////////////////////////////////////

   /**
    Set the user-interface redraw level: 
    REDRAW_FULL, REDRAW_PATHS, REDRAW_MIC, REDRAW_MAC, or REDRAW_NONE
    */

   public void setRedrawLevel( int level)
   {
      redrawLevel = level;
   }


   /**
    Return the current user-interface redraw level (constant indicating
    the amount of drawing which will be done).
    */

   public int getRedrawLevel()
   {
      return redrawLevel;
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Private Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   private static int  CONSOLE_ROWS = 3;
   private static int  CONSOLE_COLS = 32;
   private static char CURSOR_CHAR  = (char) 127;


   private int conRowPos = 0;
   private int conColPos = 0;
   private Point consoleOrigin = new Point( 217,295);
   private char ttyImage[][]   = new char[CONSOLE_ROWS][CONSOLE_COLS];


   public static int REDRAW_FULL  = 9;
   public static int REDRAW_PATHS = 4;
   public static int REDRAW_MIC   = 3;
   public static int REDRAW_MAC   = 2;
   public static int REDRAW_NONE  = 0;

   private int      redrawLevel = REDRAW_FULL;

   private static final Color blackColor      = new Color(   0,  0,  0);
   private static final Color goldColor       = new Color( 153,153,  0);
   private static final Color whiteColor      = new Color( 255,255,204);
   private static final Color beigeColor      = new Color( 255,255,153);
   private static final Color grayColor       = new Color( 204,204,204);
   private static final Color coralColor      = new Color( 204,102,000);
   private static final Color ltRedColor      = new Color( 255,204,204);
   private static final Color ltGreenColor    = new Color( 204,255,204);
   private static final Color ltBlueColor     = new Color( 204,204,255);
   private static final Color greenColor      = new Color(   0,255,  0);
   private static final Color cornflowerColor = new Color( 000, 51,153);

   private static final int BLUE  = 0;  // data path colors
   private static final int RED   = 1;
   private static final int GREEN = 2;

   private static final int GRAY    = 0;  // register background color
   private static final int CREME   = 1;
   private static final int YELLOWF = 2;  // foreground color, black back
   private static final int REDF    = 3;
   private static final int GREENF  = 4;


   private static final int BIN = 2;      // Radix used for drawRegister()
   private static final int DEC = 10;
   private static final int HEX = 16;

   private static final int maxOtherPaths   = 10;
   private int otherPaths                   = 0;

   private int lastPathToBusA               = 0;
   private int lastPathToBusB               = 0;
   private int lastPathToBusC               = 0;
   private int lastPathOther[]              = new int[maxOtherPaths];

   private boolean lastPathToBusAHighlight  = false;
   private boolean lastPathToBusBHighlight  = false;
   private boolean lastPathToBusCHighlight  = false;
   private boolean lastPathOtherHighlight[] = new boolean[maxOtherPaths];


   private boolean  uiReady = false;

   private Applet   applet = null;

   private Simulator sim = null;

   private Image    cpu;
   private Image[]  digits;
   private Image[]  chars;
   private int      width;
   private int      height;
   private Graphics gr   = null;
   private Graphics gcon = null;
   private Graphics gmic = null;
   private Graphics gmac = null;

   private int      textHeight;

   private Font     sansFont;
   private Font     monoFont;

   private long MIC   = 0;

   private long PC    = 0;
   private long AC    = 0;
   private long SP    = 0;
   private long IR    = 0;
   private long TIR   = 0;
   private long CZ    = 0;
   private long CP    = 0;
   private long CM    = 0;
   private long AMASK = 0;
   private long SMASK = 0;
   private long A     = 0;
   private long B     = 0;
   private long C     = 0;
   private long D     = 0;
   private long E     = 0;
   private long F     = 0;

   private long LA    = 0;
   private long LB    = 0;
   private long AMUX  = 0;
   private long ALU   = 0;
   private long SH    = 0;
   private long MBR   = 0;
   private long MAR   = 0;
   private long ZF    = 0;
   private long NF    = 0;


   private long SP2   = 0;
   private long SP3   = 0;
   private long SPv1  = 0;
   private long SPv2  = 0;
   private long SPv3  = 0;
   private long In    = 0;
   private long Out   = 0;
   private long Inf   = 0;
   private long Outf  = 0;

   private long iMPC  = 0;
   private long iAMUX = 0;
   private long iCOND = 0;
   private long iALU  = 0;
   private long iSH   = 0;
   private long iMBR  = 0;
   private long iMAR  = 0;
   private long iRD   = 0;
   private long iWR   = 0;
   private long iENC  = 0;
   private long iC    = 0;
   private long iB    = 0;
   private long iA    = 0;
   private long iADDR = 0;




   ///////////////////////////////////////////////////////////////////
   //  Use a MediaTracker to get a named image.
   ///////////////////////////////////////////////////////////////////

   private Image getImage( String name) {

      Image image = null;

      MediaTracker tracker = new MediaTracker(this);

      if ( applet == null)
         image = Toolkit.getDefaultToolkit().getImage( name);
      else {
         try {
            image = applet.getImage( new URL( applet.getDocumentBase(), name));
         }
         catch (Exception e) { 
            new MessageDialog( new Frame(),e.toString()+"\ntrying to open\n"+
               applet.getDocumentBase()+" "+name);};
      }

      if ( image != null) {
         tracker.addImage(image, 0);
         try { tracker.waitForID(0); } catch (Exception e) {}
      }

      return fixDither( image);
   }




   private Image fixDither( Image i)
   {
      Image j = createImage( i.getWidth(this), i.getHeight(this));


      Graphics g = j.getGraphics();

      g.drawImage( i, 0, 0, this);

      g.dispose();

      return j;
   }





   ///////////////////////////////////////////////////////////////////
   //  Paint a character bitmap at the given x, y spot.
   ///////////////////////////////////////////////////////////////////
   
   private void drawChar( int x, int y, char c)
   {
      if ( !uiReady)
         return;

      if ( c > 128)
         c = 33;
      if (gcon != null)
          gcon.drawImage( chars[c], x, y, Color.black, this);
   }



   ///////////////////////////////////////////////////////////////////
   //  Paint a bitmap representation of the value of a given
   //  register.
   ///////////////////////////////////////////////////////////////////
   
   private void drawRegister( int x, int y, long value, int radix, int Digits, int color)
   {
      int v;
      int dx = x + (Digits * 6) - 6;
 
      color *= 16;

      for (int i = 0; i < Digits; i++) {
         v  = (int) value % radix;

         gr.drawImage( digits[color+v], dx, y, Color.white, this);

         dx -= 6;

         value /= radix;
      }
   }



   //////////////////////////////////////////////////////////////////////
   //  Paint the bitmaps representing the Mic register file
   //////////////////////////////////////////////////////////////////////

   private void drawMicRegisters()
   {
      if ( redrawLevel < REDRAW_MIC)
         return;

      //            y    x   reg  radix digits
      drawRegister( 76,  19,   PC, BIN, 16, GRAY);  // PC
      drawRegister( 76,  31,   AC, BIN, 16, CREME); // AC
      drawRegister( 76,  43,   SP, BIN, 16, GRAY);  // SP
      drawRegister( 76,  55,   IR, BIN, 16, CREME); // IR
      drawRegister( 76,  67,  TIR, BIN, 16, GRAY);  // TIR
      drawRegister( 76,  79,   CZ, BIN, 16, CREME); // 0
      drawRegister( 76,  91,   CP, BIN, 16, GRAY);  // +1
      drawRegister( 76, 103,   CM, BIN, 16, CREME); // -1
      drawRegister( 76, 115,AMASK, BIN, 16, GRAY);  // AMASK
      drawRegister( 76, 127,SMASK, BIN, 16, CREME); // SMASK
      drawRegister( 76, 139,    A, BIN, 16, GRAY);  // A
      drawRegister( 76, 151,    B, BIN, 16, CREME); // B
      drawRegister( 76, 163,    C, BIN, 16, GRAY);  // C
      drawRegister( 76, 175,    D, BIN, 16, CREME); // D
      drawRegister( 76, 187,    E, BIN, 16, GRAY);  // E
      drawRegister( 76, 199,    F, BIN, 16, CREME); // F
   }



   //////////////////////////////////////////////////////////////////////
   //  Paint the bitmaps representing all the other visible data
   //  bearing components on the screen related to Mic
   //////////////////////////////////////////////////////////////////////

   private void drawLatches()
   {
      if ( redrawLevel < REDRAW_MIC)
         return;

      //             y    x   reg radix digits
      drawRegister( 270,  29,   LA, BIN, 16, CREME); // A
      drawRegister( 348,  57,   LB, BIN, 16, CREME); // B
      drawRegister( 259, 101, AMUX, BIN, 16, CREME); // Amux
      drawRegister( 314, 152,  ALU, BIN, 16, CREME); // ALU
      drawRegister( 271, 145,   ZF, BIN,  1, CREME); // Zero flag
      drawRegister( 271, 155,   NF, BIN,  1, CREME); // Negative flag
      drawRegister( 306, 186,   SH, BIN, 16, CREME); // Shifter
      drawRegister( 462, 101,  MBR, BIN, 16, CREME); // MBR
      drawRegister( 486,  78,  MAR, BIN, 12, CREME); // MAR
   }



   //////////////////////////////////////////////////////////////////////
   //  Paint bitmap representations of the Mac registers & memory
   //////////////////////////////////////////////////////////////////////

   private void drawMacRegisters()
   {
      if ( redrawLevel < REDRAW_MAC)
         return;

      //             y    x   reg  radix digits
      drawRegister(  51, 297,   PC, HEX,  3, REDF);   // PC
      drawRegister(  45, 309,   AC, HEX,  4, REDF);   // AC
      drawRegister(  96, 296,   SP, HEX,  3, REDF);   // SP
      drawRegister(  96, 308,  SP2, HEX,  3, REDF);   // SP+1
      drawRegister(  96, 320,  SP3, HEX,  3, REDF);   // SP+2
      drawRegister( 120, 296, SPv1, HEX,  4, GREENF); // SP value
      drawRegister( 120, 308, SPv2, HEX,  4, GREENF); // SP+1 value
      drawRegister( 120, 320, SPv3, HEX,  4, GREENF); // SP+2 value
   }



   //////////////////////////////////////////////////////////////////////
   //  Draw bitmaps representations of the microinstruction fields
   //////////////////////////////////////////////////////////////////////

   private void drawInstruction()
   {
      if ( redrawLevel < REDRAW_MIC)
         return;

      //             y    x   reg  radix digits
      drawRegister( 476, 147,  iMPC, DEC,  3, CREME); // MPC
      drawRegister( 488, 167, iAMUX, DEC,  1, CREME); // AMUX
      drawRegister( 488, 181, iCOND, DEC,  1, CREME); // COND
      drawRegister( 488, 195,  iALU, DEC,  1, CREME); // ALU
      drawRegister( 488, 209,   iSH, DEC,  1, CREME); // SHIFT
      drawRegister( 488, 223,  iMBR, DEC,  1, CREME); // MBR
      drawRegister( 488, 237,  iMAR, DEC,  1, CREME); // MAR
      drawRegister( 488, 251,   iRD, DEC,  1, CREME); // RD
      drawRegister( 488, 265,   iWR, DEC,  1, CREME); // WR
      drawRegister( 488, 279,  iENC, DEC,  1, CREME); // ENC
      drawRegister( 482, 293,    iC, DEC,  2, CREME); // C
      drawRegister( 482, 307,    iB, DEC,  2, CREME); // B
      drawRegister( 482, 321,    iA, DEC,  2, CREME); // A
      drawRegister( 476, 335, iADDR, DEC,  3, CREME); // ADDR
   }



   //////////////////////////////////////////////////////////////////////
   //  Setup an array of digit bitmaps from a bitmap file containing
   //  digit glyphs in various colors.  Usually "digits.gif"
   //////////////////////////////////////////////////////////////////////

   private Image[] setupDigits( String name)
   {
      int   next = 0;
      Image d;

      digits = new Image[104];

      d = getImage( name);

      Image dig    = createImage( 100, 100);

      Graphics g   = dig.getGraphics();

      g.drawImage( d, 0, 0, this);

      for ( int i = 1; i < 7; i++) {
         for ( int j = 0; j < 16; j++) {
            digits[next] = createImage( 6, 8);

            int vx = j * 6;
            int vy = i * 8;
            g.copyArea( vx, vy, 6, 8, -vx, -vy);

            Graphics gr = digits[next].getGraphics();
            gr.drawImage( dig, 0, 0, this);
            gr.dispose();

            next++;
         }
      }

      return digits;
   }



   //////////////////////////////////////////////////////////////////////
   //  Setup an array of character bitmaps from a bitmap file containing
   //  character glyphs for the tty display.  Usually "chars.gif"
   //////////////////////////////////////////////////////////////////////

   private Image[] setupChars( String name)
   {
      int   next = 0;
      Image d;

      chars = new Image[128];

      d = getImage( name);

      Image chara    = createImage( 673, 10);

      Graphics g   = chara.getGraphics();

      g.drawImage( d, 0, 0, this);

      int vx = 0;


      for ( int i = 32; i < chars.length; i++) {

         chars[i] = createImage( 7, 10);

         if ( i > 32) {
            vx = next * 7;
            g.copyArea( vx, 0, 7, 10, -vx, 0);
         }

         Graphics gr = chars[i].getGraphics();
         gr.drawImage( chara, 0, 0, this);
         gr.dispose();

         next++;
      }


      for ( int i = 0; i < 32; i++) // non-printables are blank
         chars[i] = chars[32];



      return chars;
   }




   //////////////////////////////////////////////////////////////////////
   //  Set the drawing colors depending on the color code and whether
   //  or not we are drawing the ON or OFF version of a highight
   //////////////////////////////////////////////////////////////////////

   private Color drawPathColor( int color, boolean highlight)
   {
      Color c = Color.black;

      if ( highlight) {
         switch (color) {
            case BLUE:  c = Color.blue;   break;
            case RED:   c = Color.red;    break;
            case GREEN: c = greenColor;   break;
         }
      }
      else {
         switch (color) {
            case BLUE:  c = ltBlueColor;  break;
            case RED:   c = ltRedColor;   break;
            case GREEN: c = ltGreenColor; break;
         }
      }

      return c;
   }



   //////////////////////////////////////////////////////////////////////
   //  Draw the selected data pathway leading from the register file
   //  to A Latch. Highlights are in the bright version of the color,
   //  Unhighlighted lines are a "dimmer" version of the same color.
   //////////////////////////////////////////////////////////////////////

   private void drawPathToBusA( int path, boolean highlight)
   {
      if ( redrawLevel < REDRAW_PATHS)
         return;

      Color c = drawPathColor( BLUE, highlight);  gr.setColor(c);


      switch (path) {
         case 0:  gr.fillRect( 174,20,13,2); 
                  gr.fillRect( 185,22, 2,9);
                  break;

         case 1:  gr.fillRect( 174,32,10,2);
                  break;

         case 2:  gr.fillRect( 174,44,11,2);
                  gr.fillRect( 185,35,2, 11);
                  break;

         case 3:  gr.fillRect( 174,56,11,2);
                  gr.fillRect( 185,35,2, 23);
                  break;

         case 4:  gr.fillRect( 174,68,11,2);
                  gr.fillRect( 185,35,2, 35);
                  break;

         case 5:  gr.fillRect( 174,80,11,2);
                  gr.fillRect( 185,35,2, 47);
                  break;

         case 6:  gr.fillRect( 174,92,11,2);
                  gr.fillRect( 185,35,2, 59);
                  break;

         case 7:  gr.fillRect( 174,104,11,2);
                  gr.fillRect( 185,35,2, 71);
                  break;

         case 8:  gr.fillRect( 174,116,11,2);
                  gr.fillRect( 185,35,2, 83);
                  break;

         case 9:  gr.fillRect( 174,128,11,2);
                  gr.fillRect( 185,35,2, 95);
                  break;

         case 10: gr.fillRect( 174,140,11,2);
                  gr.fillRect( 185,35,2, 107);
                  break;

         case 11: gr.fillRect( 174,152,11,2);
                  gr.fillRect( 185,35,2, 119);
                  break;

         case 12: gr.fillRect( 174,164,11,2);
                  gr.fillRect( 185,35,2, 131);
                  break;

         case 13: gr.fillRect( 174,176,11,2);
                  gr.fillRect( 185,35,2, 143);
                  break;

         case 14: gr.fillRect( 174,188,11,2);
                  gr.fillRect( 185,35,2, 155);
                  break;

         case 15: gr.fillRect( 174,200,11,2);
                  gr.fillRect( 185,35,2, 167);
                  break;
      }

      gr.fillRect( 184, 31,  4,  4);
      gr.fillRect( 188, 32, 35,  2);
      gr.drawLine( 219, 29, 219,36);
      gr.drawLine( 220, 30, 220,35);
      gr.drawLine( 221, 31, 221,34);

      lastPathToBusA = path;
      lastPathToBusAHighlight = highlight;
   }



   //////////////////////////////////////////////////////////////////////
   //  Draw the selected data pathway leading from the register file
   //  to B Latch. Highlights are in the bright version of the color,
   //  Unhighlighted lines are a "dimmer" version of the same color.
   //////////////////////////////////////////////////////////////////////

   private void drawPathToBusB( int path, boolean highlight)
   {
      if ( redrawLevel < REDRAW_PATHS)
         return;

      Color c = drawPathColor( RED, highlight);  gr.setColor(c);


      switch (path) {
         case 0:  gr.fillRect( 174,24,24,2); 
                  gr.fillRect( 198,24, 2,35);
                  break;

         case 1:  gr.fillRect( 174,36,24,2); 
                  gr.fillRect( 198,36, 2,23);
                  break;

         case 2:  gr.fillRect( 174,48,24,2); 
                  gr.fillRect( 198,48, 2,11);
                  break;

         case 3:  gr.fillRect( 174,60,24,2); 
                  break;

         case 4:  gr.fillRect( 174,72,24,2); 
                  gr.fillRect( 198,63, 2,11);
                  break;

         case 5:  gr.fillRect( 174,84,24,2); 
                  gr.fillRect( 198,63, 2,23);
                  break;

         case 6:  gr.fillRect( 174,96,24,2); 
                  gr.fillRect( 198,63, 2,35);
                  break;

         case 7:  gr.fillRect( 174,108,24,2); 
                  gr.fillRect( 198,63, 2,47);
                  break;

         case 8:  gr.fillRect( 174,120,24,2); 
                  gr.fillRect( 198,63, 2,59);
                  break;

         case 9:  gr.fillRect( 174,132,24,2); 
                  gr.fillRect( 198,63, 2,71);
                  break;

         case 10: gr.fillRect( 174,144,24,2); 
                  gr.fillRect( 198,63, 2,83);
                  break;

         case 11: gr.fillRect( 174,156,24,2); 
                  gr.fillRect( 198,63, 2,95);
                  break;

         case 12: gr.fillRect( 174,168,24,2); 
                  gr.fillRect( 198,63, 2,107);
                  break;

         case 13: gr.fillRect( 174,180,24,2); 
                  gr.fillRect( 198,63, 2,119);
                  break;

         case 14: gr.fillRect( 174,192,24,2); 
                  gr.fillRect( 198,63, 2,131);
                  break;

         case 15: gr.fillRect( 174,204,24,2); 
                  gr.fillRect( 198,63, 2,143);
                  break;


      }

      gr.fillRect( 197, 59,   4,  4);
      gr.fillRect( 201, 60, 101,  2);
      gr.drawLine( 298, 57, 298, 64);
      gr.drawLine( 299, 58, 299, 63);
      gr.drawLine( 300, 59, 300, 62);

      lastPathToBusB = path;
      lastPathToBusBHighlight = highlight;
   }




   //////////////////////////////////////////////////////////////////////
   //  Draw the selected data pathway leading from shifter back to the
   //  register file. Highlights are in the bright version of the color,
   //  Unhighlighted lines are a "dimmer" version of the same color.
   //////////////////////////////////////////////////////////////////////

   private void drawPathToBusC( int path, boolean highlight)
   {
      if ( redrawLevel < REDRAW_PATHS)
         return;

      Color c = drawPathColor( GREEN, highlight);  gr.setColor(c);


      switch (path) {
         case 0: gr.fillRect( 14,22,  2, 198);
                 gr.fillRect( 14,22, 20,   2);
                 break;

         case 1: gr.fillRect( 14,34,  2, 186);
                 gr.fillRect( 14,34, 20,   2);
                 break;

         case 2: gr.fillRect( 14,46,  2, 174);
                 gr.fillRect( 14,46, 20,   2);
                 break;

         case 3: gr.fillRect( 14,58,  2, 162);
                 gr.fillRect( 14,58, 20,   2);
                 break;

         case 4: gr.fillRect( 14,70,  2, 150);
                 gr.fillRect( 14,70, 20,   2);
                 break;

         case 5: gr.fillRect( 14,82,  2, 138);
                 gr.fillRect( 14,82, 20,   2);
                 break;

         case 6: gr.fillRect( 14,94,  2, 126);
                 gr.fillRect( 14,94, 20,   2);
                 break;

         case 7: gr.fillRect( 14,106,  2,114);
                 gr.fillRect( 14,106, 20,  2);
                 break;

         case 8: gr.fillRect( 14,118,  2,102);
                 gr.fillRect( 14,118, 20,  2);
                 break;

         case 9: gr.fillRect( 14,130,  2, 90);
                 gr.fillRect( 14,130, 20,  2);
                 break;

         case 10:gr.fillRect( 14,142,  2, 78);
                 gr.fillRect( 14,142, 20,  2);
                 break;

         case 11:gr.fillRect( 14,154,  2, 66);
                 gr.fillRect( 14,154, 20,  2);
                 break;

         case 12:gr.fillRect( 14,166,  2, 54);
                 gr.fillRect( 14,166, 20,  2);
                 break;

         case 13:gr.fillRect( 14,178,  2, 42);
                 gr.fillRect( 14,178, 20,  2);
                 break;

         case 14:gr.fillRect( 14,190,  2, 30);
                 gr.fillRect( 14,190, 20,  2);
                 break;

         case 15:gr.fillRect( 14,202,  2, 18);
                 gr.fillRect( 14,202, 20,  2);
                 break;

      }

      gr.fillRect( 335,197,  2, 24);
      gr.fillRect(  14,219,321,  2);

      int i = path * 12;

      gr.drawLine( 30, i+19, 30, i+26);
      gr.drawLine( 31, i+20, 31, i+25);
      gr.drawLine( 32, i+21, 32, i+24);

      lastPathToBusC = path;
      lastPathToBusCHighlight = highlight;
   }



   //////////////////////////////////////////////////////////////////////
   //  Draw a selected misc. data pathway which does not fall into the
   //  above catagories. Highlights are in the bright version of the color,
   //  Unhighlighted lines are a "dimmer" version of the same color. 
   //////////////////////////////////////////////////////////////////////

   private void drawOtherPath( int path, boolean highlight, boolean refresh)
   {
      if ( redrawLevel < REDRAW_PATHS)
         return;

      switch (path) {
         case 0: gr.setColor( drawPathColor(BLUE, highlight)); 
                 gr.fillRect( 258, 40, 2, 58);
                 gr.fillRect( 255, 94, 8, 1);
                 gr.fillRect( 256, 95, 6, 1);
                 gr.fillRect( 257, 96, 4, 1);
                 break;

         case 1: gr.setColor( drawPathColor(BLUE, highlight));
                 gr.fillRect( 258,112, 2, 29);
                 gr.fillRect( 255,137, 8, 1);
                 gr.fillRect( 256,138, 6, 1);
                 gr.fillRect( 257,139, 4, 1);
                 break;

         case 2: gr.setColor( drawPathColor(BLUE, highlight));
                 gr.fillRect( 357,104, 74, 2);
                 gr.fillRect( 360,101,  1, 8);
                 gr.fillRect( 359,102,  1, 6);
                 gr.fillRect( 358,103,  1, 4);
                 break;

         case 3: gr.setColor( drawPathColor(BLUE, highlight));
                 gr.fillRect( 560,104, 46,  2);
                 gr.fillRect( 563,101,  1,  8);
                 gr.fillRect( 562,102,  1,  6);
                 gr.fillRect( 561,103,  1,  4);
                 break;

         case 4: gr.setColor( drawPathColor(BLUE, highlight));
                 gr.fillRect( 560,104, 46,  2);
                 gr.fillRect( 601,101,  1,  8);
                 gr.fillRect( 602,102,  1,  6);
                 gr.fillRect( 603,103,  1,  4);
                 break;

         case 5: gr.setColor( drawPathColor(GREEN, highlight));
                 gr.fillRect( 335,167,  2, 16);
                 gr.fillRect( 332,179,  8,  1);
                 gr.fillRect( 333,180,  6,  1);
                 gr.fillRect( 334,181,  4,  1);
                 break;


         case 6: gr.setColor( drawPathColor(RED, highlight));
                 gr.fillRect( 408, 81, 46,  2);
                 gr.fillRect( 404, 80,  4,  4);
                 gr.fillRect( 450, 78,  1,  8);
                 gr.fillRect( 451, 79,  1,  6);
                 gr.fillRect( 452, 80,  1,  4);
       

         case 7: gr.setColor( drawPathColor(RED, highlight));
                 gr.fillRect( 405, 68,  2, 73);
                 gr.fillRect( 402,137,  8,  1);
                 gr.fillRect( 403,138,  6,  1);
                 gr.fillRect( 404,139,  4,  1);
                 break;

         case 8: gr.setColor( drawPathColor(RED, highlight));
                 gr.fillRect( 405, 68,  2, 15);
                 gr.fillRect( 406, 81, 48,  2);
                 gr.fillRect( 450, 78,  1,  8);
                 gr.fillRect( 451, 79,  1,  6);
                 gr.fillRect( 452, 80,  1,  4);
                 break;

         case 9: gr.setColor( drawPathColor(RED, highlight));
                 gr.fillRect( 560, 81, 45,  2);
                 gr.fillRect( 601, 78,  1,  8);
                 gr.fillRect( 602, 79,  1,  6);
                 gr.fillRect( 603, 80,  1,  4);
                 break;

         case 10:gr.setColor( drawPathColor(GREEN, highlight));
                 gr.fillRect( 337,219,108,  2);
                 gr.fillRect( 335,197,  2, 24);
                 gr.fillRect( 443,112,  2,108);
                 gr.fillRect( 440,115,  8,  1);
                 gr.fillRect( 441,114,  6,  1);
                 gr.fillRect( 442,113,  4,  1);
                 break;

         case 11:gr.setColor( drawPathColor(GREEN, highlight));
                 gr.fillRect( 334,218,  4,  4);
                 break;

         case 12:gr.setColor( drawPathColor(BLUE, highlight));
                 gr.fillRect( 560,104, 46,  2);
                 gr.fillRect( 563,101,  1,  8);
                 gr.fillRect( 562,102,  1,  6);
                 gr.fillRect( 561,103,  1,  4);
                 gr.fillRect( 560,104, 46,  2);
                 gr.fillRect( 601,101,  1,  8);
                 gr.fillRect( 602,102,  1,  6);
                 gr.fillRect( 603,103,  1,  4);
                 break;
      }


      if (!refresh) {
         lastPathOther[otherPaths] = path;
         lastPathOtherHighlight[otherPaths] = highlight;

         otherPaths++;  otherPaths %= maxOtherPaths;
      }
   }




   //////////////////////////////////////////////////////////////////////
   //  Redraw all the existing data paths.  Other paths is a special 
   //  case where all the path numbers since the last instruction are
   //  cached and redrawn here.
   //////////////////////////////////////////////////////////////////////

   private void drawPaths()
   {
      drawPathToBusA( lastPathToBusA,  lastPathToBusAHighlight);
      drawPathToBusB( lastPathToBusB,  lastPathToBusBHighlight);
      drawPathToBusC( lastPathToBusC,  lastPathToBusCHighlight);

      // redraw all the "Other" paths drawn this Mic cycle

      for (int i = 0; i < otherPaths; i++)
         drawOtherPath(  lastPathOther[i],   lastPathOtherHighlight[i], true);
   }





   //////////////////////////////////////////////////////////////////////
   //  Create the graphic subregions for the source and console regions
   //  of the simulator (to facilitation an IE4.x HACK!)
   //////////////////////////////////////////////////////////////////////

   private void setGraphics( Graphics gr)
   {            
      gmic = gr.create(95,242,350,30);


      gmac = gr.create(95,337,340,18);

      gcon = gr.create(consoleOrigin.x,consoleOrigin.y,
                       (CONSOLE_COLS*7),(CONSOLE_ROWS*13));
   }
}
