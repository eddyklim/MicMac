import java.awt.Frame;
import java.awt.Event;
import java.awt.Color;
import java.awt.CheckboxMenuItem;
import java.awt.MenuItem;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.Font;
import java.awt.TextArea;

import java.util.StringTokenizer;
import java.util.Enumeration;


//////////////////////////////////////////////////////////////////////
// 
//  View and Edit Core Dumps.  The dump is a editable window where
//  each line contains an address and the contents of that address.
//  Three types of dumps are supported:  Microstore, Main memory (CORE)
//  and Register.  This simply changes the title and calls a different
//  dump and recovery methods in the given simulator instance.
//
//  You can add/modify addressed entries simply by typing them in.
//  You may use any of the common radicies (hex, oct, bin, dec) by
//  appending the character: h, o, b to the end of the value.  Hex
//  values must begin with digit, even if that must be a zero.
//
//  Try to return focus to the invoking window on exit.
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 MicMac's core-dump user-interface.
 @see MicMac
 */

public class EditDump extends Frame
{  
   public static final int STORE = 0;
   public static final int CORE  = 1;
   public static final int REG   = 2;


   ///////////////////////////////////////////////////////////////////
   //  Constructors
   ///////////////////////////////////////////////////////////////////

   /**
    Allows the user to view and modify the contents of MicMac's
    microstore, main memory, or registers.  Pops-up automatically

    @param parent Frame to which focus returns
    @param sim Reference to the simulator object of the current MicMac session
    @param type The type of dump to desired: STORE, CORE, or REGISTER
    @param canvas Reference to the user-interface canvas (MicMacCanvas)
    */

   public EditDump( Frame parent, Simulator sim, int type)
   {
      this( parent, sim, type, null);
   }


   public EditDump( Frame parent, Simulator sim, MicMacCanvas canvas)
   {
      this( parent, sim, REG, canvas);
   }


   public EditDump( Frame parent, Simulator sim, int type, MicMacCanvas canvas) 
   {
      this.sim    = sim;
      this.canvas = canvas;
      this.parent = parent;

      setBackground( background);

      setupMenuBar();

      switch ( (this.type = type)) {

         case STORE:  setTitle("Edit Microstore Dump");
                      document = new TextArea( sim.dumpStore(),8, 42);
                      break;

         case CORE:   setTitle("Edit Memory Dump");
                      document = new TextArea( sim.dumpCore(), 8, 36);
                      break;

         case REG:    setTitle("Edit Register Dump");
                      document = new TextArea( sim.dumpReg("-018bb "), 8, 36);
                      break;
      }


      document.setFont( new Font( "Courier", Font.BOLD, 12));
      document.setBackground( background);


      add( "Center", document);

      setupMenuBar();

      pack();
      
      
      Util.nextWindowCorner(this);

      show();
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Public Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   ///////////////////////////////////////////////////////////////////
   //  Top-level event handler for the editor.
   ///////////////////////////////////////////////////////////////////

   public boolean handleEvent( Event e) {

      if ( e.id == Event.ACTION_EVENT || e.id == Event.WINDOW_DESTROY) {
         if ( e.id == Event.WINDOW_DESTROY || e.target == mItemAbandon)
            exit();
         else
         if ( e.target == mItemCommit) {   
            if ( mItemReadOnly.getState() == false) {
               switch (type) {
                  case STORE: sim.loadStore(document.getText()); break;
                  case CORE:  sim.loadCore( document.getText()); break;
                  case REG:   sim.loadReg( document.getText()); 
                              canvas.refreshRegisters();
                              break;
               }
            }

            exit();
         }
      }

      return super.handleEvent( e);
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Private Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   private static final Color background = new Color( 255,255,204);

   private CheckboxMenuItem mItemReadOnly;
   private MenuItem         mItemCommit;
   private MenuItem         mItemAbandon;

   private int          type;

   private Simulator    sim;
   private MicMacCanvas canvas;
   private TextArea     document;

   private Frame        parent = null;



   ///////////////////////////////////////////////////////////////////
   //  Setup a new menubar
   ///////////////////////////////////////////////////////////////////

   private void setupMenuBar()
   {
      MenuBar mb = new MenuBar();
      Menu    m  = new Menu("Edit");

      mItemReadOnly = new CheckboxMenuItem("Read Only");

      if ( type != REG) {
         m.add( mItemReadOnly);
         mItemReadOnly.setState( true);
         m.addSeparator();
      }

      m.add( (mItemCommit  = new MenuItem("Commit Session")));
      m.add( (mItemAbandon = new MenuItem("Abandon")));

      mb.add(m);

      setMenuBar(mb);
   }




   ///////////////////////////////////////////////////////////////////
   //  Try to give the invoking window the focus on the way out.
   ///////////////////////////////////////////////////////////////////

   private void exit()
   {
      hide();

      if ( parent != null)
         parent.requestFocus();

      dispose();
   }
}



