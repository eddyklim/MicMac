import java.awt.List;
import java.util.Hashtable;


//////////////////////////////////////////////////////////////////////
// 
// FastList is like List except that it can answer getSelectionAt()
// much more quickly than List.  The breakpoint feature uses Lists
// to implement breakpoint lists and it is necessary to lookup a
// given item in the list to see if it is selected (hence a breakpoint)
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 Subclass of List which returns a boolean indicating whether an item is
 selected, or not, with great speed.
 @see MicMac
 @see Simulator
 */

public class FastList extends List
{
   /**
    Mark an item as 'Fast' selected.
    @param i Item number
    @param selected Item's selection boolean state.
    */

   public void fastSelected( int i, boolean selected)
   {
      Integer key = new Integer(i);

      if ( selected)
         lookup.put( (Object) key, (Object) key);
      else
         lookup.remove( (Object) key);
   }


   /**
    Quickly return an item's selection state.
    @param  i Item number.
    @return Boolean of item's selection state.
    */

   public boolean isFastSelected( int i)
   {
      if ( lookup.get( (Object) new Integer(i)) != null)
         return true;

      return false;
   }


   private Hashtable lookup = new Hashtable(121);
}