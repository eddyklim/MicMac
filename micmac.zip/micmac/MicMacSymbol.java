import java.util.Hashtable;
import java.util.Enumeration;
import java.util.StringTokenizer;


//////////////////////////////////////////////////////////////////////
// 
//  MicMacSymbol is the symbol table class for the MicMacMake'
//  translator.  At first I simply used a hash table pairing symbols
//  with longs, but things started getting complicated (I was using
//  bit patterns to effectively store several fields in each symbol.
//  (Unfortunately, I'm still doing that a little.) So using a separate
//  symbol table class makes the code a bit easier to understand.
//
//           (c) 1997 Brett Blatchley, all rights reserved.  
//                 See MicMac TERMS OF USE for details.
//
//////////////////////////////////////////////////////////////////////

/**
 MicMacMake's symbols and symbol table.
 @see MicMacMake
 */

public class MicMacSymbol extends Object
{
   public  static final int ALL_SYMBOLS = 0;
   public  static final int SPECIAL     = 1;
   public  static final int MIC_KEYWORD = 2;
   public  static final int MIC_SYMBOL  = 3;
   public  static final int MAC_KEYWORD = 4;
   public  static final int MAC_SYMBOL  = 5;
   public  static final int MAC_OPCODE  = 6;
   public  static final int MAC_PARAM   = 7;

   public  static final int UNDEFINED   = -1;

   ///////////////////////////////////////////////////////////////////
   //  Constructors
   ///////////////////////////////////////////////////////////////////

   /**
    Insert a new symbol into the table.
    @param key Symbol's key.
    @param value Symbol's numeric value, if appropriate.
    @param svalue Symbol's string value, if approriate.
    @param shift Symbol's shift value (number of bits to shift parameter value), if appropriate.
    @param type Type of symbol: SPECIAL, MIC_KEYWORD, MIC_SYMBOL, MAC_KEYWORD, MAC_SYMBOL, MAC_OPCODE, MAC_PARAM, or UNDEFINED
    */

   public MicMacSymbol( String key, int value, String svalue, int shift, int type)
   {
      this.key    = key;  
      this.value  = value;
      this.svalue = svalue;
      this.shift  = shift;
      this.type   = type;

      table.put( makeKey( key, type), (Object) this);
   }


   public MicMacSymbol( int value, String key, int shift, int type)
   {
      this.key    = key;  
      this.value  = value;
      this.svalue = "";
      this.shift  = shift;
      this.type   = type;

      table.put( makeKey( value, type), (Object) this);
   }


   public static MicMacSymbol lookup( String key, int type)
   {
      return (MicMacSymbol) table.get( makeKey( key, type));
   }




   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Public Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   ///////////////////////////////////////////////////////////////////
   //  Mic Symbols
   ///////////////////////////////////////////////////////////////////

   /**
    Insert a new Mic symbol.
    @param key Symbol.
    @param value Symbol's value or address.
    */

   public static void insertMicSymbol( String key, int value)
   {
      new MicMacSymbol( key, value, "", 0, MIC_SYMBOL);
   }


   /**
    Lookup a Mic symbol.
    @return Value or address of the symbol, or UNDEFINED.
    */

   public static int lookupMicSymbol( String key)
   {
      MicMacSymbol s = (MicMacSymbol) table.get( makeKey( key, MIC_SYMBOL));

      return s != null ?  s.value : UNDEFINED;
   }



   ///////////////////////////////////////////////////////////////////
   //  Mic Keywords
   ///////////////////////////////////////////////////////////////////

   /**
    Insert a new Mic language keyword.
    @param key Keyword.
    @param value Keyword's token value.
    */

   public static void insertMicKeyword( String key, int value)
   {
      new MicMacSymbol( key, value, "", 0, MIC_KEYWORD);
   }


   /**
    Lookup a Mic keyword.
    @param key Keyword.
    @return Copy of the keyword's symbol table entry.
    */

   public static MicMacSymbol lookupMicKeyword( String key)
   {
      return (MicMacSymbol) table.get( makeKey( key, MIC_KEYWORD));
   }


   /**
    Lookup a Mic keyword.
    @param key Keyword.
    @return Token value of the keyword.
    */

   public static int lookupMicKeywordValue( String key)
   {
      MicMacSymbol s = (MicMacSymbol) table.get( makeKey( key, MIC_KEYWORD));

      return s != null ?  s.value : UNDEFINED;
   }



   ///////////////////////////////////////////////////////////////////
   //  Mac Symbols
   ///////////////////////////////////////////////////////////////////

   /**
    Insert a new Mac symbol
    @param key Symbol.
    @param value Symbol's value or address.
    */

   public static void insertMacSymbol( String key, int value)
   {
      new MicMacSymbol( key, value, "", 0, MAC_SYMBOL);
   }


   /**
    Lookup a Mac symbol.
    @param key Symbol.
    @return Token value of the symbol, or UNDEFINED.
    */

   public static int lookupMacSymbol( String key)
   {
      MicMacSymbol s = (MicMacSymbol) table.get( makeKey( key, MAC_SYMBOL));

      return s != null ? s.value : UNDEFINED;
   }



   ///////////////////////////////////////////////////////////////////
   //  Mac Keywords
   ///////////////////////////////////////////////////////////////////

   /**
    Insert a new Mac keyword.
    @param key Keyword.
    @param value Keyword token value.
    */

   public static void insertMacKeyword( String key, int value)
   {
      new MicMacSymbol( key, value, "", 0, MAC_KEYWORD);
   }


   /**
    Lookup a Mac keyword.
    @param key Keyword.
    @return Copy of the keyword entry in the symbol table.
    */

   public static MicMacSymbol lookupMacKeyword( String key)
   {
      return (MicMacSymbol) table.get( makeKey( key, MAC_KEYWORD));
   }




   ///////////////////////////////////////////////////////////////////
   //  Mac User Defined Instructions
   ///////////////////////////////////////////////////////////////////

   /**
    Insert a new Mac language opcode.
    @param key Opcode.
    @param value Opcode's instruction mask.
    */

   public static void insertMacOpcode( String key, int mask)
   {
      new MicMacSymbol( key, mask, "", 0, MAC_OPCODE);
   }


   /**
    Lookup a Mac opcode.
    @param key Opcode.
    @return Copy of the opcode's symbol table entry.
    */

   public static MicMacSymbol lookupMacOpcode( String key)
   {
      return (MicMacSymbol) table.get( makeKey( key, MAC_OPCODE));
   }


   /**
    Lookup a Mac opcode.
    @param key Opcode.
    @return Opcode's instruction mask value.
    */

   public static int lookupMacOpcodeValue( String key)
   {
      MicMacSymbol s = (MicMacSymbol) table.get( makeKey( key, MAC_OPCODE));

      return s != null ?  s.value : UNDEFINED;
   }



   ///////////////////////////////////////////////////////////////////
   //  Mac User Defined Instruction Parameters
   ///////////////////////////////////////////////////////////////////

   /**
    Insert a new Mac opcode parameter.
    @param key Opcode.
    @param paramNo Parameter number (from left to right, starting at 0).
    @param mask Parameter mask value.
    */

   public static void insertMacParameter( String key, int paramNo, int mask, int shift)
   {
      new MicMacSymbol( key, mask, "", shift, MAC_PARAM+(paramNo*100));
   }


   /**
    Lookup Mac parameter.
    @param key Opcode.
    @param paramNo Parameter number (from left to right, starting at 0).
    @return Copy of Opcode's selected parameter entry in the symbol table.
    */

   public static MicMacSymbol lookupMacParameter( String key, int paramNo)
   {
      return (MicMacSymbol) table.get( makeKey( key, MAC_PARAM+(paramNo*100)));
   }




   ///////////////////////////////////////////////////////////////////
   //  Special Symbol (like error counters, etc.)
   ///////////////////////////////////////////////////////////////////

   /**
    Insert a special symbol.
    @param key Symbol
    @param value Symbol's numeric value
    */

   public static void insertSpecial( String key, int value)
   {
      new MicMacSymbol( key, value, "", 0, SPECIAL);
   }


   /**
    Insert a special symbol.
    @param key Symbol.
    @param value Symbol's text value.
    */

   public static void insertSpecial( String key, String text)
   {
      new MicMacSymbol( key, 0, text, 0, SPECIAL);
   }


   /**
    Lookup a special symbol.
    @param key Symbol.
    @return Copy of Symbol's entry in the symbol table.
    */

   public static MicMacSymbol lookupSpecial( String key)
   {
      return (MicMacSymbol) table.get( makeKey( key, SPECIAL));
   }


   /**
    Lookup a special symbol.
    @param key Symbol.
    @return Symbol's numeric value, or UNDEFINED.
    */

   public static int lookupSpecialValue( String key)
   {
      MicMacSymbol s = (MicMacSymbol) table.get( makeKey( key, SPECIAL));

      return s != null ? s.value : UNDEFINED;
   }


   /**
    Lookup a special symbol.
    @param key Symbol.
    @return Symbol's text value, or null.
    */

   public static String lookupSpecialText( String key)
   {
      MicMacSymbol s = (MicMacSymbol) table.get( makeKey( key, SPECIAL));

      return s != null ? s.svalue : null;
   }




   ///////////////////////////////////////////////////////////////////
   //  Accessor methods
   ///////////////////////////////////////////////////////////////////

   /**
    Return a symbol's numeric value.
    @return Symbol's numeric value.
    */

   public int getValue() { return value; }

   /**
    Return a symbol's shift value.
    @return Symbol's shift value.
    */

   public int getShift() { return shift; }



   ///////////////////////////////////////////////////////////////////
   //  Clear a table of symbols
   ///////////////////////////////////////////////////////////////////

   /**
    Remove all the entries from the symbol table.
    */

   public static void clearTable()
   {
      table = null;  table = new Hashtable(32);
   }




   ///////////////////////////////////////////////////////////////////
   //  Create a string list of the contents an entire table
   ///////////////////////////////////////////////////////////////////

   /**
    Return a string containing a sorted list of all the symbol table entries
    in textual form.
    @return Symbol list.
    */

   public static String listTable()
   {
      return listTable(ALL_SYMBOLS, 0, 0, 0);
   }



   ///////////////////////////////////////////////////////////////////
   //  Create a string list of a certain type of symbol in a table
   ///////////////////////////////////////////////////////////////////

   /**
    Return a string containing a sorted list of a given class of symbol
    table entries in textual form.
    @param type Type of symbols desired: ALL_SYMBOLS, SPECIAL, MIC_KEYWORD, MIC_SYMBOL, MAC_KEYWORD, MAC_SYMBOL, MAC_OPCODE, MAC_PARAM, or UNDEFINED
    @param margin Number of spaces to indent each line.
    @param digits Number of places to format numeric values.
    @param radix Radix in which to express numeric values.
    @return Symbol list.
    */

   public static String listTable( int type, int margin, int digits, int radix)
   {
      Enumeration  e = table.keys();
      MicMacSymbol s;

      String list = "", key = "";


      while ( e.hasMoreElements())
         list += (String) e.nextElement() + "\n";


      StringTokenizer t = new StringTokenizer( Sort.string( list)); list = "";

      String margins = "" + margin + "s";

      String radixs  = "d ";

      switch (radix) {
         case 16: radixs = "xh "; break;
         case 10: radixs = "d  "; break;
         case  8: radixs = "oo "; break;
         case  2: radixs = "bb "; break;
      }

      radixs = "-0" + (digits+2) + radixs;

      while ( t.hasMoreTokens()) {
         key = (String) t.nextToken();

         s = (MicMacSymbol) table.get((Object) key);
      
         if ( s.type == type)
            list += Util.format(margins," ") +
                    Util.format("15s ",s.key) + 
                    Util.format(radixs, s.value) + 
                    Util.format("-10d", s.value) + "\n";
         else
         if ( type == ALL_SYMBOLS) {

            list += Util.format("32s ", s.key);

            switch ( s.type) {
               case SPECIAL:     list += "SPECIAL     ";
                                 list += Util.format( "-10d ", s.value); 
                                 list += " (" + s.svalue + ")"; break;

               case MIC_SYMBOL:  list += "MIC_SYMBOL  ";
                                 list += Util.format( "-10d ", s.value); break;

               case MIC_KEYWORD: list += "MIC_KEYWORD ";
                                 list += Util.format( "-10d ", s.value); break;

               case MAC_SYMBOL:  list += "MAC_SYMBOL  ";
                                 list += Util.format( "-10d ", s.value); break;

               case MAC_KEYWORD: list += "MAC_KEYWORD ";
                                 list += Util.format( "-10d ", s.value); break;

               case MAC_OPCODE:  list += "MAC_OPCODE  ";
                                 list += Util.format( "-09x ", s.value); break;

               case MAC_PARAM: 
               default:          list += "MAC_PARAM   ";
                                 list += Util.format( "-09x ", s.value);
                                 list += Util.format( "-3d ",  s.shift); break;
            }

            list += "\n";
         }
      }

      return list;
   }





   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////
   //  Private Members
   ///////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////




   private static Hashtable table = new Hashtable(32);

   private String key;
   private int    value;
   private String svalue;
   private int    shift;      // number of bits to shift the value
   private int    type;       // what type of symbols is this (see constants above)




   ///////////////////////////////////////////////////////////////////
   //  Make a special type of key from a given key and type number
   ///////////////////////////////////////////////////////////////////

   private static Object makeKey( String key, int type)
   {
      return (Object) (key + "_" + type);
   }


   private static Object makeKey( int key, int type)
   {
      return (Object) (Integer.toString(key) + "_" + type);
   }
}

